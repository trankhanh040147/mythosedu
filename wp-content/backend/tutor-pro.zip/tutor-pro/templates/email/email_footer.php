<div class="tutor-email-footer">
	<div class="tutor-email-separator">
		<img style="z-index:9;position:relative;" src="<?php echo esc_url( TUTOR_EMAIL()->url . 'assets/images/email.png' ); ?>">
	</div>
	<div class="tutor-email-footer-text">
		<div data-source="email-footer-text">{footer_text}</div>
	</div>
</div>
