<?php
    /**
     * @package TutorLMS/Templates
     * @version 1.4.3
     */

    $active_tab = 'my-courses/private-courses';
    include dirname(__DIR__) . DIRECTORY_SEPARATOR . 'my-courses.php';
?>
