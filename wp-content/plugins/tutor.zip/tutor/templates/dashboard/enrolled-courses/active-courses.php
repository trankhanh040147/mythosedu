<?php
    /**
     * @package TutorLMS/Templates
     * @version 1.4.3
     */

    $active_tab = 'enrolled-courses/active-courses';
    include dirname(__DIR__) . DIRECTORY_SEPARATOR . 'enrolled-courses.php';
?>
