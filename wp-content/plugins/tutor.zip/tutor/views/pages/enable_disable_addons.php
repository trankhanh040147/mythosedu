<?php
/**
 * Addons template for tutor pro
 */
?>
<div id="tutor-addons-list-wrapper"></div>
