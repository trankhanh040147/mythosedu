<style>
    #wpbody-content .notice {
        margin-top: 10px !important;
        margin-bottom: 10px !important;
    }
</style>