-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 19, 2022 at 07:53 AM
-- Server version: 8.0.30-0ubuntu0.20.04.2
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `live_vus_traininghub`
--
CREATE DATABASE IF NOT EXISTS `live_vus_traininghub` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `live_vus_traininghub`;

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_actions`
--

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;
CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint UNSIGNED NOT NULL,
  `hook` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `group_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `attempts` int NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_actions`
--

INSERT INTO `wp_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(200, 'wp_mail_smtp_summary_report_email', 'complete', '2022-07-26 02:02:01', '2022-07-26 02:02:01', '[1]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658800921;s:18:\"\0*\0first_timestamp\";i:1657548000;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658800921;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 2, 1, '2022-07-26 07:44:58', '2022-07-26 07:44:58', 0, NULL),
(221, 'wp_mail_smtp_summary_report_email', 'complete', '2022-08-02 07:44:58', '2022-08-02 07:44:58', '[1]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659426298;s:18:\"\0*\0first_timestamp\";i:1657548000;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659426298;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 2, 1, '2022-08-02 08:39:09', '2022-08-02 08:39:09', 0, NULL),
(222, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-26 07:44:58', '2022-07-26 07:44:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658821498;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658821498;}', 0, 1, '2022-07-26 07:45:15', '2022-07-26 07:45:15', 0, NULL),
(223, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-07-26 07:45:12', '2022-07-26 07:45:12', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658821512;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658821512;}', 0, 1, '2022-07-26 07:45:15', '2022-07-26 07:45:15', 0, NULL),
(224, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-26 08:56:06', '2022-07-26 08:56:06', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658825766;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658825766;}', 0, 1, '2022-07-26 08:56:06', '2022-07-26 08:56:06', 0, NULL),
(225, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-26 09:48:42', '2022-07-26 09:48:42', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658828922;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658828922;}', 0, 1, '2022-07-26 09:50:39', '2022-07-26 09:50:39', 0, NULL),
(226, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-26 11:39:01', '2022-07-26 11:39:01', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658835541;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658835541;}', 0, 1, '2022-07-26 11:44:50', '2022-07-26 11:44:50', 0, NULL),
(227, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-26 11:44:50', '2022-07-26 11:44:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658835890;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658835890;}', 0, 1, '2022-07-26 11:48:13', '2022-07-26 11:48:13', 0, NULL),
(228, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 02:01:32', '2022-07-27 02:01:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658887292;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658887292;}', 0, 1, '2022-07-27 02:03:33', '2022-07-27 02:03:33', 0, NULL),
(229, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 07:10:36', '2022-07-27 07:10:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658905836;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658905836;}', 0, 1, '2022-07-27 07:11:36', '2022-07-27 07:11:36', 0, NULL),
(230, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-07-27 07:43:24', '2022-07-27 07:43:24', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658907804;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658907804;}', 0, 1, '2022-07-27 07:43:24', '2022-07-27 07:43:24', 0, NULL),
(231, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 07:43:24', '2022-07-27 07:43:24', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658907804;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658907804;}', 0, 1, '2022-07-27 07:43:24', '2022-07-27 07:43:24', 0, NULL),
(232, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 08:43:23', '2022-07-27 08:43:23', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658911403;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658911403;}', 0, 1, '2022-07-27 08:43:23', '2022-07-27 08:43:23', 0, NULL),
(233, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 09:43:17', '2022-07-27 09:43:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658914997;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658914997;}', 0, 1, '2022-07-27 09:43:17', '2022-07-27 09:43:17', 0, NULL),
(234, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 10:43:17', '2022-07-27 10:43:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658918597;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658918597;}', 0, 1, '2022-07-27 10:43:17', '2022-07-27 10:43:17', 0, NULL),
(235, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 11:56:15', '2022-07-27 11:56:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658922975;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658922975;}', 0, 1, '2022-07-27 11:57:17', '2022-07-27 11:57:17', 0, NULL),
(236, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 12:43:17', '2022-07-27 12:43:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658925797;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658925797;}', 0, 1, '2022-07-27 12:43:17', '2022-07-27 12:43:17', 0, NULL),
(237, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 13:56:10', '2022-07-27 13:56:10', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658930170;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658930170;}', 0, 1, '2022-07-27 13:56:17', '2022-07-27 13:56:17', 0, NULL),
(238, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 14:43:17', '2022-07-27 14:43:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658932997;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658932997;}', 0, 1, '2022-07-27 14:43:17', '2022-07-27 14:43:17', 0, NULL),
(239, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-27 15:43:17', '2022-07-27 15:43:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658936597;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658936597;}', 0, 1, '2022-07-27 15:43:17', '2022-07-27 15:43:17', 0, NULL),
(240, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 04:18:15', '2022-07-28 04:18:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658981895;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658981895;}', 0, 1, '2022-07-28 04:18:54', '2022-07-28 04:18:54', 0, NULL),
(241, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 04:49:18', '2022-07-28 04:49:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658983758;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658983758;}', 0, 1, '2022-07-28 05:10:47', '2022-07-28 05:10:47', 0, NULL),
(242, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 05:43:55', '2022-07-28 05:43:55', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658987035;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658987035;}', 0, 1, '2022-07-28 05:53:53', '2022-07-28 05:53:53', 0, NULL),
(243, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 07:26:22', '2022-07-28 07:26:22', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658993182;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658993182;}', 0, 1, '2022-07-28 07:34:37', '2022-07-28 07:34:37', 0, NULL),
(244, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-07-28 07:43:15', '2022-07-28 07:43:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658994195;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658994195;}', 0, 1, '2022-07-28 07:43:16', '2022-07-28 07:43:16', 0, NULL),
(245, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 07:43:15', '2022-07-28 07:43:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658994195;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658994195;}', 0, 1, '2022-07-28 07:43:16', '2022-07-28 07:43:16', 0, NULL),
(246, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 09:21:43', '2022-07-28 09:21:43', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659000103;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659000103;}', 0, 1, '2022-07-28 12:50:54', '2022-07-28 12:50:54', 0, NULL),
(247, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 12:50:54', '2022-07-28 12:50:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659012654;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659012654;}', 0, 1, '2022-07-28 13:13:13', '2022-07-28 13:13:13', 0, NULL),
(248, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 14:19:21', '2022-07-28 14:19:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659017961;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659017961;}', 0, 1, '2022-07-28 14:32:23', '2022-07-28 14:32:23', 0, NULL),
(249, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 14:43:40', '2022-07-28 14:43:40', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659019420;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659019420;}', 0, 1, '2022-07-28 14:43:41', '2022-07-28 14:43:41', 0, NULL),
(250, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-28 23:46:10', '2022-07-28 23:46:10', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659051970;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659051970;}', 0, 1, '2022-07-29 01:05:28', '2022-07-29 01:05:28', 0, NULL),
(251, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 01:05:28', '2022-07-29 01:05:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659056728;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659056728;}', 0, 1, '2022-07-29 01:32:26', '2022-07-29 01:32:26', 0, NULL),
(252, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 01:56:20', '2022-07-29 01:56:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659059780;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659059780;}', 0, 1, '2022-07-29 01:56:20', '2022-07-29 01:56:20', 0, NULL),
(253, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 02:43:14', '2022-07-29 02:43:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659062594;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659062594;}', 0, 1, '2022-07-29 02:44:15', '2022-07-29 02:44:15', 0, NULL),
(254, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 04:58:32', '2022-07-29 04:58:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659070712;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659070712;}', 0, 1, '2022-07-29 05:26:26', '2022-07-29 05:26:26', 0, NULL),
(255, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 07:55:54', '2022-07-29 07:55:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659081354;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659081354;}', 0, 1, '2022-07-29 07:55:54', '2022-07-29 07:55:54', 0, NULL),
(256, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-07-29 07:55:55', '2022-07-29 07:55:55', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659081355;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659081355;}', 0, 1, '2022-07-29 07:56:00', '2022-07-29 07:56:00', 0, NULL),
(257, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 10:33:38', '2022-07-29 10:33:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659090818;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659090818;}', 0, 1, '2022-07-29 11:08:12', '2022-07-29 11:08:12', 0, NULL),
(258, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 11:08:12', '2022-07-29 11:08:12', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659092892;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659092892;}', 0, 1, '2022-07-29 13:16:06', '2022-07-29 13:16:06', 0, NULL),
(259, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 13:16:06', '2022-07-29 13:16:06', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659100566;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659100566;}', 0, 1, '2022-07-29 13:58:41', '2022-07-29 13:58:41', 0, NULL),
(260, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 13:58:41', '2022-07-29 13:58:41', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659103121;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659103121;}', 0, 1, '2022-07-29 19:38:21', '2022-07-29 19:38:21', 0, NULL),
(261, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 19:38:29', '2022-07-29 19:38:29', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659123509;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659123509;}', 0, 1, '2022-07-29 23:26:39', '2022-07-29 23:26:39', 0, NULL),
(262, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-29 23:26:39', '2022-07-29 23:26:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659137199;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659137199;}', 0, 1, '2022-07-30 01:51:17', '2022-07-30 01:51:17', 0, NULL),
(263, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 01:51:17', '2022-07-30 01:51:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659145877;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659145877;}', 0, 1, '2022-07-30 02:55:59', '2022-07-30 02:55:59', 0, NULL),
(264, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 02:56:07', '2022-07-30 02:56:07', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659149767;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659149767;}', 0, 1, '2022-07-30 04:08:09', '2022-07-30 04:08:09', 0, NULL),
(265, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 04:08:09', '2022-07-30 04:08:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659154089;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659154089;}', 0, 1, '2022-07-30 04:19:05', '2022-07-30 04:19:05', 0, NULL),
(266, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 05:51:07', '2022-07-30 05:51:07', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659160267;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659160267;}', 0, 1, '2022-07-30 05:54:02', '2022-07-30 05:54:02', 0, NULL),
(267, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 07:09:41', '2022-07-30 07:09:41', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659164981;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659164981;}', 0, 1, '2022-07-30 08:08:51', '2022-07-30 08:08:51', 0, NULL),
(268, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-07-30 08:08:52', '2022-07-30 08:08:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659168532;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659168532;}', 0, 1, '2022-07-30 12:15:38', '2022-07-30 12:15:38', 0, NULL),
(269, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 08:08:52', '2022-07-30 08:08:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659168532;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659168532;}', 0, 1, '2022-07-30 12:15:38', '2022-07-30 12:15:38', 0, NULL),
(270, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 12:15:38', '2022-07-30 12:15:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659183338;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659183338;}', 0, 1, '2022-07-30 13:13:57', '2022-07-30 13:13:57', 0, NULL),
(271, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 13:13:57', '2022-07-30 13:13:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659186837;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659186837;}', 0, 1, '2022-07-30 13:30:10', '2022-07-30 13:30:10', 0, NULL),
(272, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 14:59:30', '2022-07-30 14:59:30', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659193170;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659193170;}', 0, 1, '2022-07-30 16:45:31', '2022-07-30 16:45:31', 0, NULL),
(273, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 16:45:31', '2022-07-30 16:45:31', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659199531;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659199531;}', 0, 1, '2022-07-30 18:38:31', '2022-07-30 18:38:31', 0, NULL),
(274, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 18:38:31', '2022-07-30 18:38:31', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659206311;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659206311;}', 0, 1, '2022-07-30 22:27:08', '2022-07-30 22:27:08', 0, NULL),
(275, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 22:27:08', '2022-07-30 22:27:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659220028;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659220028;}', 0, 1, '2022-07-30 23:37:10', '2022-07-30 23:37:10', 0, NULL),
(276, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-30 23:37:10', '2022-07-30 23:37:10', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659224230;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659224230;}', 0, 1, '2022-07-31 01:27:51', '2022-07-31 01:27:51', 0, NULL),
(277, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 01:27:51', '2022-07-31 01:27:51', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659230871;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659230871;}', 0, 1, '2022-07-31 03:21:18', '2022-07-31 03:21:18', 0, NULL),
(278, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 03:21:18', '2022-07-31 03:21:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659237678;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659237678;}', 0, 1, '2022-07-31 03:23:22', '2022-07-31 03:23:22', 0, NULL),
(279, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 05:56:25', '2022-07-31 05:56:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659246985;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659246985;}', 0, 1, '2022-07-31 08:15:19', '2022-07-31 08:15:19', 0, NULL),
(280, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 08:15:19', '2022-07-31 08:15:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659255319;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659255319;}', 0, 1, '2022-07-31 08:15:19', '2022-07-31 08:15:19', 0, NULL),
(281, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-07-31 08:15:20', '2022-07-31 08:15:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659255320;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659255320;}', 0, 1, '2022-07-31 08:15:25', '2022-07-31 08:15:25', 0, NULL),
(282, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 09:22:15', '2022-07-31 09:22:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659259335;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659259335;}', 0, 1, '2022-07-31 09:24:38', '2022-07-31 09:24:38', 0, NULL),
(283, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 09:54:04', '2022-07-31 09:54:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659261244;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659261244;}', 0, 1, '2022-07-31 10:02:49', '2022-07-31 10:02:49', 0, NULL),
(284, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 11:45:24', '2022-07-31 11:45:24', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659267924;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659267924;}', 0, 1, '2022-07-31 13:12:57', '2022-07-31 13:12:57', 0, NULL),
(285, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 13:12:58', '2022-07-31 13:12:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659273178;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659273178;}', 0, 1, '2022-07-31 13:33:15', '2022-07-31 13:33:15', 0, NULL),
(286, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 18:12:44', '2022-07-31 18:12:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659291164;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659291164;}', 0, 1, '2022-07-31 18:19:37', '2022-07-31 18:19:37', 0, NULL),
(287, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 19:51:35', '2022-07-31 19:51:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659297095;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659297095;}', 0, 1, '2022-07-31 20:36:59', '2022-07-31 20:36:59', 0, NULL),
(288, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 22:30:40', '2022-07-31 22:30:40', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659306640;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659306640;}', 0, 1, '2022-07-31 23:48:40', '2022-07-31 23:48:40', 0, NULL),
(289, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-07-31 23:48:40', '2022-07-31 23:48:40', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659311320;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659311320;}', 0, 1, '2022-08-01 00:54:09', '2022-08-01 00:54:09', 0, NULL),
(290, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 00:54:09', '2022-08-01 00:54:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659315249;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659315249;}', 0, 1, '2022-08-01 01:01:54', '2022-08-01 01:01:54', 0, NULL),
(291, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 02:45:39', '2022-08-01 02:45:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659321939;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659321939;}', 0, 1, '2022-08-01 02:47:14', '2022-08-01 02:47:14', 0, NULL),
(292, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 03:43:39', '2022-08-01 03:43:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659325419;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659325419;}', 0, 1, '2022-08-01 03:43:39', '2022-08-01 03:43:39', 0, NULL),
(293, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 04:43:39', '2022-08-01 04:43:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659329019;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659329019;}', 0, 1, '2022-08-01 04:43:39', '2022-08-01 04:43:39', 0, NULL),
(294, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 05:53:33', '2022-08-01 05:53:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659333213;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659333213;}', 0, 1, '2022-08-01 06:41:38', '2022-08-01 06:41:38', 0, NULL),
(295, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 06:46:46', '2022-08-01 06:46:46', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659336406;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659336406;}', 0, 1, '2022-08-01 06:51:56', '2022-08-01 06:51:56', 0, NULL),
(296, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-01 07:59:11', '2022-08-01 07:59:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659340751;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659340751;}', 0, 1, '2022-08-01 07:59:15', '2022-08-01 07:59:15', 0, NULL),
(297, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 07:59:11', '2022-08-01 07:59:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659340751;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659340751;}', 0, 1, '2022-08-01 07:59:15', '2022-08-01 07:59:15', 0, NULL),
(298, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 09:22:51', '2022-08-01 09:22:51', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659345771;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659345771;}', 0, 1, '2022-08-01 11:23:44', '2022-08-01 11:23:44', 0, NULL),
(299, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 11:23:44', '2022-08-01 11:23:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659353024;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659353024;}', 0, 1, '2022-08-01 11:24:18', '2022-08-01 11:24:18', 0, NULL),
(300, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 11:57:03', '2022-08-01 11:57:03', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659355023;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659355023;}', 0, 1, '2022-08-01 12:00:22', '2022-08-01 12:00:22', 0, NULL),
(301, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 13:00:04', '2022-08-01 13:00:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659358804;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659358804;}', 0, 1, '2022-08-01 13:03:59', '2022-08-01 13:03:59', 0, NULL),
(302, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 20:00:36', '2022-08-01 20:00:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659384036;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659384036;}', 0, 1, '2022-08-01 21:14:52', '2022-08-01 21:14:52', 0, NULL),
(303, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 21:14:52', '2022-08-01 21:14:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659388492;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659388492;}', 0, 1, '2022-08-01 22:02:27', '2022-08-01 22:02:27', 0, NULL),
(304, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-01 22:02:27', '2022-08-01 22:02:27', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659391347;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659391347;}', 0, 1, '2022-08-01 22:38:50', '2022-08-01 22:38:50', 0, NULL),
(305, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 01:41:05', '2022-08-02 01:41:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659404465;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659404465;}', 0, 1, '2022-08-02 01:56:20', '2022-08-02 01:56:20', 0, NULL),
(306, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 01:56:20', '2022-08-02 01:56:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659405380;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659405380;}', 0, 1, '2022-08-02 02:24:52', '2022-08-02 02:24:52', 0, NULL),
(307, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 02:46:38', '2022-08-02 02:46:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659408398;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659408398;}', 0, 1, '2022-08-02 02:46:38', '2022-08-02 02:46:38', 0, NULL),
(308, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 05:55:30', '2022-08-02 05:55:30', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659419730;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659419730;}', 0, 1, '2022-08-02 06:11:40', '2022-08-02 06:11:40', 0, NULL),
(309, 'wp_mail_smtp_summary_report_email', 'complete', '2022-08-09 08:39:09', '2022-08-09 08:39:09', '[1]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660034349;s:18:\"\0*\0first_timestamp\";i:1657548000;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660034349;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 2, 1, '2022-08-09 08:53:33', '2022-08-09 08:53:33', 0, NULL),
(310, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 08:39:09', '2022-08-02 08:39:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659429549;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659429549;}', 0, 1, '2022-08-02 08:39:10', '2022-08-02 08:39:10', 0, NULL),
(311, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-02 08:39:11', '2022-08-02 08:39:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659429551;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659429551;}', 0, 1, '2022-08-02 08:39:15', '2022-08-02 08:39:15', 0, NULL),
(312, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 09:03:50', '2022-08-02 09:03:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659431030;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659431030;}', 0, 1, '2022-08-02 10:09:35', '2022-08-02 10:09:35', 0, NULL),
(313, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 10:09:35', '2022-08-02 10:09:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659434975;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659434975;}', 0, 1, '2022-08-02 10:18:58', '2022-08-02 10:18:58', 0, NULL),
(314, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 11:34:32', '2022-08-02 11:34:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659440072;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659440072;}', 0, 1, '2022-08-02 11:34:48', '2022-08-02 11:34:48', 0, NULL),
(315, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 12:10:15', '2022-08-02 12:10:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659442215;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659442215;}', 0, 1, '2022-08-02 14:54:48', '2022-08-02 14:54:48', 0, NULL),
(316, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 14:54:48', '2022-08-02 14:54:48', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659452088;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659452088;}', 0, 1, '2022-08-02 15:42:55', '2022-08-02 15:42:55', 0, NULL),
(317, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 16:28:36', '2022-08-02 16:28:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659457716;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659457716;}', 0, 1, '2022-08-02 16:28:36', '2022-08-02 16:28:36', 0, NULL),
(318, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 16:54:50', '2022-08-02 16:54:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659459290;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659459290;}', 0, 1, '2022-08-02 17:18:22', '2022-08-02 17:18:22', 0, NULL),
(319, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 18:17:27', '2022-08-02 18:17:27', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659464247;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659464247;}', 0, 1, '2022-08-02 18:31:13', '2022-08-02 18:31:13', 0, NULL),
(320, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-02 22:11:08', '2022-08-02 22:11:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659478268;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659478268;}', 0, 1, '2022-08-02 22:11:08', '2022-08-02 22:11:08', 0, NULL),
(321, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 01:35:14', '2022-08-03 01:35:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659490514;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659490514;}', 0, 1, '2022-08-03 01:35:21', '2022-08-03 01:35:21', 0, NULL),
(322, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 02:15:14', '2022-08-03 02:15:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659492914;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659492914;}', 0, 1, '2022-08-03 02:16:26', '2022-08-03 02:16:26', 0, NULL),
(323, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 02:43:13', '2022-08-03 02:43:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659494593;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659494593;}', 0, 1, '2022-08-03 02:43:14', '2022-08-03 02:43:14', 0, NULL),
(324, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 03:43:13', '2022-08-03 03:43:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659498193;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659498193;}', 0, 1, '2022-08-03 03:43:43', '2022-08-03 03:43:43', 0, NULL),
(325, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 06:08:05', '2022-08-03 06:08:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659506885;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659506885;}', 0, 1, '2022-08-03 06:08:05', '2022-08-03 06:08:05', 0, NULL),
(326, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 07:23:33', '2022-08-03 07:23:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659511413;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659511413;}', 0, 1, '2022-08-03 07:45:54', '2022-08-03 07:45:54', 0, NULL),
(327, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-03 07:45:54', '2022-08-03 07:45:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659512754;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659512754;}', 0, 1, '2022-08-03 07:49:27', '2022-08-03 07:49:27', 0, NULL),
(328, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 07:45:54', '2022-08-03 07:45:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659512754;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659512754;}', 0, 1, '2022-08-03 07:49:27', '2022-08-03 07:49:27', 0, NULL),
(329, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 09:22:15', '2022-08-03 09:22:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659518535;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659518535;}', 0, 1, '2022-08-03 09:44:13', '2022-08-03 09:44:13', 0, NULL),
(330, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 09:44:13', '2022-08-03 09:44:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659519853;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659519853;}', 0, 1, '2022-08-03 09:49:07', '2022-08-03 09:49:07', 0, NULL),
(331, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 10:54:47', '2022-08-03 10:54:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659524087;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659524087;}', 0, 1, '2022-08-03 11:04:35', '2022-08-03 11:04:35', 0, NULL),
(332, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 11:43:27', '2022-08-03 11:43:27', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659527007;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659527007;}', 0, 1, '2022-08-03 11:53:48', '2022-08-03 11:53:48', 0, NULL),
(333, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 13:18:57', '2022-08-03 13:18:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659532737;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659532737;}', 0, 1, '2022-08-03 13:32:24', '2022-08-03 13:32:24', 0, NULL),
(334, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 14:03:47', '2022-08-03 14:03:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659535427;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659535427;}', 0, 1, '2022-08-03 14:13:38', '2022-08-03 14:13:38', 0, NULL),
(335, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 14:49:57', '2022-08-03 14:49:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659538197;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659538197;}', 0, 1, '2022-08-03 17:13:41', '2022-08-03 17:13:41', 0, NULL),
(336, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 17:13:41', '2022-08-03 17:13:41', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659546821;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659546821;}', 0, 1, '2022-08-03 17:29:08', '2022-08-03 17:29:08', 0, NULL),
(337, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 18:24:26', '2022-08-03 18:24:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659551066;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659551066;}', 0, 1, '2022-08-03 18:27:52', '2022-08-03 18:27:52', 0, NULL),
(338, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 19:58:30', '2022-08-03 19:58:30', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659556710;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659556710;}', 0, 1, '2022-08-03 20:53:15', '2022-08-03 20:53:15', 0, NULL),
(339, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 20:53:15', '2022-08-03 20:53:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659559995;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659559995;}', 0, 1, '2022-08-03 21:38:45', '2022-08-03 21:38:45', 0, NULL),
(340, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 22:33:31', '2022-08-03 22:33:31', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659566011;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659566011;}', 0, 1, '2022-08-03 22:48:52', '2022-08-03 22:48:52', 0, NULL),
(341, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 22:48:52', '2022-08-03 22:48:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659566932;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659566932;}', 0, 1, '2022-08-03 23:39:18', '2022-08-03 23:39:18', 0, NULL),
(342, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-03 23:49:26', '2022-08-03 23:49:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659570566;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659570566;}', 0, 1, '2022-08-03 23:53:15', '2022-08-03 23:53:15', 0, NULL),
(343, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 00:52:09', '2022-08-04 00:52:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659574329;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659574329;}', 0, 1, '2022-08-04 01:51:05', '2022-08-04 01:51:05', 0, NULL),
(344, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 01:51:05', '2022-08-04 01:51:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659577865;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659577865;}', 0, 1, '2022-08-04 04:23:36', '2022-08-04 04:23:36', 0, NULL),
(345, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 04:23:45', '2022-08-04 04:23:45', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659587025;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659587025;}', 0, 1, '2022-08-04 05:21:49', '2022-08-04 05:21:49', 0, NULL),
(346, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 05:21:49', '2022-08-04 05:21:49', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659590509;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659590509;}', 0, 1, '2022-08-04 05:26:29', '2022-08-04 05:26:29', 0, NULL),
(347, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 06:00:01', '2022-08-04 06:00:01', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659592801;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659592801;}', 0, 1, '2022-08-04 06:11:45', '2022-08-04 06:11:45', 0, NULL),
(348, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 06:57:53', '2022-08-04 06:57:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659596273;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659596273;}', 0, 1, '2022-08-04 07:06:43', '2022-08-04 07:06:43', 0, NULL),
(349, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-04 07:44:17', '2022-08-04 07:44:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659599057;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659599057;}', 0, 1, '2022-08-04 09:43:06', '2022-08-04 09:43:06', 0, NULL),
(350, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 07:44:17', '2022-08-04 07:44:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659599057;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659599057;}', 0, 1, '2022-08-04 09:43:06', '2022-08-04 09:43:06', 0, NULL),
(351, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 09:43:06', '2022-08-04 09:43:06', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659606186;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659606186;}', 0, 1, '2022-08-04 11:40:24', '2022-08-04 11:40:24', 0, NULL),
(352, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 11:40:24', '2022-08-04 11:40:24', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659613224;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659613224;}', 0, 1, '2022-08-04 11:40:24', '2022-08-04 11:40:24', 0, NULL),
(353, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 11:53:55', '2022-08-04 11:53:55', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659614035;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659614035;}', 0, 1, '2022-08-04 12:06:31', '2022-08-04 12:06:31', 0, NULL),
(354, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 13:08:21', '2022-08-04 13:08:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659618501;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659618501;}', 0, 1, '2022-08-04 13:36:47', '2022-08-04 13:36:47', 0, NULL),
(355, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 14:02:04', '2022-08-04 14:02:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659621724;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659621724;}', 0, 1, '2022-08-04 14:02:14', '2022-08-04 14:02:14', 0, NULL),
(356, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 16:01:28', '2022-08-04 16:01:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659628888;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659628888;}', 0, 1, '2022-08-04 16:33:52', '2022-08-04 16:33:52', 0, NULL),
(357, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 17:37:49', '2022-08-04 17:37:49', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659634669;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659634669;}', 0, 1, '2022-08-04 19:50:47', '2022-08-04 19:50:47', 0, NULL),
(358, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 19:50:47', '2022-08-04 19:50:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659642647;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659642647;}', 0, 1, '2022-08-04 20:09:57', '2022-08-04 20:09:57', 0, NULL),
(359, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 21:54:50', '2022-08-04 21:54:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659650090;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659650090;}', 0, 1, '2022-08-04 23:09:39', '2022-08-04 23:09:39', 0, NULL),
(360, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-04 23:09:39', '2022-08-04 23:09:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659654579;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659654579;}', 0, 1, '2022-08-04 23:17:59', '2022-08-04 23:17:59', 0, NULL),
(361, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 00:11:07', '2022-08-05 00:11:07', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659658267;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659658267;}', 0, 1, '2022-08-05 00:11:17', '2022-08-05 00:11:17', 0, NULL),
(362, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 01:30:14', '2022-08-05 01:30:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659663014;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659663014;}', 0, 1, '2022-08-05 01:52:08', '2022-08-05 01:52:08', 0, NULL),
(363, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 01:52:08', '2022-08-05 01:52:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659664328;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659664328;}', 0, 1, '2022-08-05 01:52:18', '2022-08-05 01:52:18', 0, NULL),
(364, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 02:43:33', '2022-08-05 02:43:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659667413;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659667413;}', 0, 1, '2022-08-05 03:41:43', '2022-08-05 03:41:43', 0, NULL),
(365, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 03:45:57', '2022-08-05 03:45:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659671157;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659671157;}', 0, 1, '2022-08-05 03:49:36', '2022-08-05 03:49:36', 0, NULL),
(366, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 05:09:35', '2022-08-05 05:09:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659676175;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659676175;}', 0, 1, '2022-08-05 06:07:39', '2022-08-05 06:07:39', 0, NULL),
(367, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 06:07:39', '2022-08-05 06:07:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659679659;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659679659;}', 0, 1, '2022-08-05 06:29:01', '2022-08-05 06:29:01', 0, NULL),
(368, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 06:46:30', '2022-08-05 06:46:30', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659681990;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659681990;}', 0, 1, '2022-08-05 06:46:30', '2022-08-05 06:46:30', 0, NULL),
(369, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-05 07:44:22', '2022-08-05 07:44:22', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659685462;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659685462;}', 0, 1, '2022-08-05 07:44:22', '2022-08-05 07:44:22', 0, NULL),
(370, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 07:44:22', '2022-08-05 07:44:22', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659685462;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659685462;}', 0, 1, '2022-08-05 07:44:22', '2022-08-05 07:44:22', 0, NULL),
(371, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 09:08:12', '2022-08-05 09:08:12', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659690492;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659690492;}', 0, 1, '2022-08-05 09:11:23', '2022-08-05 09:11:23', 0, NULL),
(372, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 09:50:10', '2022-08-05 09:50:10', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659693010;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659693010;}', 0, 1, '2022-08-05 10:04:01', '2022-08-05 10:04:01', 0, NULL),
(373, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 10:54:28', '2022-08-05 10:54:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659696868;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659696868;}', 0, 1, '2022-08-05 11:04:49', '2022-08-05 11:04:49', 0, NULL),
(374, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 11:52:53', '2022-08-05 11:52:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659700373;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659700373;}', 0, 1, '2022-08-05 12:01:11', '2022-08-05 12:01:11', 0, NULL),
(375, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 13:15:21', '2022-08-05 13:15:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659705321;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659705321;}', 0, 1, '2022-08-05 18:02:09', '2022-08-05 18:02:09', 0, NULL),
(376, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-05 18:02:09', '2022-08-05 18:02:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659722529;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659722529;}', 0, 1, '2022-08-05 18:02:18', '2022-08-05 18:02:18', 0, NULL),
(377, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 00:29:45', '2022-08-06 00:29:45', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659745785;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659745785;}', 0, 1, '2022-08-06 00:35:06', '2022-08-06 00:35:06', 0, NULL),
(378, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 02:46:57', '2022-08-06 02:46:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659754017;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659754017;}', 0, 1, '2022-08-06 02:47:31', '2022-08-06 02:47:31', 0, NULL),
(379, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 06:02:26', '2022-08-06 06:02:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659765746;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659765746;}', 0, 1, '2022-08-06 07:09:33', '2022-08-06 07:09:33', 0, NULL),
(380, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 07:09:34', '2022-08-06 07:09:34', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659769774;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659769774;}', 0, 1, '2022-08-06 07:17:03', '2022-08-06 07:17:03', 0, NULL),
(381, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-06 11:47:36', '2022-08-06 11:47:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659786456;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659786456;}', 0, 1, '2022-08-06 12:04:51', '2022-08-06 12:04:51', 0, NULL),
(382, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 11:47:36', '2022-08-06 11:47:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659786456;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659786456;}', 0, 1, '2022-08-06 12:04:51', '2022-08-06 12:04:51', 0, NULL),
(383, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 12:59:36', '2022-08-06 12:59:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659790776;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659790776;}', 0, 1, '2022-08-06 13:43:31', '2022-08-06 13:43:31', 0, NULL),
(384, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 13:43:32', '2022-08-06 13:43:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659793412;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659793412;}', 0, 1, '2022-08-06 16:00:39', '2022-08-06 16:00:39', 0, NULL),
(385, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 16:00:48', '2022-08-06 16:00:48', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659801648;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659801648;}', 0, 1, '2022-08-06 18:42:02', '2022-08-06 18:42:02', 0, NULL),
(386, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 18:42:02', '2022-08-06 18:42:02', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659811322;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659811322;}', 0, 1, '2022-08-06 18:46:19', '2022-08-06 18:46:19', 0, NULL),
(387, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 18:46:19', '2022-08-06 18:46:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659811579;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659811579;}', 0, 1, '2022-08-06 18:56:23', '2022-08-06 18:56:23', 0, NULL),
(388, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 19:51:23', '2022-08-06 19:51:23', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659815483;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659815483;}', 0, 1, '2022-08-06 20:11:38', '2022-08-06 20:11:38', 0, NULL),
(389, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-06 23:53:00', '2022-08-06 23:53:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659829980;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659829980;}', 0, 1, '2022-08-07 00:51:37', '2022-08-07 00:51:37', 0, NULL),
(390, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 00:51:38', '2022-08-07 00:51:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659833498;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659833498;}', 0, 1, '2022-08-07 01:10:16', '2022-08-07 01:10:16', 0, NULL),
(391, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 01:58:52', '2022-08-07 01:58:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659837532;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659837532;}', 0, 1, '2022-08-07 03:00:00', '2022-08-07 03:00:00', 0, NULL),
(392, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 03:00:08', '2022-08-07 03:00:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659841208;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659841208;}', 0, 1, '2022-08-07 03:16:09', '2022-08-07 03:16:09', 0, NULL),
(393, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 04:19:04', '2022-08-07 04:19:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659845944;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659845944;}', 0, 1, '2022-08-07 04:29:24', '2022-08-07 04:29:24', 0, NULL),
(394, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 06:00:14', '2022-08-07 06:00:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659852014;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659852014;}', 0, 1, '2022-08-07 06:08:01', '2022-08-07 06:08:01', 0, NULL),
(395, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 06:57:34', '2022-08-07 06:57:34', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659855454;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659855454;}', 0, 1, '2022-08-07 07:25:55', '2022-08-07 07:25:55', 0, NULL),
(396, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-07 08:15:46', '2022-08-07 08:15:46', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659860146;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659860146;}', 0, 1, '2022-08-07 09:17:33', '2022-08-07 09:17:33', 0, NULL),
(397, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 08:15:46', '2022-08-07 08:15:46', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659860146;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659860146;}', 0, 1, '2022-08-07 09:17:33', '2022-08-07 09:17:33', 0, NULL),
(398, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 09:17:33', '2022-08-07 09:17:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659863853;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659863853;}', 0, 1, '2022-08-07 09:51:19', '2022-08-07 09:51:19', 0, NULL),
(399, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 09:51:19', '2022-08-07 09:51:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659865879;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659865879;}', 0, 1, '2022-08-07 09:56:57', '2022-08-07 09:56:57', 0, NULL),
(400, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 10:44:11', '2022-08-07 10:44:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659869051;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659869051;}', 0, 1, '2022-08-07 11:59:50', '2022-08-07 11:59:50', 0, NULL),
(401, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 11:59:50', '2022-08-07 11:59:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659873590;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659873590;}', 0, 1, '2022-08-07 12:06:38', '2022-08-07 12:06:38', 0, NULL),
(402, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 13:01:44', '2022-08-07 13:01:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659877304;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659877304;}', 0, 1, '2022-08-07 15:47:58', '2022-08-07 15:47:58', 0, NULL),
(403, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 15:47:58', '2022-08-07 15:47:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659887278;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659887278;}', 0, 1, '2022-08-07 16:33:54', '2022-08-07 16:33:54', 0, NULL),
(404, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 17:56:02', '2022-08-07 17:56:02', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659894962;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659894962;}', 0, 1, '2022-08-07 19:17:21', '2022-08-07 19:17:21', 0, NULL),
(405, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 19:17:21', '2022-08-07 19:17:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659899841;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659899841;}', 0, 1, '2022-08-07 20:01:12', '2022-08-07 20:01:12', 0, NULL),
(406, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 20:01:12', '2022-08-07 20:01:12', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659902472;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659902472;}', 0, 1, '2022-08-07 21:42:22', '2022-08-07 21:42:22', 0, NULL),
(407, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 21:42:22', '2022-08-07 21:42:22', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659908542;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659908542;}', 0, 1, '2022-08-07 21:43:23', '2022-08-07 21:43:23', 0, NULL),
(408, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 21:43:23', '2022-08-07 21:43:23', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659908603;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659908603;}', 0, 1, '2022-08-07 21:43:23', '2022-08-07 21:43:23', 0, NULL),
(409, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-07 22:59:21', '2022-08-07 22:59:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659913161;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659913161;}', 0, 1, '2022-08-07 23:07:12', '2022-08-07 23:07:12', 0, NULL),
(410, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 01:50:07', '2022-08-08 01:50:07', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659923407;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659923407;}', 0, 1, '2022-08-08 01:50:17', '2022-08-08 01:50:17', 0, NULL),
(411, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 03:29:22', '2022-08-08 03:29:22', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659929362;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659929362;}', 0, 1, '2022-08-08 04:15:40', '2022-08-08 04:15:40', 0, NULL),
(412, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 04:15:40', '2022-08-08 04:15:40', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659932140;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659932140;}', 0, 1, '2022-08-08 05:31:18', '2022-08-08 05:31:18', 0, NULL),
(413, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 05:31:18', '2022-08-08 05:31:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659936678;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659936678;}', 0, 1, '2022-08-08 05:59:16', '2022-08-08 05:59:16', 0, NULL),
(414, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 05:59:16', '2022-08-08 05:59:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659938356;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659938356;}', 0, 1, '2022-08-08 07:40:36', '2022-08-08 07:40:36', 0, NULL),
(415, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 07:40:36', '2022-08-08 07:40:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659944436;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659944436;}', 0, 1, '2022-08-08 07:40:36', '2022-08-08 07:40:36', 0, NULL),
(416, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-08 08:01:14', '2022-08-08 08:01:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659945674;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659945674;}', 0, 1, '2022-08-08 09:36:20', '2022-08-08 09:36:20', 0, NULL),
(417, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 08:01:14', '2022-08-08 08:01:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659945674;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659945674;}', 0, 1, '2022-08-08 09:36:20', '2022-08-08 09:36:20', 0, NULL),
(418, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 09:36:21', '2022-08-08 09:36:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659951381;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659951381;}', 0, 1, '2022-08-08 09:45:42', '2022-08-08 09:45:42', 0, NULL),
(419, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 09:45:42', '2022-08-08 09:45:42', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659951942;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659951942;}', 0, 1, '2022-08-08 11:55:54', '2022-08-08 11:55:54', 0, NULL),
(420, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 11:55:54', '2022-08-08 11:55:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659959754;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659959754;}', 0, 1, '2022-08-08 11:59:44', '2022-08-08 11:59:44', 0, NULL),
(421, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 13:02:17', '2022-08-08 13:02:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659963737;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659963737;}', 0, 1, '2022-08-08 13:02:44', '2022-08-08 13:02:44', 0, NULL),
(422, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 15:26:35', '2022-08-08 15:26:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659972395;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659972395;}', 0, 1, '2022-08-08 17:45:08', '2022-08-08 17:45:08', 0, NULL),
(423, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 17:45:08', '2022-08-08 17:45:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659980708;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659980708;}', 0, 1, '2022-08-08 17:45:18', '2022-08-08 17:45:18', 0, NULL),
(424, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-08 19:50:58', '2022-08-08 19:50:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1659988258;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1659988258;}', 0, 1, '2022-08-08 20:22:04', '2022-08-08 20:22:04', 0, NULL),
(425, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 00:52:08', '2022-08-09 00:52:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660006328;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660006328;}', 0, 1, '2022-08-09 01:10:28', '2022-08-09 01:10:28', 0, NULL),
(426, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 01:45:54', '2022-08-09 01:45:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660009554;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660009554;}', 0, 1, '2022-08-09 03:25:40', '2022-08-09 03:25:40', 0, NULL),
(427, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 03:25:50', '2022-08-09 03:25:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660015550;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660015550;}', 0, 1, '2022-08-09 03:41:57', '2022-08-09 03:41:57', 0, NULL),
(428, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 04:21:18', '2022-08-09 04:21:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660018878;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660018878;}', 0, 1, '2022-08-09 05:00:53', '2022-08-09 05:00:53', 0, NULL),
(429, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 05:00:53', '2022-08-09 05:00:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660021253;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660021253;}', 0, 1, '2022-08-09 05:55:26', '2022-08-09 05:55:26', 0, NULL),
(430, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 05:55:26', '2022-08-09 05:55:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660024526;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660024526;}', 0, 1, '2022-08-09 05:57:03', '2022-08-09 05:57:03', 0, NULL),
(431, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 07:42:03', '2022-08-09 07:42:03', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660030923;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660030923;}', 0, 1, '2022-08-09 07:42:03', '2022-08-09 07:42:03', 0, NULL),
(432, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-09 08:20:20', '2022-08-09 08:20:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660033220;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660033220;}', 0, 1, '2022-08-09 08:29:42', '2022-08-09 08:29:42', 0, NULL),
(433, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 08:20:20', '2022-08-09 08:20:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660033220;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660033220;}', 0, 1, '2022-08-09 08:29:42', '2022-08-09 08:29:42', 0, NULL),
(434, 'wp_mail_smtp_summary_report_email', 'complete', '2022-08-16 08:53:33', '2022-08-16 08:53:33', '[1]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660640013;s:18:\"\0*\0first_timestamp\";i:1657548000;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660640013;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 2, 1, '2022-08-16 10:30:12', '2022-08-16 10:30:12', 0, NULL),
(435, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 08:53:33', '2022-08-09 08:53:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660035213;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660035213;}', 0, 1, '2022-08-09 08:59:42', '2022-08-09 08:59:42', 0, NULL),
(436, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 09:49:39', '2022-08-09 09:49:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660038579;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660038579;}', 0, 1, '2022-08-09 10:09:33', '2022-08-09 10:09:33', 0, NULL),
(437, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 11:36:13', '2022-08-09 11:36:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660044973;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660044973;}', 0, 1, '2022-08-09 11:36:23', '2022-08-09 11:36:23', 0, NULL),
(438, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 11:44:00', '2022-08-09 11:44:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660045440;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660045440;}', 0, 1, '2022-08-09 12:21:14', '2022-08-09 12:21:14', 0, NULL),
(439, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 13:01:18', '2022-08-09 13:01:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660050078;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660050078;}', 0, 1, '2022-08-09 13:51:32', '2022-08-09 13:51:32', 0, NULL),
(440, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 13:51:32', '2022-08-09 13:51:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660053092;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660053092;}', 0, 1, '2022-08-09 13:51:45', '2022-08-09 13:51:45', 0, NULL),
(441, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 15:05:19', '2022-08-09 15:05:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660057519;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660057519;}', 0, 1, '2022-08-09 16:02:27', '2022-08-09 16:02:27', 0, NULL),
(442, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 16:02:28', '2022-08-09 16:02:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660060948;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660060948;}', 0, 1, '2022-08-09 17:48:04', '2022-08-09 17:48:04', 0, NULL),
(443, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 17:48:05', '2022-08-09 17:48:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660067285;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660067285;}', 0, 1, '2022-08-09 17:48:15', '2022-08-09 17:48:15', 0, NULL),
(444, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 20:26:53', '2022-08-09 20:26:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660076813;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660076813;}', 0, 1, '2022-08-09 21:34:36', '2022-08-09 21:34:36', 0, NULL),
(445, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 21:34:36', '2022-08-09 21:34:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660080876;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660080876;}', 0, 1, '2022-08-09 22:56:39', '2022-08-09 22:56:39', 0, NULL),
(446, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-09 22:56:39', '2022-08-09 22:56:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660085799;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660085799;}', 0, 1, '2022-08-09 23:25:59', '2022-08-09 23:25:59', 0, NULL),
(447, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 01:54:31', '2022-08-10 01:54:31', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660096471;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660096471;}', 0, 1, '2022-08-10 04:05:34', '2022-08-10 04:05:34', 0, NULL),
(448, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 04:05:42', '2022-08-10 04:05:42', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660104342;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660104342;}', 0, 1, '2022-08-10 04:27:10', '2022-08-10 04:27:10', 0, NULL),
(449, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 07:47:37', '2022-08-10 07:47:37', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660117657;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660117657;}', 0, 1, '2022-08-10 07:47:38', '2022-08-10 07:47:38', 0, NULL),
(450, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-10 07:47:39', '2022-08-10 07:47:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660117659;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660117659;}', 0, 1, '2022-08-10 07:47:43', '2022-08-10 07:47:43', 0, NULL),
(451, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 08:57:13', '2022-08-10 08:57:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660121833;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660121833;}', 0, 1, '2022-08-10 09:01:15', '2022-08-10 09:01:15', 0, NULL),
(452, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 09:57:07', '2022-08-10 09:57:07', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660125427;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660125427;}', 0, 1, '2022-08-10 09:57:17', '2022-08-10 09:57:17', 0, NULL),
(453, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 12:15:15', '2022-08-10 12:15:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660133715;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660133715;}', 0, 1, '2022-08-10 12:28:27', '2022-08-10 12:28:27', 0, NULL),
(454, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 13:56:04', '2022-08-10 13:56:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660139764;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660139764;}', 0, 1, '2022-08-10 16:56:37', '2022-08-10 16:56:37', 0, NULL),
(455, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 16:56:45', '2022-08-10 16:56:45', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660150605;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660150605;}', 0, 1, '2022-08-10 17:25:26', '2022-08-10 17:25:26', 0, NULL),
(456, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 17:58:53', '2022-08-10 17:58:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660154333;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660154333;}', 0, 1, '2022-08-10 18:01:52', '2022-08-10 18:01:52', 0, NULL),
(457, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 20:26:33', '2022-08-10 20:26:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660163193;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660163193;}', 0, 1, '2022-08-10 21:53:40', '2022-08-10 21:53:40', 0, NULL),
(458, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 21:53:40', '2022-08-10 21:53:40', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660168420;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660168420;}', 0, 1, '2022-08-10 22:36:51', '2022-08-10 22:36:51', 0, NULL),
(459, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-10 22:59:00', '2022-08-10 22:59:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660172340;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660172340;}', 0, 1, '2022-08-10 23:28:04', '2022-08-10 23:28:04', 0, NULL),
(460, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 01:02:18', '2022-08-11 01:02:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660179738;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660179738;}', 0, 1, '2022-08-11 02:04:39', '2022-08-11 02:04:39', 0, NULL),
(461, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 02:04:39', '2022-08-11 02:04:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660183479;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660183479;}', 0, 1, '2022-08-11 03:56:33', '2022-08-11 03:56:33', 0, NULL),
(462, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 03:56:43', '2022-08-11 03:56:43', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660190203;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660190203;}', 0, 1, '2022-08-11 04:12:46', '2022-08-11 04:12:46', 0, NULL),
(463, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 04:52:28', '2022-08-11 04:52:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660193548;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660193548;}', 0, 1, '2022-08-11 05:59:13', '2022-08-11 05:59:13', 0, NULL),
(464, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 05:59:13', '2022-08-11 05:59:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660197553;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660197553;}', 0, 1, '2022-08-11 08:43:52', '2022-08-11 08:43:52', 0, NULL),
(465, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 08:43:52', '2022-08-11 08:43:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660207432;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660207432;}', 0, 1, '2022-08-11 08:43:53', '2022-08-11 08:43:53', 0, NULL),
(466, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-11 08:43:53', '2022-08-11 08:43:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660207433;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660207433;}', 0, 1, '2022-08-11 08:43:58', '2022-08-11 08:43:58', 0, NULL),
(467, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 10:11:15', '2022-08-11 10:11:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660212675;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660212675;}', 0, 1, '2022-08-11 10:23:54', '2022-08-11 10:23:54', 0, NULL),
(468, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 10:52:18', '2022-08-11 10:52:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660215138;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660215138;}', 0, 1, '2022-08-11 12:21:18', '2022-08-11 12:21:18', 0, NULL),
(469, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 12:21:18', '2022-08-11 12:21:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660220478;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660220478;}', 0, 1, '2022-08-11 12:30:08', '2022-08-11 12:30:08', 0, NULL),
(470, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 14:38:49', '2022-08-11 14:38:49', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660228729;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660228729;}', 0, 1, '2022-08-11 14:39:06', '2022-08-11 14:39:06', 0, NULL),
(471, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 18:17:32', '2022-08-11 18:17:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660241852;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660241852;}', 0, 1, '2022-08-11 18:47:25', '2022-08-11 18:47:25', 0, NULL),
(472, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 18:47:25', '2022-08-11 18:47:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660243645;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660243645;}', 0, 1, '2022-08-11 20:42:07', '2022-08-11 20:42:07', 0, NULL),
(473, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 20:42:07', '2022-08-11 20:42:07', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660250527;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660250527;}', 0, 1, '2022-08-11 21:33:32', '2022-08-11 21:33:32', 0, NULL),
(474, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 21:33:32', '2022-08-11 21:33:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660253612;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660253612;}', 0, 1, '2022-08-11 21:47:53', '2022-08-11 21:47:53', 0, NULL),
(475, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-11 21:47:53', '2022-08-11 21:47:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660254473;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660254473;}', 0, 1, '2022-08-12 01:09:10', '2022-08-12 01:09:10', 0, NULL),
(476, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 01:09:10', '2022-08-12 01:09:10', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660266550;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660266550;}', 0, 1, '2022-08-12 02:32:39', '2022-08-12 02:32:39', 0, NULL),
(477, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 02:32:39', '2022-08-12 02:32:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660271559;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660271559;}', 0, 1, '2022-08-12 04:27:42', '2022-08-12 04:27:42', 0, NULL),
(478, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 04:27:42', '2022-08-12 04:27:42', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660278462;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660278462;}', 0, 1, '2022-08-12 04:59:03', '2022-08-12 04:59:03', 0, NULL),
(479, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 04:59:04', '2022-08-12 04:59:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660280344;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660280344;}', 0, 1, '2022-08-12 05:15:20', '2022-08-12 05:15:20', 0, NULL),
(480, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 07:38:07', '2022-08-12 07:38:07', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660289887;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660289887;}', 0, 1, '2022-08-12 07:38:08', '2022-08-12 07:38:08', 0, NULL),
(481, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-12 10:37:05', '2022-08-12 10:37:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660300625;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660300625;}', 0, 1, '2022-08-12 10:37:15', '2022-08-12 10:37:15', 0, NULL),
(482, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 10:37:05', '2022-08-12 10:37:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660300625;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660300625;}', 0, 1, '2022-08-12 10:37:15', '2022-08-12 10:37:15', 0, NULL),
(483, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 10:59:38', '2022-08-12 10:59:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660301978;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660301978;}', 0, 1, '2022-08-12 11:29:49', '2022-08-12 11:29:49', 0, NULL),
(484, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 12:28:49', '2022-08-12 12:28:49', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660307329;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660307329;}', 0, 1, '2022-08-12 14:04:35', '2022-08-12 14:04:35', 0, NULL),
(485, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 14:04:35', '2022-08-12 14:04:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660313075;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660313075;}', 0, 1, '2022-08-12 15:21:00', '2022-08-12 15:21:00', 0, NULL),
(486, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 15:21:09', '2022-08-12 15:21:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660317669;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660317669;}', 0, 1, '2022-08-12 15:47:46', '2022-08-12 15:47:46', 0, NULL),
(487, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 15:47:47', '2022-08-12 15:47:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660319267;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660319267;}', 0, 1, '2022-08-12 17:55:59', '2022-08-12 17:55:59', 0, NULL),
(488, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 17:55:59', '2022-08-12 17:55:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660326959;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660326959;}', 0, 1, '2022-08-12 18:39:31', '2022-08-12 18:39:31', 0, NULL),
(489, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 20:28:54', '2022-08-12 20:28:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660336134;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660336134;}', 0, 1, '2022-08-12 20:35:05', '2022-08-12 20:35:05', 0, NULL),
(490, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 21:29:19', '2022-08-12 21:29:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660339759;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660339759;}', 0, 1, '2022-08-12 21:55:50', '2022-08-12 21:55:50', 0, NULL),
(491, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 21:55:50', '2022-08-12 21:55:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660341350;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660341350;}', 0, 1, '2022-08-12 22:18:07', '2022-08-12 22:18:07', 0, NULL),
(492, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-12 23:22:41', '2022-08-12 23:22:41', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660346561;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660346561;}', 0, 1, '2022-08-13 01:00:59', '2022-08-13 01:00:59', 0, NULL),
(493, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 01:00:59', '2022-08-13 01:00:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660352459;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660352459;}', 0, 1, '2022-08-13 02:47:37', '2022-08-13 02:47:37', 0, NULL),
(494, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 02:47:37', '2022-08-13 02:47:37', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660358857;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660358857;}', 0, 1, '2022-08-13 03:00:58', '2022-08-13 03:00:58', 0, NULL),
(495, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 03:51:53', '2022-08-13 03:51:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660362713;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660362713;}', 0, 1, '2022-08-13 04:37:02', '2022-08-13 04:37:02', 0, NULL),
(496, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 05:00:49', '2022-08-13 05:00:49', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660366849;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660366849;}', 0, 1, '2022-08-13 05:57:57', '2022-08-13 05:57:57', 0, NULL),
(497, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 05:57:57', '2022-08-13 05:57:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660370277;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660370277;}', 0, 1, '2022-08-13 06:14:13', '2022-08-13 06:14:13', 0, NULL),
(498, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 07:21:19', '2022-08-13 07:21:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660375279;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660375279;}', 0, 1, '2022-08-13 09:22:14', '2022-08-13 09:22:14', 0, NULL),
(499, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-13 09:22:14', '2022-08-13 09:22:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660382534;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660382534;}', 0, 1, '2022-08-13 11:21:54', '2022-08-13 11:21:54', 0, NULL),
(500, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 09:22:14', '2022-08-13 09:22:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660382534;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660382534;}', 0, 1, '2022-08-13 11:21:54', '2022-08-13 11:21:54', 0, NULL),
(501, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 11:21:54', '2022-08-13 11:21:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660389714;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660389714;}', 0, 1, '2022-08-13 12:38:18', '2022-08-13 12:38:18', 0, NULL),
(502, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 12:38:18', '2022-08-13 12:38:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660394298;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660394298;}', 0, 1, '2022-08-13 15:44:06', '2022-08-13 15:44:06', 0, NULL),
(503, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 15:44:06', '2022-08-13 15:44:06', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660405446;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660405446;}', 0, 1, '2022-08-13 15:45:00', '2022-08-13 15:45:00', 0, NULL),
(504, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 17:24:23', '2022-08-13 17:24:23', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660411463;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660411463;}', 0, 1, '2022-08-13 17:39:54', '2022-08-13 17:39:54', 0, NULL),
(505, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 17:50:08', '2022-08-13 17:50:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660413008;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660413008;}', 0, 1, '2022-08-13 19:01:29', '2022-08-13 19:01:29', 0, NULL),
(506, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 19:01:29', '2022-08-13 19:01:29', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660417289;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660417289;}', 0, 1, '2022-08-13 20:39:33', '2022-08-13 20:39:33', 0, NULL),
(507, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 20:39:33', '2022-08-13 20:39:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660423173;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660423173;}', 0, 1, '2022-08-13 20:53:50', '2022-08-13 20:53:50', 0, NULL),
(508, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 20:53:50', '2022-08-13 20:53:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660424030;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660424030;}', 0, 1, '2022-08-13 22:13:37', '2022-08-13 22:13:37', 0, NULL),
(509, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-13 22:13:38', '2022-08-13 22:13:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660428818;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660428818;}', 0, 1, '2022-08-14 01:47:27', '2022-08-14 01:47:27', 0, NULL),
(510, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 01:47:27', '2022-08-14 01:47:27', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660441647;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660441647;}', 0, 1, '2022-08-14 03:03:24', '2022-08-14 03:03:24', 0, NULL),
(511, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 03:03:33', '2022-08-14 03:03:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660446213;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660446213;}', 0, 1, '2022-08-14 03:05:26', '2022-08-14 03:05:26', 0, NULL),
(512, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 03:55:58', '2022-08-14 03:55:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660449358;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660449358;}', 0, 1, '2022-08-14 03:59:10', '2022-08-14 03:59:10', 0, NULL),
(513, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 05:58:33', '2022-08-14 05:58:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660456713;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660456713;}', 0, 1, '2022-08-14 07:47:22', '2022-08-14 07:47:22', 0, NULL),
(514, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 07:47:22', '2022-08-14 07:47:22', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660463242;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660463242;}', 0, 1, '2022-08-14 07:47:22', '2022-08-14 07:47:22', 0, NULL),
(515, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-14 07:47:23', '2022-08-14 07:47:23', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660463243;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660463243;}', 0, 1, '2022-08-14 07:47:27', '2022-08-14 07:47:27', 0, NULL),
(516, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 08:50:19', '2022-08-14 08:50:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660467019;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660467019;}', 0, 1, '2022-08-14 09:11:21', '2022-08-14 09:11:21', 0, NULL),
(517, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 10:17:09', '2022-08-14 10:17:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660472229;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660472229;}', 0, 1, '2022-08-14 10:17:31', '2022-08-14 10:17:31', 0, NULL),
(518, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 10:47:50', '2022-08-14 10:47:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660474070;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660474070;}', 0, 1, '2022-08-14 11:42:15', '2022-08-14 11:42:15', 0, NULL),
(519, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 11:43:18', '2022-08-14 11:43:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660477398;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660477398;}', 0, 1, '2022-08-14 11:43:18', '2022-08-14 11:43:18', 0, NULL),
(520, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 13:16:19', '2022-08-14 13:16:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660482979;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660482979;}', 0, 1, '2022-08-14 13:30:53', '2022-08-14 13:30:53', 0, NULL),
(521, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 14:39:56', '2022-08-14 14:39:56', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660487996;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660487996;}', 0, 1, '2022-08-14 14:56:43', '2022-08-14 14:56:43', 0, NULL),
(522, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 14:56:43', '2022-08-14 14:56:43', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660489003;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660489003;}', 0, 1, '2022-08-14 15:20:19', '2022-08-14 15:20:19', 0, NULL),
(523, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 16:08:29', '2022-08-14 16:08:29', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660493309;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660493309;}', 0, 1, '2022-08-14 16:45:26', '2022-08-14 16:45:26', 0, NULL),
(524, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 16:45:26', '2022-08-14 16:45:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660495526;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660495526;}', 0, 1, '2022-08-14 19:10:25', '2022-08-14 19:10:25', 0, NULL),
(525, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 19:10:25', '2022-08-14 19:10:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660504225;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660504225;}', 0, 1, '2022-08-14 19:58:46', '2022-08-14 19:58:46', 0, NULL),
(526, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 19:58:47', '2022-08-14 19:58:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660507127;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660507127;}', 0, 1, '2022-08-14 22:18:38', '2022-08-14 22:18:38', 0, NULL),
(527, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 22:18:38', '2022-08-14 22:18:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660515518;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660515518;}', 0, 1, '2022-08-14 22:52:08', '2022-08-14 22:52:08', 0, NULL),
(528, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-14 22:52:08', '2022-08-14 22:52:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660517528;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660517528;}', 0, 1, '2022-08-14 22:52:18', '2022-08-14 22:52:18', 0, NULL),
(529, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 01:40:28', '2022-08-15 01:40:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660527628;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660527628;}', 0, 1, '2022-08-15 01:46:49', '2022-08-15 01:46:49', 0, NULL),
(530, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 01:46:49', '2022-08-15 01:46:49', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660528009;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660528009;}', 0, 1, '2022-08-15 01:47:54', '2022-08-15 01:47:54', 0, NULL),
(531, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 07:34:38', '2022-08-15 07:34:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660548878;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660548878;}', 0, 1, '2022-08-15 07:34:38', '2022-08-15 07:34:38', 0, NULL),
(532, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-15 07:44:52', '2022-08-15 07:44:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660549492;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660549492;}', 0, 1, '2022-08-15 07:45:23', '2022-08-15 07:45:23', 0, NULL),
(533, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 07:44:52', '2022-08-15 07:44:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660549492;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660549492;}', 0, 1, '2022-08-15 07:45:23', '2022-08-15 07:45:23', 0, NULL),
(534, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 08:55:25', '2022-08-15 08:55:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660553725;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660553725;}', 0, 1, '2022-08-15 09:13:37', '2022-08-15 09:13:37', 0, NULL),
(535, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 10:13:14', '2022-08-15 10:13:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660558394;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660558394;}', 0, 1, '2022-08-15 10:23:48', '2022-08-15 10:23:48', 0, NULL),
(536, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 12:41:08', '2022-08-15 12:41:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660567268;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660567268;}', 0, 1, '2022-08-15 13:47:20', '2022-08-15 13:47:20', 0, NULL),
(537, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 13:47:20', '2022-08-15 13:47:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660571240;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660571240;}', 0, 1, '2022-08-15 15:37:47', '2022-08-15 15:37:47', 0, NULL),
(538, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 15:37:56', '2022-08-15 15:37:56', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660577876;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660577876;}', 0, 1, '2022-08-15 15:56:41', '2022-08-15 15:56:41', 0, NULL),
(539, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 15:56:41', '2022-08-15 15:56:41', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660579001;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660579001;}', 0, 1, '2022-08-15 15:57:48', '2022-08-15 15:57:48', 0, NULL),
(540, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 17:06:36', '2022-08-15 17:06:36', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660583196;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660583196;}', 0, 1, '2022-08-15 17:15:39', '2022-08-15 17:15:39', 0, NULL),
(541, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 18:03:01', '2022-08-15 18:03:01', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660586581;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660586581;}', 0, 1, '2022-08-15 18:45:15', '2022-08-15 18:45:15', 0, NULL),
(542, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 18:45:15', '2022-08-15 18:45:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660589115;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660589115;}', 0, 1, '2022-08-15 19:35:33', '2022-08-15 19:35:33', 0, NULL),
(543, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 21:18:55', '2022-08-15 21:18:55', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660598335;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660598335;}', 0, 1, '2022-08-15 21:38:24', '2022-08-15 21:38:24', 0, NULL),
(544, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-15 22:11:14', '2022-08-15 22:11:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660601474;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660601474;}', 0, 1, '2022-08-15 22:41:44', '2022-08-15 22:41:44', 0, NULL),
(545, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 00:28:18', '2022-08-16 00:28:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660609698;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660609698;}', 0, 1, '2022-08-16 01:49:12', '2022-08-16 01:49:12', 0, NULL),
(546, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 01:49:12', '2022-08-16 01:49:12', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660614552;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660614552;}', 0, 1, '2022-08-16 02:47:36', '2022-08-16 02:47:36', 0, NULL),
(547, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 02:47:46', '2022-08-16 02:47:46', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660618066;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660618066;}', 0, 1, '2022-08-16 02:52:38', '2022-08-16 02:52:38', 0, NULL),
(548, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 04:04:45', '2022-08-16 04:04:45', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660622685;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660622685;}', 0, 1, '2022-08-16 04:04:45', '2022-08-16 04:04:45', 0, NULL),
(549, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 05:20:53', '2022-08-16 05:20:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660627253;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660627253;}', 0, 1, '2022-08-16 06:49:56', '2022-08-16 06:49:56', 0, NULL),
(550, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 06:49:56', '2022-08-16 06:49:56', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660632596;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660632596;}', 0, 1, '2022-08-16 08:31:18', '2022-08-16 08:31:18', 0, NULL),
(551, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-16 08:31:18', '2022-08-16 08:31:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660638678;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660638678;}', 0, 1, '2022-08-16 10:30:12', '2022-08-16 10:30:12', 0, NULL),
(552, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 08:31:18', '2022-08-16 08:31:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660638678;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660638678;}', 0, 1, '2022-08-16 10:30:12', '2022-08-16 10:30:12', 0, NULL),
(553, 'wp_mail_smtp_summary_report_email', 'complete', '2022-08-23 10:30:12', '2022-08-23 10:30:12', '[1]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1661250612;s:18:\"\0*\0first_timestamp\";i:1657548000;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1661250612;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 2, 1, '2022-08-23 13:25:35', '2022-08-23 13:25:35', 0, NULL),
(554, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 10:30:12', '2022-08-16 10:30:12', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660645812;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660645812;}', 0, 1, '2022-08-16 10:30:34', '2022-08-16 10:30:34', 0, NULL),
(555, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 11:14:34', '2022-08-16 11:14:34', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660648474;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660648474;}', 0, 1, '2022-08-16 11:31:39', '2022-08-16 11:31:39', 0, NULL),
(556, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 11:49:16', '2022-08-16 11:49:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660650556;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660650556;}', 0, 1, '2022-08-16 12:23:17', '2022-08-16 12:23:17', 0, NULL),
(557, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 12:50:25', '2022-08-16 12:50:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660654225;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660654225;}', 0, 1, '2022-08-16 15:20:11', '2022-08-16 15:20:11', 0, NULL),
(558, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 15:20:11', '2022-08-16 15:20:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660663211;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660663211;}', 0, 1, '2022-08-16 15:27:08', '2022-08-16 15:27:08', 0, NULL),
(559, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 16:07:43', '2022-08-16 16:07:43', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660666063;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660666063;}', 0, 1, '2022-08-16 17:35:33', '2022-08-16 17:35:33', 0, NULL),
(560, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 17:35:33', '2022-08-16 17:35:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660671333;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660671333;}', 0, 1, '2022-08-16 18:55:38', '2022-08-16 18:55:38', 0, NULL),
(561, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-16 18:55:38', '2022-08-16 18:55:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660676138;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660676138;}', 0, 1, '2022-08-16 19:15:35', '2022-08-16 19:15:35', 0, NULL),
(562, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 00:56:43', '2022-08-17 00:56:43', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660697803;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660697803;}', 0, 1, '2022-08-17 01:27:44', '2022-08-17 01:27:44', 0, NULL),
(563, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 01:55:38', '2022-08-17 01:55:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660701338;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660701338;}', 0, 1, '2022-08-17 01:55:38', '2022-08-17 01:55:38', 0, NULL),
(564, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 02:46:30', '2022-08-17 02:46:30', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660704390;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660704390;}', 0, 1, '2022-08-17 03:39:02', '2022-08-17 03:39:02', 0, NULL),
(565, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 03:48:31', '2022-08-17 03:48:31', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660708111;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660708111;}', 0, 1, '2022-08-17 04:30:01', '2022-08-17 04:30:01', 0, NULL),
(566, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 04:44:46', '2022-08-17 04:44:46', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660711486;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660711486;}', 0, 1, '2022-08-17 04:46:26', '2022-08-17 04:46:26', 0, NULL),
(567, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 06:01:24', '2022-08-17 06:01:24', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660716084;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660716084;}', 0, 1, '2022-08-17 06:26:16', '2022-08-17 06:26:16', 0, NULL),
(568, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 07:32:30', '2022-08-17 07:32:30', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660721550;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660721550;}', 0, 1, '2022-08-17 07:44:12', '2022-08-17 07:44:12', 0, NULL),
(569, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-17 07:44:13', '2022-08-17 07:44:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660722253;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660722253;}', 0, 1, '2022-08-17 07:44:17', '2022-08-17 07:44:17', 0, NULL),
(570, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 07:44:13', '2022-08-17 07:44:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660722253;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660722253;}', 0, 1, '2022-08-17 07:44:17', '2022-08-17 07:44:17', 0, NULL),
(571, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 09:54:26', '2022-08-17 09:54:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660730066;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660730066;}', 0, 1, '2022-08-17 10:29:03', '2022-08-17 10:29:03', 0, NULL),
(572, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 11:22:31', '2022-08-17 11:22:31', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660735351;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660735351;}', 0, 1, '2022-08-17 13:12:23', '2022-08-17 13:12:23', 0, NULL),
(573, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 13:12:23', '2022-08-17 13:12:23', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660741943;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660741943;}', 0, 1, '2022-08-17 13:14:26', '2022-08-17 13:14:26', 0, NULL),
(574, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 14:04:57', '2022-08-17 14:04:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660745097;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660745097;}', 0, 1, '2022-08-17 15:12:00', '2022-08-17 15:12:00', 0, NULL),
(575, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 15:12:09', '2022-08-17 15:12:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660749129;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660749129;}', 0, 1, '2022-08-17 15:12:17', '2022-08-17 15:12:17', 0, NULL),
(576, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 16:55:44', '2022-08-17 16:55:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660755344;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660755344;}', 0, 1, '2022-08-17 18:14:03', '2022-08-17 18:14:03', 0, NULL),
(577, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 18:14:03', '2022-08-17 18:14:03', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660760043;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660760043;}', 0, 1, '2022-08-17 19:10:37', '2022-08-17 19:10:37', 0, NULL),
(578, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 19:10:37', '2022-08-17 19:10:37', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660763437;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660763437;}', 0, 1, '2022-08-17 21:20:18', '2022-08-17 21:20:18', 0, NULL),
(579, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 21:20:19', '2022-08-17 21:20:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660771219;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660771219;}', 0, 1, '2022-08-17 23:05:00', '2022-08-17 23:05:00', 0, NULL),
(580, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-17 23:05:00', '2022-08-17 23:05:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660777500;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660777500;}', 0, 1, '2022-08-17 23:21:57', '2022-08-17 23:21:57', 0, NULL),
(581, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 01:29:10', '2022-08-18 01:29:10', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660786150;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660786150;}', 0, 1, '2022-08-18 03:09:44', '2022-08-18 03:09:44', 0, NULL),
(582, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 03:09:45', '2022-08-18 03:09:45', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660792185;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660792185;}', 0, 1, '2022-08-18 03:10:22', '2022-08-18 03:10:22', 0, NULL),
(583, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 03:52:47', '2022-08-18 03:52:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660794767;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660794767;}', 0, 1, '2022-08-18 03:54:07', '2022-08-18 03:54:07', 0, NULL),
(584, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 07:53:25', '2022-08-18 07:53:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660809205;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660809205;}', 0, 1, '2022-08-18 07:53:25', '2022-08-18 07:53:25', 0, NULL),
(585, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-18 07:53:26', '2022-08-18 07:53:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660809206;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660809206;}', 0, 1, '2022-08-18 07:53:30', '2022-08-18 07:53:30', 0, NULL),
(586, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 10:25:13', '2022-08-18 10:25:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660818313;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660818313;}', 0, 1, '2022-08-18 11:34:08', '2022-08-18 11:34:08', 0, NULL),
(587, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 11:34:08', '2022-08-18 11:34:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660822448;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660822448;}', 0, 1, '2022-08-18 11:56:30', '2022-08-18 11:56:30', 0, NULL),
(588, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 11:56:30', '2022-08-18 11:56:30', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660823790;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660823790;}', 0, 1, '2022-08-18 12:25:37', '2022-08-18 12:25:37', 0, NULL),
(589, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 13:14:58', '2022-08-18 13:14:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660828498;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660828498;}', 0, 1, '2022-08-18 14:28:35', '2022-08-18 14:28:35', 0, NULL),
(590, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 14:28:35', '2022-08-18 14:28:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660832915;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660832915;}', 0, 1, '2022-08-18 15:01:46', '2022-08-18 15:01:46', 0, NULL),
(591, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 15:01:54', '2022-08-18 15:01:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660834914;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660834914;}', 0, 1, '2022-08-18 15:23:28', '2022-08-18 15:23:28', 0, NULL),
(592, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 16:58:20', '2022-08-18 16:58:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660841900;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660841900;}', 0, 1, '2022-08-18 18:31:20', '2022-08-18 18:31:20', 0, NULL),
(593, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 18:31:20', '2022-08-18 18:31:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660847480;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660847480;}', 0, 1, '2022-08-18 20:56:15', '2022-08-18 20:56:15', 0, NULL),
(594, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 20:56:15', '2022-08-18 20:56:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660856175;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660856175;}', 0, 1, '2022-08-18 23:31:48', '2022-08-18 23:31:48', 0, NULL),
(595, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-18 23:31:48', '2022-08-18 23:31:48', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660865508;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660865508;}', 0, 1, '2022-08-19 00:03:14', '2022-08-19 00:03:14', 0, NULL),
(596, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 00:03:14', '2022-08-19 00:03:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660867394;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660867394;}', 0, 1, '2022-08-19 04:11:35', '2022-08-19 04:11:35', 0, NULL),
(597, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 04:11:35', '2022-08-19 04:11:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660882295;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660882295;}', 0, 1, '2022-08-19 04:14:16', '2022-08-19 04:14:16', 0, NULL),
(598, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 05:36:34', '2022-08-19 05:36:34', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660887394;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660887394;}', 0, 1, '2022-08-19 06:11:29', '2022-08-19 06:11:29', 0, NULL),
(599, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 06:11:29', '2022-08-19 06:11:29', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660889489;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660889489;}', 0, 1, '2022-08-19 06:27:48', '2022-08-19 06:27:48', 0, NULL),
(600, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 07:26:14', '2022-08-19 07:26:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660893974;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660893974;}', 0, 1, '2022-08-19 07:27:05', '2022-08-19 07:27:05', 0, NULL),
(601, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-19 09:40:29', '2022-08-19 09:40:29', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660902029;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660902029;}', 0, 1, '2022-08-19 11:05:20', '2022-08-19 11:05:20', 0, NULL),
(602, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 09:40:29', '2022-08-19 09:40:29', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660902029;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660902029;}', 0, 1, '2022-08-19 11:05:20', '2022-08-19 11:05:20', 0, NULL),
(603, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 11:05:20', '2022-08-19 11:05:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660907120;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660907120;}', 0, 1, '2022-08-19 11:27:14', '2022-08-19 11:27:14', 0, NULL),
(604, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 12:24:39', '2022-08-19 12:24:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660911879;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660911879;}', 0, 1, '2022-08-19 12:37:43', '2022-08-19 12:37:43', 0, NULL),
(605, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 13:52:03', '2022-08-19 13:52:03', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660917123;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660917123;}', 0, 1, '2022-08-19 14:10:23', '2022-08-19 14:10:23', 0, NULL),
(606, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 15:17:34', '2022-08-19 15:17:34', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660922254;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660922254;}', 0, 1, '2022-08-19 15:30:56', '2022-08-19 15:30:56', 0, NULL),
(607, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 18:28:46', '2022-08-19 18:28:46', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660933726;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660933726;}', 0, 1, '2022-08-19 19:09:09', '2022-08-19 19:09:09', 0, NULL),
(608, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 19:09:09', '2022-08-19 19:09:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660936149;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660936149;}', 0, 1, '2022-08-19 22:01:20', '2022-08-19 22:01:20', 0, NULL),
(609, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 22:01:20', '2022-08-19 22:01:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660946480;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660946480;}', 0, 1, '2022-08-19 22:52:53', '2022-08-19 22:52:53', 0, NULL),
(610, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 22:52:53', '2022-08-19 22:52:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660949573;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660949573;}', 0, 1, '2022-08-19 23:43:47', '2022-08-19 23:43:47', 0, NULL),
(611, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-19 23:43:47', '2022-08-19 23:43:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660952627;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660952627;}', 0, 1, '2022-08-20 00:12:31', '2022-08-20 00:12:31', 0, NULL),
(612, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 01:50:58', '2022-08-20 01:50:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660960258;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660960258;}', 0, 1, '2022-08-20 02:35:38', '2022-08-20 02:35:38', 0, NULL),
(613, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 05:13:23', '2022-08-20 05:13:23', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660972403;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660972403;}', 0, 1, '2022-08-20 06:12:28', '2022-08-20 06:12:28', 0, NULL),
(614, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 06:12:28', '2022-08-20 06:12:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660975948;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660975948;}', 0, 1, '2022-08-20 06:50:05', '2022-08-20 06:50:05', 0, NULL),
(615, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 06:50:05', '2022-08-20 06:50:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660978205;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660978205;}', 0, 1, '2022-08-20 07:26:39', '2022-08-20 07:26:39', 0, NULL),
(616, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-20 07:47:53', '2022-08-20 07:47:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660981673;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660981673;}', 0, 1, '2022-08-20 08:16:56', '2022-08-20 08:16:56', 0, NULL),
(617, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 07:47:53', '2022-08-20 07:47:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660981673;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660981673;}', 0, 1, '2022-08-20 08:16:56', '2022-08-20 08:16:56', 0, NULL),
(618, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 09:00:00', '2022-08-20 09:00:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660986000;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660986000;}', 0, 1, '2022-08-20 10:06:44', '2022-08-20 10:06:44', 0, NULL),
(619, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 10:06:44', '2022-08-20 10:06:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660990004;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660990004;}', 0, 1, '2022-08-20 11:23:21', '2022-08-20 11:23:21', 0, NULL),
(620, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 11:23:21', '2022-08-20 11:23:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660994601;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660994601;}', 0, 1, '2022-08-20 11:27:01', '2022-08-20 11:27:01', 0, NULL),
(621, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 13:26:02', '2022-08-20 13:26:02', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661001962;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661001962;}', 0, 1, '2022-08-20 15:04:32', '2022-08-20 15:04:32', 0, NULL),
(622, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 15:04:32', '2022-08-20 15:04:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661007872;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661007872;}', 0, 1, '2022-08-20 15:11:20', '2022-08-20 15:11:20', 0, NULL),
(623, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 15:59:39', '2022-08-20 15:59:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661011179;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661011179;}', 0, 1, '2022-08-20 18:29:53', '2022-08-20 18:29:53', 0, NULL),
(624, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 18:29:54', '2022-08-20 18:29:54', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661020194;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661020194;}', 0, 1, '2022-08-20 18:46:09', '2022-08-20 18:46:09', 0, NULL),
(625, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 18:46:09', '2022-08-20 18:46:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661021169;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661021169;}', 0, 1, '2022-08-20 21:37:50', '2022-08-20 21:37:50', 0, NULL),
(626, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-20 21:37:50', '2022-08-20 21:37:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661031470;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661031470;}', 0, 1, '2022-08-21 00:34:49', '2022-08-21 00:34:49', 0, NULL),
(627, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 00:34:49', '2022-08-21 00:34:49', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661042089;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661042089;}', 0, 1, '2022-08-21 00:43:21', '2022-08-21 00:43:21', 0, NULL),
(628, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 00:43:21', '2022-08-21 00:43:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661042601;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661042601;}', 0, 1, '2022-08-21 01:12:42', '2022-08-21 01:12:42', 0, NULL),
(629, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 02:37:09', '2022-08-21 02:37:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661049429;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661049429;}', 0, 1, '2022-08-21 02:44:22', '2022-08-21 02:44:22', 0, NULL),
(630, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 02:44:22', '2022-08-21 02:44:22', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661049862;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661049862;}', 0, 1, '2022-08-21 04:12:48', '2022-08-21 04:12:48', 0, NULL),
(631, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 04:12:48', '2022-08-21 04:12:48', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661055168;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661055168;}', 0, 1, '2022-08-21 04:14:11', '2022-08-21 04:14:11', 0, NULL),
(632, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 05:21:25', '2022-08-21 05:21:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661059285;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661059285;}', 0, 1, '2022-08-21 06:04:20', '2022-08-21 06:04:20', 0, NULL),
(633, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 06:04:20', '2022-08-21 06:04:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661061860;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661061860;}', 0, 1, '2022-08-21 06:11:28', '2022-08-21 06:11:28', 0, NULL),
(634, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 07:10:03', '2022-08-21 07:10:03', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661065803;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661065803;}', 0, 1, '2022-08-21 07:32:53', '2022-08-21 07:32:53', 0, NULL),
(635, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-21 08:32:16', '2022-08-21 08:32:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661070736;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661070736;}', 0, 1, '2022-08-21 09:00:13', '2022-08-21 09:00:13', 0, NULL),
(636, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 08:32:16', '2022-08-21 08:32:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661070736;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661070736;}', 0, 1, '2022-08-21 09:00:13', '2022-08-21 09:00:13', 0, NULL),
(637, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 09:00:13', '2022-08-21 09:00:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661072413;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661072413;}', 0, 1, '2022-08-21 09:00:30', '2022-08-21 09:00:30', 0, NULL),
(638, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 11:13:38', '2022-08-21 11:13:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661080418;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661080418;}', 0, 1, '2022-08-21 11:26:17', '2022-08-21 11:26:17', 0, NULL),
(639, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 12:14:27', '2022-08-21 12:14:27', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661084067;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661084067;}', 0, 1, '2022-08-21 12:15:21', '2022-08-21 12:15:21', 0, NULL),
(640, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 15:12:08', '2022-08-21 15:12:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661094728;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661094728;}', 0, 1, '2022-08-21 15:27:29', '2022-08-21 15:27:29', 0, NULL),
(641, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 16:20:08', '2022-08-21 16:20:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661098808;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661098808;}', 0, 1, '2022-08-21 16:20:08', '2022-08-21 16:20:08', 0, NULL),
(642, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 17:49:35', '2022-08-21 17:49:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661104175;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661104175;}', 0, 1, '2022-08-21 18:11:30', '2022-08-21 18:11:30', 0, NULL),
(643, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-21 21:13:56', '2022-08-21 21:13:56', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661116436;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661116436;}', 0, 1, '2022-08-22 00:24:42', '2022-08-22 00:24:42', 0, NULL),
(644, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 00:24:42', '2022-08-22 00:24:42', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661127882;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661127882;}', 0, 1, '2022-08-22 01:43:29', '2022-08-22 01:43:29', 0, NULL),
(645, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 01:43:29', '2022-08-22 01:43:29', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661132609;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661132609;}', 0, 1, '2022-08-22 02:13:17', '2022-08-22 02:13:17', 0, NULL),
(646, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 02:45:37', '2022-08-22 02:45:37', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661136337;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661136337;}', 0, 1, '2022-08-22 03:13:15', '2022-08-22 03:13:15', 0, NULL),
(647, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 04:58:50', '2022-08-22 04:58:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661144330;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661144330;}', 0, 1, '2022-08-22 04:59:16', '2022-08-22 04:59:16', 0, NULL),
(648, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 06:19:00', '2022-08-22 06:19:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661149140;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661149140;}', 0, 1, '2022-08-22 06:59:00', '2022-08-22 06:59:00', 0, NULL),
(649, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 06:59:00', '2022-08-22 06:59:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661151540;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661151540;}', 0, 1, '2022-08-22 07:06:16', '2022-08-22 07:06:16', 0, NULL),
(650, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-22 07:46:35', '2022-08-22 07:46:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661154395;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661154395;}', 0, 1, '2022-08-22 07:56:10', '2022-08-22 07:56:10', 0, NULL),
(651, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 07:46:35', '2022-08-22 07:46:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661154395;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661154395;}', 0, 1, '2022-08-22 07:56:10', '2022-08-22 07:56:10', 0, NULL),
(652, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 11:17:28', '2022-08-22 11:17:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661167048;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661167048;}', 0, 1, '2022-08-22 13:29:17', '2022-08-22 13:29:17', 0, NULL),
(653, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 13:29:17', '2022-08-22 13:29:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661174957;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661174957;}', 0, 1, '2022-08-22 13:33:48', '2022-08-22 13:33:48', 0, NULL),
(654, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 15:29:16', '2022-08-22 15:29:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661182156;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661182156;}', 0, 1, '2022-08-22 15:29:16', '2022-08-22 15:29:16', 0, NULL),
(655, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 16:56:57', '2022-08-22 16:56:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661187417;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661187417;}', 0, 1, '2022-08-22 18:02:39', '2022-08-22 18:02:39', 0, NULL),
(656, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 18:02:40', '2022-08-22 18:02:40', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661191360;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661191360;}', 0, 1, '2022-08-22 18:33:40', '2022-08-22 18:33:40', 0, NULL),
(657, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 18:50:00', '2022-08-22 18:50:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661194200;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661194200;}', 0, 1, '2022-08-22 20:08:56', '2022-08-22 20:08:56', 0, NULL),
(658, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 20:08:56', '2022-08-22 20:08:56', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661198936;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661198936;}', 0, 1, '2022-08-22 22:20:44', '2022-08-22 22:20:44', 0, NULL),
(659, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 22:20:44', '2022-08-22 22:20:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661206844;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661206844;}', 0, 1, '2022-08-22 22:31:50', '2022-08-22 22:31:50', 0, NULL),
(660, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-22 23:37:21', '2022-08-22 23:37:21', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661211441;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661211441;}', 0, 1, '2022-08-23 02:42:14', '2022-08-23 02:42:14', 0, NULL),
(661, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 02:42:14', '2022-08-23 02:42:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661222534;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661222534;}', 0, 1, '2022-08-23 03:01:18', '2022-08-23 03:01:18', 0, NULL),
(662, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 03:01:17', '2022-08-23 03:01:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661223677;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661223677;}', 0, 1, '2022-08-23 03:01:18', '2022-08-23 03:01:18', 0, NULL),
(663, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 04:13:04', '2022-08-23 04:13:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661227984;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661227984;}', 0, 1, '2022-08-23 04:13:23', '2022-08-23 04:13:23', 0, NULL),
(664, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 04:52:14', '2022-08-23 04:52:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661230334;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661230334;}', 0, 1, '2022-08-23 05:07:25', '2022-08-23 05:07:25', 0, NULL),
(665, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 05:43:59', '2022-08-23 05:43:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661233439;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661233439;}', 0, 1, '2022-08-23 05:44:36', '2022-08-23 05:44:36', 0, NULL),
(666, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 07:30:59', '2022-08-23 07:30:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661239859;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661239859;}', 0, 1, '2022-08-23 09:17:11', '2022-08-23 09:17:11', 0, NULL),
(667, 'facebook_for_woocommerce_daily_heartbeat', 'complete', '2022-08-23 09:17:11', '2022-08-23 09:17:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661246231;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661246231;}', 0, 1, '2022-08-23 13:25:35', '2022-08-23 13:25:35', 0, NULL),
(668, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 09:17:11', '2022-08-23 09:17:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661246231;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661246231;}', 0, 1, '2022-08-23 13:25:35', '2022-08-23 13:25:35', 0, NULL),
(669, 'wp_mail_smtp_summary_report_email', 'pending', '2022-08-30 13:25:35', '2022-08-30 13:25:35', '[1]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1661865935;s:18:\"\0*\0first_timestamp\";i:1657548000;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1661865935;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(670, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 13:25:35', '2022-08-23 13:25:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661261135;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661261135;}', 0, 1, '2022-08-23 13:33:55', '2022-08-23 13:33:55', 0, NULL),
(671, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 15:11:02', '2022-08-23 15:11:02', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661267462;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661267462;}', 0, 1, '2022-08-23 15:24:32', '2022-08-23 15:24:32', 0, NULL),
(672, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 15:50:49', '2022-08-23 15:50:49', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661269849;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661269849;}', 0, 1, '2022-08-23 15:59:27', '2022-08-23 15:59:27', 0, NULL),
(673, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 18:27:35', '2022-08-23 18:27:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661279255;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661279255;}', 0, 1, '2022-08-23 21:41:35', '2022-08-23 21:41:35', 0, NULL),
(674, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 21:41:35', '2022-08-23 21:41:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661290895;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661290895;}', 0, 1, '2022-08-23 22:24:08', '2022-08-23 22:24:08', 0, NULL),
(675, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 22:24:09', '2022-08-23 22:24:09', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661293449;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661293449;}', 0, 1, '2022-08-23 22:41:30', '2022-08-23 22:41:30', 0, NULL),
(676, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-23 23:30:58', '2022-08-23 23:30:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661297458;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661297458;}', 0, 1, '2022-08-24 00:54:43', '2022-08-24 00:54:43', 0, NULL),
(677, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-24 00:54:43', '2022-08-24 00:54:43', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661302483;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661302483;}', 0, 1, '2022-08-24 01:27:05', '2022-08-24 01:27:05', 0, NULL),
(678, 'facebook_for_woocommerce_hourly_heartbeat', 'complete', '2022-08-24 02:46:52', '2022-08-24 02:46:52', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661309212;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661309212;}', 0, 1, '2022-08-24 03:06:16', '2022-08-24 03:06:16', 0, NULL),
(679, 'facebook_for_woocommerce_hourly_heartbeat', 'pending', '2022-08-24 04:20:45', '2022-08-24 04:20:45', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1661314845;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1661314845;}', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_claims`
--

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;
CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint UNSIGNED NOT NULL,
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_groups`
--

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;
CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint UNSIGNED NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_groups`
--

INSERT INTO `wp_actionscheduler_groups` (`group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wp_mail_smtp');

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_logs`
--

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;
CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint UNSIGNED NOT NULL,
  `action_id` bigint UNSIGNED NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_logs`
--

INSERT INTO `wp_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(390, 200, 'action created', '2022-07-19 02:02:01', '2022-07-19 02:02:01'),
(451, 200, 'action started via WP Cron', '2022-07-26 07:44:55', '2022-07-26 07:44:55'),
(452, 200, 'action complete via WP Cron', '2022-07-26 07:44:58', '2022-07-26 07:44:58'),
(453, 221, 'action created', '2022-07-26 07:44:58', '2022-07-26 07:44:58'),
(454, 222, 'action created', '2022-07-26 07:44:58', '2022-07-26 07:44:58'),
(455, 223, 'action created', '2022-07-26 07:45:12', '2022-07-26 07:45:12'),
(456, 222, 'action started via WP Cron', '2022-07-26 07:45:15', '2022-07-26 07:45:15'),
(457, 222, 'action complete via WP Cron', '2022-07-26 07:45:15', '2022-07-26 07:45:15'),
(458, 223, 'action started via WP Cron', '2022-07-26 07:45:15', '2022-07-26 07:45:15'),
(459, 223, 'action complete via WP Cron', '2022-07-26 07:45:15', '2022-07-26 07:45:15'),
(460, 224, 'action created', '2022-07-26 08:56:06', '2022-07-26 08:56:06'),
(461, 224, 'action started via WP Cron', '2022-07-26 08:56:06', '2022-07-26 08:56:06'),
(462, 224, 'action complete via WP Cron', '2022-07-26 08:56:06', '2022-07-26 08:56:06'),
(463, 225, 'action created', '2022-07-26 09:48:42', '2022-07-26 09:48:42'),
(464, 225, 'action started via WP Cron', '2022-07-26 09:50:39', '2022-07-26 09:50:39'),
(465, 225, 'action complete via WP Cron', '2022-07-26 09:50:39', '2022-07-26 09:50:39'),
(466, 226, 'action created', '2022-07-26 11:39:01', '2022-07-26 11:39:01'),
(467, 226, 'action started via WP Cron', '2022-07-26 11:44:50', '2022-07-26 11:44:50'),
(468, 226, 'action complete via WP Cron', '2022-07-26 11:44:50', '2022-07-26 11:44:50'),
(469, 227, 'action created', '2022-07-26 11:44:50', '2022-07-26 11:44:50'),
(470, 227, 'action started via WP Cron', '2022-07-26 11:48:13', '2022-07-26 11:48:13'),
(471, 227, 'action complete via WP Cron', '2022-07-26 11:48:13', '2022-07-26 11:48:13'),
(472, 228, 'action created', '2022-07-27 02:01:32', '2022-07-27 02:01:32'),
(473, 228, 'action started via WP Cron', '2022-07-27 02:03:33', '2022-07-27 02:03:33'),
(474, 228, 'action complete via WP Cron', '2022-07-27 02:03:33', '2022-07-27 02:03:33'),
(475, 229, 'action created', '2022-07-27 07:10:36', '2022-07-27 07:10:36'),
(476, 229, 'action started via WP Cron', '2022-07-27 07:11:36', '2022-07-27 07:11:36'),
(477, 229, 'action complete via WP Cron', '2022-07-27 07:11:36', '2022-07-27 07:11:36'),
(478, 230, 'action created', '2022-07-27 07:43:24', '2022-07-27 07:43:24'),
(479, 231, 'action created', '2022-07-27 07:43:24', '2022-07-27 07:43:24'),
(480, 230, 'action started via WP Cron', '2022-07-27 07:43:24', '2022-07-27 07:43:24'),
(481, 230, 'action complete via WP Cron', '2022-07-27 07:43:24', '2022-07-27 07:43:24'),
(482, 231, 'action started via WP Cron', '2022-07-27 07:43:24', '2022-07-27 07:43:24'),
(483, 231, 'action complete via WP Cron', '2022-07-27 07:43:24', '2022-07-27 07:43:24'),
(484, 232, 'action created', '2022-07-27 08:43:23', '2022-07-27 08:43:23'),
(485, 232, 'action started via WP Cron', '2022-07-27 08:43:23', '2022-07-27 08:43:23'),
(486, 232, 'action complete via WP Cron', '2022-07-27 08:43:23', '2022-07-27 08:43:23'),
(487, 233, 'action created', '2022-07-27 09:43:17', '2022-07-27 09:43:17'),
(488, 233, 'action started via WP Cron', '2022-07-27 09:43:17', '2022-07-27 09:43:17'),
(489, 233, 'action complete via WP Cron', '2022-07-27 09:43:17', '2022-07-27 09:43:17'),
(490, 234, 'action created', '2022-07-27 10:43:17', '2022-07-27 10:43:17'),
(491, 234, 'action started via WP Cron', '2022-07-27 10:43:17', '2022-07-27 10:43:17'),
(492, 234, 'action complete via WP Cron', '2022-07-27 10:43:17', '2022-07-27 10:43:17'),
(493, 235, 'action created', '2022-07-27 11:56:15', '2022-07-27 11:56:15'),
(494, 235, 'action started via WP Cron', '2022-07-27 11:57:17', '2022-07-27 11:57:17'),
(495, 235, 'action complete via WP Cron', '2022-07-27 11:57:17', '2022-07-27 11:57:17'),
(496, 236, 'action created', '2022-07-27 12:43:17', '2022-07-27 12:43:17'),
(497, 236, 'action started via WP Cron', '2022-07-27 12:43:17', '2022-07-27 12:43:17'),
(498, 236, 'action complete via WP Cron', '2022-07-27 12:43:17', '2022-07-27 12:43:17'),
(499, 237, 'action created', '2022-07-27 13:56:10', '2022-07-27 13:56:10'),
(500, 237, 'action started via WP Cron', '2022-07-27 13:56:17', '2022-07-27 13:56:17'),
(501, 237, 'action complete via WP Cron', '2022-07-27 13:56:17', '2022-07-27 13:56:17'),
(502, 238, 'action created', '2022-07-27 14:43:17', '2022-07-27 14:43:17'),
(503, 238, 'action started via WP Cron', '2022-07-27 14:43:17', '2022-07-27 14:43:17'),
(504, 238, 'action complete via WP Cron', '2022-07-27 14:43:17', '2022-07-27 14:43:17'),
(505, 239, 'action created', '2022-07-27 15:43:17', '2022-07-27 15:43:17'),
(506, 239, 'action started via WP Cron', '2022-07-27 15:43:17', '2022-07-27 15:43:17'),
(507, 239, 'action complete via WP Cron', '2022-07-27 15:43:17', '2022-07-27 15:43:17'),
(508, 240, 'action created', '2022-07-28 04:18:15', '2022-07-28 04:18:15'),
(509, 240, 'action started via Async Request', '2022-07-28 04:18:54', '2022-07-28 04:18:54'),
(510, 240, 'action complete via Async Request', '2022-07-28 04:18:54', '2022-07-28 04:18:54'),
(511, 241, 'action created', '2022-07-28 04:49:18', '2022-07-28 04:49:18'),
(512, 241, 'action started via WP Cron', '2022-07-28 05:10:47', '2022-07-28 05:10:47'),
(513, 241, 'action complete via WP Cron', '2022-07-28 05:10:47', '2022-07-28 05:10:47'),
(514, 242, 'action created', '2022-07-28 05:43:55', '2022-07-28 05:43:55'),
(515, 242, 'action started via WP Cron', '2022-07-28 05:53:53', '2022-07-28 05:53:53'),
(516, 242, 'action complete via WP Cron', '2022-07-28 05:53:53', '2022-07-28 05:53:53'),
(517, 243, 'action created', '2022-07-28 07:26:22', '2022-07-28 07:26:22'),
(518, 243, 'action started via WP Cron', '2022-07-28 07:34:37', '2022-07-28 07:34:37'),
(519, 243, 'action complete via WP Cron', '2022-07-28 07:34:37', '2022-07-28 07:34:37'),
(520, 244, 'action created', '2022-07-28 07:43:15', '2022-07-28 07:43:15'),
(521, 245, 'action created', '2022-07-28 07:43:15', '2022-07-28 07:43:15'),
(522, 244, 'action started via WP Cron', '2022-07-28 07:43:15', '2022-07-28 07:43:15'),
(523, 244, 'action complete via WP Cron', '2022-07-28 07:43:15', '2022-07-28 07:43:15'),
(524, 245, 'action started via WP Cron', '2022-07-28 07:43:16', '2022-07-28 07:43:16'),
(525, 245, 'action complete via WP Cron', '2022-07-28 07:43:16', '2022-07-28 07:43:16'),
(526, 246, 'action created', '2022-07-28 09:21:43', '2022-07-28 09:21:43'),
(527, 246, 'action started via WP Cron', '2022-07-28 12:50:54', '2022-07-28 12:50:54'),
(528, 246, 'action complete via WP Cron', '2022-07-28 12:50:54', '2022-07-28 12:50:54'),
(529, 247, 'action created', '2022-07-28 12:50:54', '2022-07-28 12:50:54'),
(530, 247, 'action started via WP Cron', '2022-07-28 13:13:13', '2022-07-28 13:13:13'),
(531, 247, 'action complete via WP Cron', '2022-07-28 13:13:13', '2022-07-28 13:13:13'),
(532, 248, 'action created', '2022-07-28 14:19:21', '2022-07-28 14:19:21'),
(533, 248, 'action started via WP Cron', '2022-07-28 14:32:23', '2022-07-28 14:32:23'),
(534, 248, 'action complete via WP Cron', '2022-07-28 14:32:23', '2022-07-28 14:32:23'),
(535, 249, 'action created', '2022-07-28 14:43:40', '2022-07-28 14:43:40'),
(536, 249, 'action started via WP Cron', '2022-07-28 14:43:41', '2022-07-28 14:43:41'),
(537, 249, 'action complete via WP Cron', '2022-07-28 14:43:41', '2022-07-28 14:43:41'),
(538, 250, 'action created', '2022-07-28 23:46:10', '2022-07-28 23:46:10'),
(539, 250, 'action started via WP Cron', '2022-07-29 01:05:28', '2022-07-29 01:05:28'),
(540, 250, 'action complete via WP Cron', '2022-07-29 01:05:28', '2022-07-29 01:05:28'),
(541, 251, 'action created', '2022-07-29 01:05:28', '2022-07-29 01:05:28'),
(542, 251, 'action started via WP Cron', '2022-07-29 01:32:26', '2022-07-29 01:32:26'),
(543, 251, 'action complete via WP Cron', '2022-07-29 01:32:26', '2022-07-29 01:32:26'),
(544, 252, 'action created', '2022-07-29 01:56:20', '2022-07-29 01:56:20'),
(545, 252, 'action started via WP Cron', '2022-07-29 01:56:20', '2022-07-29 01:56:20'),
(546, 252, 'action complete via WP Cron', '2022-07-29 01:56:20', '2022-07-29 01:56:20'),
(547, 253, 'action created', '2022-07-29 02:43:14', '2022-07-29 02:43:14'),
(548, 253, 'action started via WP Cron', '2022-07-29 02:44:15', '2022-07-29 02:44:15'),
(549, 253, 'action complete via WP Cron', '2022-07-29 02:44:15', '2022-07-29 02:44:15'),
(550, 254, 'action created', '2022-07-29 04:58:32', '2022-07-29 04:58:32'),
(551, 254, 'action started via WP Cron', '2022-07-29 05:26:26', '2022-07-29 05:26:26'),
(552, 254, 'action complete via WP Cron', '2022-07-29 05:26:26', '2022-07-29 05:26:26'),
(553, 255, 'action created', '2022-07-29 07:55:54', '2022-07-29 07:55:54'),
(554, 255, 'action started via Async Request', '2022-07-29 07:55:54', '2022-07-29 07:55:54'),
(555, 255, 'action complete via Async Request', '2022-07-29 07:55:54', '2022-07-29 07:55:54'),
(556, 256, 'action created', '2022-07-29 07:55:55', '2022-07-29 07:55:55'),
(557, 256, 'action started via Async Request', '2022-07-29 07:56:00', '2022-07-29 07:56:00'),
(558, 256, 'action complete via Async Request', '2022-07-29 07:56:00', '2022-07-29 07:56:00'),
(559, 257, 'action created', '2022-07-29 10:33:38', '2022-07-29 10:33:38'),
(560, 257, 'action started via WP Cron', '2022-07-29 11:08:12', '2022-07-29 11:08:12'),
(561, 257, 'action complete via WP Cron', '2022-07-29 11:08:12', '2022-07-29 11:08:12'),
(562, 258, 'action created', '2022-07-29 11:08:12', '2022-07-29 11:08:12'),
(563, 258, 'action started via WP Cron', '2022-07-29 13:16:06', '2022-07-29 13:16:06'),
(564, 258, 'action complete via WP Cron', '2022-07-29 13:16:06', '2022-07-29 13:16:06'),
(565, 259, 'action created', '2022-07-29 13:16:06', '2022-07-29 13:16:06'),
(566, 259, 'action started via WP Cron', '2022-07-29 13:58:41', '2022-07-29 13:58:41'),
(567, 259, 'action complete via WP Cron', '2022-07-29 13:58:41', '2022-07-29 13:58:41'),
(568, 260, 'action created', '2022-07-29 13:58:41', '2022-07-29 13:58:41'),
(569, 260, 'action started via WP Cron', '2022-07-29 19:38:21', '2022-07-29 19:38:21'),
(570, 260, 'action complete via WP Cron', '2022-07-29 19:38:21', '2022-07-29 19:38:21'),
(571, 261, 'action created', '2022-07-29 19:38:29', '2022-07-29 19:38:29'),
(572, 261, 'action started via WP Cron', '2022-07-29 23:26:39', '2022-07-29 23:26:39'),
(573, 261, 'action complete via WP Cron', '2022-07-29 23:26:39', '2022-07-29 23:26:39'),
(574, 262, 'action created', '2022-07-29 23:26:39', '2022-07-29 23:26:39'),
(575, 262, 'action started via WP Cron', '2022-07-30 01:51:17', '2022-07-30 01:51:17'),
(576, 262, 'action complete via WP Cron', '2022-07-30 01:51:17', '2022-07-30 01:51:17'),
(577, 263, 'action created', '2022-07-30 01:51:17', '2022-07-30 01:51:17'),
(578, 263, 'action started via WP Cron', '2022-07-30 02:55:59', '2022-07-30 02:55:59'),
(579, 263, 'action complete via WP Cron', '2022-07-30 02:55:59', '2022-07-30 02:55:59'),
(580, 264, 'action created', '2022-07-30 02:56:07', '2022-07-30 02:56:07'),
(581, 264, 'action started via WP Cron', '2022-07-30 04:08:09', '2022-07-30 04:08:09'),
(582, 264, 'action complete via WP Cron', '2022-07-30 04:08:09', '2022-07-30 04:08:09'),
(583, 265, 'action created', '2022-07-30 04:08:09', '2022-07-30 04:08:09'),
(584, 265, 'action started via WP Cron', '2022-07-30 04:19:05', '2022-07-30 04:19:05'),
(585, 265, 'action complete via WP Cron', '2022-07-30 04:19:05', '2022-07-30 04:19:05'),
(586, 266, 'action created', '2022-07-30 05:51:07', '2022-07-30 05:51:07'),
(587, 266, 'action started via WP Cron', '2022-07-30 05:54:02', '2022-07-30 05:54:02'),
(588, 266, 'action complete via WP Cron', '2022-07-30 05:54:02', '2022-07-30 05:54:02'),
(589, 267, 'action created', '2022-07-30 07:09:41', '2022-07-30 07:09:41'),
(590, 267, 'action started via WP Cron', '2022-07-30 08:08:51', '2022-07-30 08:08:51'),
(591, 267, 'action complete via WP Cron', '2022-07-30 08:08:51', '2022-07-30 08:08:51'),
(592, 268, 'action created', '2022-07-30 08:08:52', '2022-07-30 08:08:52'),
(593, 269, 'action created', '2022-07-30 08:08:52', '2022-07-30 08:08:52'),
(594, 268, 'action started via WP Cron', '2022-07-30 12:15:38', '2022-07-30 12:15:38'),
(595, 268, 'action complete via WP Cron', '2022-07-30 12:15:38', '2022-07-30 12:15:38'),
(596, 269, 'action started via WP Cron', '2022-07-30 12:15:38', '2022-07-30 12:15:38'),
(597, 269, 'action complete via WP Cron', '2022-07-30 12:15:38', '2022-07-30 12:15:38'),
(598, 270, 'action created', '2022-07-30 12:15:38', '2022-07-30 12:15:38'),
(599, 270, 'action started via WP Cron', '2022-07-30 13:13:56', '2022-07-30 13:13:56'),
(600, 270, 'action complete via WP Cron', '2022-07-30 13:13:57', '2022-07-30 13:13:57'),
(601, 271, 'action created', '2022-07-30 13:13:57', '2022-07-30 13:13:57'),
(602, 271, 'action started via WP Cron', '2022-07-30 13:30:10', '2022-07-30 13:30:10'),
(603, 271, 'action complete via WP Cron', '2022-07-30 13:30:10', '2022-07-30 13:30:10'),
(604, 272, 'action created', '2022-07-30 14:59:30', '2022-07-30 14:59:30'),
(605, 272, 'action started via WP Cron', '2022-07-30 16:45:31', '2022-07-30 16:45:31'),
(606, 272, 'action complete via WP Cron', '2022-07-30 16:45:31', '2022-07-30 16:45:31'),
(607, 273, 'action created', '2022-07-30 16:45:31', '2022-07-30 16:45:31'),
(608, 273, 'action started via WP Cron', '2022-07-30 18:38:30', '2022-07-30 18:38:30'),
(609, 273, 'action complete via WP Cron', '2022-07-30 18:38:31', '2022-07-30 18:38:31'),
(610, 274, 'action created', '2022-07-30 18:38:31', '2022-07-30 18:38:31'),
(611, 274, 'action started via WP Cron', '2022-07-30 22:27:08', '2022-07-30 22:27:08'),
(612, 274, 'action complete via WP Cron', '2022-07-30 22:27:08', '2022-07-30 22:27:08'),
(613, 275, 'action created', '2022-07-30 22:27:08', '2022-07-30 22:27:08'),
(614, 275, 'action started via WP Cron', '2022-07-30 23:37:10', '2022-07-30 23:37:10'),
(615, 275, 'action complete via WP Cron', '2022-07-30 23:37:10', '2022-07-30 23:37:10'),
(616, 276, 'action created', '2022-07-30 23:37:10', '2022-07-30 23:37:10'),
(617, 276, 'action started via WP Cron', '2022-07-31 01:27:51', '2022-07-31 01:27:51'),
(618, 276, 'action complete via WP Cron', '2022-07-31 01:27:51', '2022-07-31 01:27:51'),
(619, 277, 'action created', '2022-07-31 01:27:51', '2022-07-31 01:27:51'),
(620, 277, 'action started via WP Cron', '2022-07-31 03:21:18', '2022-07-31 03:21:18'),
(621, 277, 'action complete via WP Cron', '2022-07-31 03:21:18', '2022-07-31 03:21:18'),
(622, 278, 'action created', '2022-07-31 03:21:18', '2022-07-31 03:21:18'),
(623, 278, 'action started via WP Cron', '2022-07-31 03:23:22', '2022-07-31 03:23:22'),
(624, 278, 'action complete via WP Cron', '2022-07-31 03:23:22', '2022-07-31 03:23:22'),
(625, 279, 'action created', '2022-07-31 05:56:25', '2022-07-31 05:56:25'),
(626, 279, 'action started via WP Cron', '2022-07-31 08:15:19', '2022-07-31 08:15:19'),
(627, 279, 'action complete via WP Cron', '2022-07-31 08:15:19', '2022-07-31 08:15:19'),
(628, 280, 'action created', '2022-07-31 08:15:19', '2022-07-31 08:15:19'),
(629, 280, 'action started via Async Request', '2022-07-31 08:15:19', '2022-07-31 08:15:19'),
(630, 280, 'action complete via Async Request', '2022-07-31 08:15:19', '2022-07-31 08:15:19'),
(631, 281, 'action created', '2022-07-31 08:15:20', '2022-07-31 08:15:20'),
(632, 281, 'action started via Async Request', '2022-07-31 08:15:25', '2022-07-31 08:15:25'),
(633, 281, 'action complete via Async Request', '2022-07-31 08:15:25', '2022-07-31 08:15:25'),
(634, 282, 'action created', '2022-07-31 09:22:15', '2022-07-31 09:22:15'),
(635, 282, 'action started via WP Cron', '2022-07-31 09:24:38', '2022-07-31 09:24:38'),
(636, 282, 'action complete via WP Cron', '2022-07-31 09:24:38', '2022-07-31 09:24:38'),
(637, 283, 'action created', '2022-07-31 09:54:04', '2022-07-31 09:54:04'),
(638, 283, 'action started via WP Cron', '2022-07-31 10:02:49', '2022-07-31 10:02:49'),
(639, 283, 'action complete via WP Cron', '2022-07-31 10:02:49', '2022-07-31 10:02:49'),
(640, 284, 'action created', '2022-07-31 11:45:24', '2022-07-31 11:45:24'),
(641, 284, 'action started via WP Cron', '2022-07-31 13:12:57', '2022-07-31 13:12:57'),
(642, 284, 'action complete via WP Cron', '2022-07-31 13:12:57', '2022-07-31 13:12:57'),
(643, 285, 'action created', '2022-07-31 13:12:58', '2022-07-31 13:12:58'),
(644, 285, 'action started via WP Cron', '2022-07-31 13:33:15', '2022-07-31 13:33:15'),
(645, 285, 'action complete via WP Cron', '2022-07-31 13:33:15', '2022-07-31 13:33:15'),
(646, 286, 'action created', '2022-07-31 18:12:44', '2022-07-31 18:12:44'),
(647, 286, 'action started via WP Cron', '2022-07-31 18:19:37', '2022-07-31 18:19:37'),
(648, 286, 'action complete via WP Cron', '2022-07-31 18:19:37', '2022-07-31 18:19:37'),
(649, 287, 'action created', '2022-07-31 19:51:35', '2022-07-31 19:51:35'),
(650, 287, 'action started via WP Cron', '2022-07-31 20:36:59', '2022-07-31 20:36:59'),
(651, 287, 'action complete via WP Cron', '2022-07-31 20:36:59', '2022-07-31 20:36:59'),
(652, 288, 'action created', '2022-07-31 22:30:40', '2022-07-31 22:30:40'),
(653, 288, 'action started via WP Cron', '2022-07-31 23:48:40', '2022-07-31 23:48:40'),
(654, 288, 'action complete via WP Cron', '2022-07-31 23:48:40', '2022-07-31 23:48:40'),
(655, 289, 'action created', '2022-07-31 23:48:40', '2022-07-31 23:48:40'),
(656, 289, 'action started via WP Cron', '2022-08-01 00:54:09', '2022-08-01 00:54:09'),
(657, 289, 'action complete via WP Cron', '2022-08-01 00:54:09', '2022-08-01 00:54:09'),
(658, 290, 'action created', '2022-08-01 00:54:09', '2022-08-01 00:54:09'),
(659, 290, 'action started via WP Cron', '2022-08-01 01:01:54', '2022-08-01 01:01:54'),
(660, 290, 'action complete via WP Cron', '2022-08-01 01:01:54', '2022-08-01 01:01:54'),
(661, 291, 'action created', '2022-08-01 02:45:39', '2022-08-01 02:45:39'),
(662, 291, 'action started via WP Cron', '2022-08-01 02:47:14', '2022-08-01 02:47:14'),
(663, 291, 'action complete via WP Cron', '2022-08-01 02:47:14', '2022-08-01 02:47:14'),
(664, 292, 'action created', '2022-08-01 03:43:39', '2022-08-01 03:43:39'),
(665, 292, 'action started via WP Cron', '2022-08-01 03:43:39', '2022-08-01 03:43:39'),
(666, 292, 'action complete via WP Cron', '2022-08-01 03:43:39', '2022-08-01 03:43:39'),
(667, 293, 'action created', '2022-08-01 04:43:39', '2022-08-01 04:43:39'),
(668, 293, 'action started via WP Cron', '2022-08-01 04:43:39', '2022-08-01 04:43:39'),
(669, 293, 'action complete via WP Cron', '2022-08-01 04:43:39', '2022-08-01 04:43:39'),
(670, 294, 'action created', '2022-08-01 05:53:33', '2022-08-01 05:53:33'),
(671, 294, 'action started via WP Cron', '2022-08-01 06:41:38', '2022-08-01 06:41:38'),
(672, 294, 'action complete via WP Cron', '2022-08-01 06:41:38', '2022-08-01 06:41:38'),
(673, 295, 'action created', '2022-08-01 06:46:46', '2022-08-01 06:46:46'),
(674, 295, 'action started via WP Cron', '2022-08-01 06:51:56', '2022-08-01 06:51:56'),
(675, 295, 'action complete via WP Cron', '2022-08-01 06:51:56', '2022-08-01 06:51:56'),
(676, 296, 'action created', '2022-08-01 07:59:11', '2022-08-01 07:59:11'),
(677, 297, 'action created', '2022-08-01 07:59:11', '2022-08-01 07:59:11'),
(678, 296, 'action started via WP Cron', '2022-08-01 07:59:15', '2022-08-01 07:59:15'),
(679, 296, 'action complete via WP Cron', '2022-08-01 07:59:15', '2022-08-01 07:59:15'),
(680, 297, 'action started via WP Cron', '2022-08-01 07:59:15', '2022-08-01 07:59:15'),
(681, 297, 'action complete via WP Cron', '2022-08-01 07:59:15', '2022-08-01 07:59:15'),
(682, 298, 'action created', '2022-08-01 09:22:51', '2022-08-01 09:22:51'),
(683, 298, 'action started via WP Cron', '2022-08-01 11:23:44', '2022-08-01 11:23:44'),
(684, 298, 'action complete via WP Cron', '2022-08-01 11:23:44', '2022-08-01 11:23:44'),
(685, 299, 'action created', '2022-08-01 11:23:44', '2022-08-01 11:23:44'),
(686, 299, 'action started via WP Cron', '2022-08-01 11:24:18', '2022-08-01 11:24:18'),
(687, 299, 'action complete via WP Cron', '2022-08-01 11:24:18', '2022-08-01 11:24:18'),
(688, 300, 'action created', '2022-08-01 11:57:03', '2022-08-01 11:57:03'),
(689, 300, 'action started via WP Cron', '2022-08-01 12:00:22', '2022-08-01 12:00:22'),
(690, 300, 'action complete via WP Cron', '2022-08-01 12:00:22', '2022-08-01 12:00:22'),
(691, 301, 'action created', '2022-08-01 13:00:04', '2022-08-01 13:00:04'),
(692, 301, 'action started via WP Cron', '2022-08-01 13:03:59', '2022-08-01 13:03:59'),
(693, 301, 'action complete via WP Cron', '2022-08-01 13:03:59', '2022-08-01 13:03:59'),
(694, 302, 'action created', '2022-08-01 20:00:36', '2022-08-01 20:00:36'),
(695, 302, 'action started via WP Cron', '2022-08-01 21:14:52', '2022-08-01 21:14:52'),
(696, 302, 'action complete via WP Cron', '2022-08-01 21:14:52', '2022-08-01 21:14:52'),
(697, 303, 'action created', '2022-08-01 21:14:52', '2022-08-01 21:14:52'),
(698, 303, 'action started via WP Cron', '2022-08-01 22:02:27', '2022-08-01 22:02:27'),
(699, 303, 'action complete via WP Cron', '2022-08-01 22:02:27', '2022-08-01 22:02:27'),
(700, 304, 'action created', '2022-08-01 22:02:27', '2022-08-01 22:02:27'),
(701, 304, 'action started via WP Cron', '2022-08-01 22:38:50', '2022-08-01 22:38:50'),
(702, 304, 'action complete via WP Cron', '2022-08-01 22:38:50', '2022-08-01 22:38:50'),
(703, 305, 'action created', '2022-08-02 01:41:05', '2022-08-02 01:41:05'),
(704, 305, 'action started via WP Cron', '2022-08-02 01:56:20', '2022-08-02 01:56:20'),
(705, 305, 'action complete via WP Cron', '2022-08-02 01:56:20', '2022-08-02 01:56:20'),
(706, 306, 'action created', '2022-08-02 01:56:20', '2022-08-02 01:56:20'),
(707, 306, 'action started via WP Cron', '2022-08-02 02:24:52', '2022-08-02 02:24:52'),
(708, 306, 'action complete via WP Cron', '2022-08-02 02:24:52', '2022-08-02 02:24:52'),
(709, 307, 'action created', '2022-08-02 02:46:38', '2022-08-02 02:46:38'),
(710, 307, 'action started via WP Cron', '2022-08-02 02:46:38', '2022-08-02 02:46:38'),
(711, 307, 'action complete via WP Cron', '2022-08-02 02:46:38', '2022-08-02 02:46:38'),
(712, 308, 'action created', '2022-08-02 05:55:30', '2022-08-02 05:55:30'),
(713, 308, 'action started via WP Cron', '2022-08-02 06:11:40', '2022-08-02 06:11:40'),
(714, 308, 'action complete via WP Cron', '2022-08-02 06:11:40', '2022-08-02 06:11:40'),
(715, 221, 'action started via WP Cron', '2022-08-02 08:39:09', '2022-08-02 08:39:09'),
(716, 221, 'action complete via WP Cron', '2022-08-02 08:39:09', '2022-08-02 08:39:09'),
(717, 309, 'action created', '2022-08-02 08:39:09', '2022-08-02 08:39:09'),
(718, 310, 'action created', '2022-08-02 08:39:09', '2022-08-02 08:39:09'),
(719, 310, 'action started via Async Request', '2022-08-02 08:39:10', '2022-08-02 08:39:10'),
(720, 310, 'action complete via Async Request', '2022-08-02 08:39:10', '2022-08-02 08:39:10'),
(721, 311, 'action created', '2022-08-02 08:39:11', '2022-08-02 08:39:11'),
(722, 311, 'action started via Async Request', '2022-08-02 08:39:15', '2022-08-02 08:39:15'),
(723, 311, 'action complete via Async Request', '2022-08-02 08:39:15', '2022-08-02 08:39:15'),
(724, 312, 'action created', '2022-08-02 09:03:50', '2022-08-02 09:03:50'),
(725, 312, 'action started via WP Cron', '2022-08-02 10:09:35', '2022-08-02 10:09:35'),
(726, 312, 'action complete via WP Cron', '2022-08-02 10:09:35', '2022-08-02 10:09:35'),
(727, 313, 'action created', '2022-08-02 10:09:35', '2022-08-02 10:09:35'),
(728, 313, 'action started via WP Cron', '2022-08-02 10:18:58', '2022-08-02 10:18:58'),
(729, 313, 'action complete via WP Cron', '2022-08-02 10:18:58', '2022-08-02 10:18:58'),
(730, 314, 'action created', '2022-08-02 11:34:32', '2022-08-02 11:34:32'),
(731, 314, 'action started via Async Request', '2022-08-02 11:34:48', '2022-08-02 11:34:48'),
(732, 314, 'action complete via Async Request', '2022-08-02 11:34:48', '2022-08-02 11:34:48'),
(733, 315, 'action created', '2022-08-02 12:10:15', '2022-08-02 12:10:15'),
(734, 315, 'action started via WP Cron', '2022-08-02 14:54:48', '2022-08-02 14:54:48'),
(735, 315, 'action complete via WP Cron', '2022-08-02 14:54:48', '2022-08-02 14:54:48'),
(736, 316, 'action created', '2022-08-02 14:54:48', '2022-08-02 14:54:48'),
(737, 316, 'action started via WP Cron', '2022-08-02 15:42:55', '2022-08-02 15:42:55'),
(738, 316, 'action complete via WP Cron', '2022-08-02 15:42:55', '2022-08-02 15:42:55'),
(739, 317, 'action created', '2022-08-02 16:28:36', '2022-08-02 16:28:36'),
(740, 317, 'action started via WP Cron', '2022-08-02 16:28:36', '2022-08-02 16:28:36'),
(741, 317, 'action complete via WP Cron', '2022-08-02 16:28:36', '2022-08-02 16:28:36'),
(742, 318, 'action created', '2022-08-02 16:54:50', '2022-08-02 16:54:50'),
(743, 318, 'action started via WP Cron', '2022-08-02 17:18:22', '2022-08-02 17:18:22'),
(744, 318, 'action complete via WP Cron', '2022-08-02 17:18:22', '2022-08-02 17:18:22'),
(745, 319, 'action created', '2022-08-02 18:17:27', '2022-08-02 18:17:27'),
(746, 319, 'action started via WP Cron', '2022-08-02 18:31:13', '2022-08-02 18:31:13'),
(747, 319, 'action complete via WP Cron', '2022-08-02 18:31:13', '2022-08-02 18:31:13'),
(748, 320, 'action created', '2022-08-02 22:11:08', '2022-08-02 22:11:08'),
(749, 320, 'action started via WP Cron', '2022-08-02 22:11:08', '2022-08-02 22:11:08'),
(750, 320, 'action complete via WP Cron', '2022-08-02 22:11:08', '2022-08-02 22:11:08'),
(751, 321, 'action created', '2022-08-03 01:35:14', '2022-08-03 01:35:14'),
(752, 321, 'action started via Async Request', '2022-08-03 01:35:21', '2022-08-03 01:35:21'),
(753, 321, 'action complete via Async Request', '2022-08-03 01:35:21', '2022-08-03 01:35:21'),
(754, 322, 'action created', '2022-08-03 02:15:14', '2022-08-03 02:15:14'),
(755, 322, 'action started via WP Cron', '2022-08-03 02:16:26', '2022-08-03 02:16:26'),
(756, 322, 'action complete via WP Cron', '2022-08-03 02:16:26', '2022-08-03 02:16:26'),
(757, 323, 'action created', '2022-08-03 02:43:13', '2022-08-03 02:43:13'),
(758, 323, 'action started via Async Request', '2022-08-03 02:43:14', '2022-08-03 02:43:14'),
(759, 323, 'action complete via Async Request', '2022-08-03 02:43:14', '2022-08-03 02:43:14'),
(760, 324, 'action created', '2022-08-03 03:43:13', '2022-08-03 03:43:13'),
(761, 324, 'action started via WP Cron', '2022-08-03 03:43:43', '2022-08-03 03:43:43'),
(762, 324, 'action complete via WP Cron', '2022-08-03 03:43:43', '2022-08-03 03:43:43'),
(763, 325, 'action created', '2022-08-03 06:08:05', '2022-08-03 06:08:05'),
(764, 325, 'action started via WP Cron', '2022-08-03 06:08:05', '2022-08-03 06:08:05'),
(765, 325, 'action complete via WP Cron', '2022-08-03 06:08:05', '2022-08-03 06:08:05'),
(766, 326, 'action created', '2022-08-03 07:23:33', '2022-08-03 07:23:33'),
(767, 326, 'action started via WP Cron', '2022-08-03 07:45:54', '2022-08-03 07:45:54'),
(768, 326, 'action complete via WP Cron', '2022-08-03 07:45:54', '2022-08-03 07:45:54'),
(769, 327, 'action created', '2022-08-03 07:45:54', '2022-08-03 07:45:54'),
(770, 328, 'action created', '2022-08-03 07:45:54', '2022-08-03 07:45:54'),
(771, 327, 'action started via WP Cron', '2022-08-03 07:49:27', '2022-08-03 07:49:27'),
(772, 327, 'action complete via WP Cron', '2022-08-03 07:49:27', '2022-08-03 07:49:27'),
(773, 328, 'action started via WP Cron', '2022-08-03 07:49:27', '2022-08-03 07:49:27'),
(774, 328, 'action complete via WP Cron', '2022-08-03 07:49:27', '2022-08-03 07:49:27'),
(775, 329, 'action created', '2022-08-03 09:22:15', '2022-08-03 09:22:15'),
(776, 329, 'action started via WP Cron', '2022-08-03 09:44:13', '2022-08-03 09:44:13'),
(777, 329, 'action complete via WP Cron', '2022-08-03 09:44:13', '2022-08-03 09:44:13'),
(778, 330, 'action created', '2022-08-03 09:44:13', '2022-08-03 09:44:13'),
(779, 330, 'action started via WP Cron', '2022-08-03 09:49:07', '2022-08-03 09:49:07'),
(780, 330, 'action complete via WP Cron', '2022-08-03 09:49:07', '2022-08-03 09:49:07'),
(781, 331, 'action created', '2022-08-03 10:54:47', '2022-08-03 10:54:47'),
(782, 331, 'action started via WP Cron', '2022-08-03 11:04:35', '2022-08-03 11:04:35'),
(783, 331, 'action complete via WP Cron', '2022-08-03 11:04:35', '2022-08-03 11:04:35'),
(784, 332, 'action created', '2022-08-03 11:43:27', '2022-08-03 11:43:27'),
(785, 332, 'action started via Async Request', '2022-08-03 11:53:48', '2022-08-03 11:53:48'),
(786, 332, 'action complete via Async Request', '2022-08-03 11:53:48', '2022-08-03 11:53:48'),
(787, 333, 'action created', '2022-08-03 13:18:57', '2022-08-03 13:18:57'),
(788, 333, 'action started via WP Cron', '2022-08-03 13:32:24', '2022-08-03 13:32:24'),
(789, 333, 'action complete via WP Cron', '2022-08-03 13:32:24', '2022-08-03 13:32:24'),
(790, 334, 'action created', '2022-08-03 14:03:47', '2022-08-03 14:03:47'),
(791, 334, 'action started via WP Cron', '2022-08-03 14:13:38', '2022-08-03 14:13:38'),
(792, 334, 'action complete via WP Cron', '2022-08-03 14:13:38', '2022-08-03 14:13:38'),
(793, 335, 'action created', '2022-08-03 14:49:57', '2022-08-03 14:49:57'),
(794, 335, 'action started via WP Cron', '2022-08-03 17:13:41', '2022-08-03 17:13:41'),
(795, 335, 'action complete via WP Cron', '2022-08-03 17:13:41', '2022-08-03 17:13:41'),
(796, 336, 'action created', '2022-08-03 17:13:41', '2022-08-03 17:13:41'),
(797, 336, 'action started via WP Cron', '2022-08-03 17:29:08', '2022-08-03 17:29:08'),
(798, 336, 'action complete via WP Cron', '2022-08-03 17:29:08', '2022-08-03 17:29:08'),
(799, 337, 'action created', '2022-08-03 18:24:26', '2022-08-03 18:24:26'),
(800, 337, 'action started via WP Cron', '2022-08-03 18:27:52', '2022-08-03 18:27:52'),
(801, 337, 'action complete via WP Cron', '2022-08-03 18:27:52', '2022-08-03 18:27:52'),
(802, 338, 'action created', '2022-08-03 19:58:30', '2022-08-03 19:58:30'),
(803, 338, 'action started via WP Cron', '2022-08-03 20:53:15', '2022-08-03 20:53:15'),
(804, 338, 'action complete via WP Cron', '2022-08-03 20:53:15', '2022-08-03 20:53:15'),
(805, 339, 'action created', '2022-08-03 20:53:15', '2022-08-03 20:53:15'),
(806, 339, 'action started via WP Cron', '2022-08-03 21:38:45', '2022-08-03 21:38:45'),
(807, 339, 'action complete via WP Cron', '2022-08-03 21:38:45', '2022-08-03 21:38:45'),
(808, 340, 'action created', '2022-08-03 22:33:31', '2022-08-03 22:33:31'),
(809, 340, 'action started via WP Cron', '2022-08-03 22:48:52', '2022-08-03 22:48:52'),
(810, 340, 'action complete via WP Cron', '2022-08-03 22:48:52', '2022-08-03 22:48:52'),
(811, 341, 'action created', '2022-08-03 22:48:52', '2022-08-03 22:48:52'),
(812, 341, 'action started via WP Cron', '2022-08-03 23:39:17', '2022-08-03 23:39:17'),
(813, 341, 'action complete via WP Cron', '2022-08-03 23:39:18', '2022-08-03 23:39:18'),
(814, 342, 'action created', '2022-08-03 23:49:26', '2022-08-03 23:49:26'),
(815, 342, 'action started via WP Cron', '2022-08-03 23:53:15', '2022-08-03 23:53:15'),
(816, 342, 'action complete via WP Cron', '2022-08-03 23:53:15', '2022-08-03 23:53:15'),
(817, 343, 'action created', '2022-08-04 00:52:09', '2022-08-04 00:52:09'),
(818, 343, 'action started via WP Cron', '2022-08-04 01:51:05', '2022-08-04 01:51:05'),
(819, 343, 'action complete via WP Cron', '2022-08-04 01:51:05', '2022-08-04 01:51:05'),
(820, 344, 'action created', '2022-08-04 01:51:05', '2022-08-04 01:51:05'),
(821, 344, 'action started via WP Cron', '2022-08-04 04:23:36', '2022-08-04 04:23:36'),
(822, 344, 'action complete via WP Cron', '2022-08-04 04:23:36', '2022-08-04 04:23:36'),
(823, 345, 'action created', '2022-08-04 04:23:45', '2022-08-04 04:23:45'),
(824, 345, 'action started via WP Cron', '2022-08-04 05:21:49', '2022-08-04 05:21:49'),
(825, 345, 'action complete via WP Cron', '2022-08-04 05:21:49', '2022-08-04 05:21:49'),
(826, 346, 'action created', '2022-08-04 05:21:49', '2022-08-04 05:21:49'),
(827, 346, 'action started via WP Cron', '2022-08-04 05:26:29', '2022-08-04 05:26:29'),
(828, 346, 'action complete via WP Cron', '2022-08-04 05:26:29', '2022-08-04 05:26:29'),
(829, 347, 'action created', '2022-08-04 06:00:01', '2022-08-04 06:00:01'),
(830, 347, 'action started via WP Cron', '2022-08-04 06:11:45', '2022-08-04 06:11:45'),
(831, 347, 'action complete via WP Cron', '2022-08-04 06:11:45', '2022-08-04 06:11:45'),
(832, 348, 'action created', '2022-08-04 06:57:54', '2022-08-04 06:57:54'),
(833, 348, 'action started via WP Cron', '2022-08-04 07:06:43', '2022-08-04 07:06:43'),
(834, 348, 'action complete via WP Cron', '2022-08-04 07:06:43', '2022-08-04 07:06:43'),
(835, 349, 'action created', '2022-08-04 07:44:17', '2022-08-04 07:44:17'),
(836, 350, 'action created', '2022-08-04 07:44:17', '2022-08-04 07:44:17'),
(837, 349, 'action started via WP Cron', '2022-08-04 09:43:06', '2022-08-04 09:43:06'),
(838, 349, 'action complete via WP Cron', '2022-08-04 09:43:06', '2022-08-04 09:43:06'),
(839, 350, 'action started via WP Cron', '2022-08-04 09:43:06', '2022-08-04 09:43:06'),
(840, 350, 'action complete via WP Cron', '2022-08-04 09:43:06', '2022-08-04 09:43:06'),
(841, 351, 'action created', '2022-08-04 09:43:06', '2022-08-04 09:43:06'),
(842, 352, 'action created', '2022-08-04 11:40:24', '2022-08-04 11:40:24'),
(843, 351, 'action started via WP Cron', '2022-08-04 11:40:24', '2022-08-04 11:40:24'),
(844, 351, 'action complete via WP Cron', '2022-08-04 11:40:24', '2022-08-04 11:40:24'),
(845, 352, 'action started via WP Cron', '2022-08-04 11:40:24', '2022-08-04 11:40:24'),
(846, 352, 'action complete via WP Cron', '2022-08-04 11:40:24', '2022-08-04 11:40:24'),
(847, 353, 'action created', '2022-08-04 11:53:55', '2022-08-04 11:53:55'),
(848, 353, 'action started via WP Cron', '2022-08-04 12:06:31', '2022-08-04 12:06:31'),
(849, 353, 'action complete via WP Cron', '2022-08-04 12:06:31', '2022-08-04 12:06:31'),
(850, 354, 'action created', '2022-08-04 13:08:21', '2022-08-04 13:08:21'),
(851, 354, 'action started via WP Cron', '2022-08-04 13:36:47', '2022-08-04 13:36:47'),
(852, 354, 'action complete via WP Cron', '2022-08-04 13:36:47', '2022-08-04 13:36:47'),
(853, 355, 'action created', '2022-08-04 14:02:04', '2022-08-04 14:02:04'),
(854, 355, 'action started via WP Cron', '2022-08-04 14:02:14', '2022-08-04 14:02:14'),
(855, 355, 'action complete via WP Cron', '2022-08-04 14:02:14', '2022-08-04 14:02:14'),
(856, 356, 'action created', '2022-08-04 16:01:28', '2022-08-04 16:01:28'),
(857, 356, 'action started via WP Cron', '2022-08-04 16:33:51', '2022-08-04 16:33:51'),
(858, 356, 'action complete via WP Cron', '2022-08-04 16:33:52', '2022-08-04 16:33:52'),
(859, 357, 'action created', '2022-08-04 17:37:49', '2022-08-04 17:37:49'),
(860, 357, 'action started via WP Cron', '2022-08-04 19:50:47', '2022-08-04 19:50:47'),
(861, 357, 'action complete via WP Cron', '2022-08-04 19:50:47', '2022-08-04 19:50:47'),
(862, 358, 'action created', '2022-08-04 19:50:47', '2022-08-04 19:50:47'),
(863, 358, 'action started via WP Cron', '2022-08-04 20:09:56', '2022-08-04 20:09:56'),
(864, 358, 'action complete via WP Cron', '2022-08-04 20:09:57', '2022-08-04 20:09:57'),
(865, 359, 'action created', '2022-08-04 21:54:50', '2022-08-04 21:54:50'),
(866, 359, 'action started via WP Cron', '2022-08-04 23:09:39', '2022-08-04 23:09:39'),
(867, 359, 'action complete via WP Cron', '2022-08-04 23:09:39', '2022-08-04 23:09:39'),
(868, 360, 'action created', '2022-08-04 23:09:39', '2022-08-04 23:09:39'),
(869, 360, 'action started via WP Cron', '2022-08-04 23:17:59', '2022-08-04 23:17:59'),
(870, 360, 'action complete via WP Cron', '2022-08-04 23:17:59', '2022-08-04 23:17:59'),
(871, 361, 'action created', '2022-08-05 00:11:07', '2022-08-05 00:11:07'),
(872, 361, 'action started via WP Cron', '2022-08-05 00:11:17', '2022-08-05 00:11:17'),
(873, 361, 'action complete via WP Cron', '2022-08-05 00:11:17', '2022-08-05 00:11:17'),
(874, 362, 'action created', '2022-08-05 01:30:14', '2022-08-05 01:30:14'),
(875, 362, 'action started via WP Cron', '2022-08-05 01:52:08', '2022-08-05 01:52:08'),
(876, 362, 'action complete via WP Cron', '2022-08-05 01:52:08', '2022-08-05 01:52:08'),
(877, 363, 'action created', '2022-08-05 01:52:08', '2022-08-05 01:52:08'),
(878, 363, 'action started via WP Cron', '2022-08-05 01:52:18', '2022-08-05 01:52:18'),
(879, 363, 'action complete via WP Cron', '2022-08-05 01:52:18', '2022-08-05 01:52:18'),
(880, 364, 'action created', '2022-08-05 02:43:34', '2022-08-05 02:43:34'),
(881, 364, 'action started via WP Cron', '2022-08-05 03:41:43', '2022-08-05 03:41:43'),
(882, 364, 'action complete via WP Cron', '2022-08-05 03:41:43', '2022-08-05 03:41:43'),
(883, 365, 'action created', '2022-08-05 03:45:57', '2022-08-05 03:45:57'),
(884, 365, 'action started via WP Cron', '2022-08-05 03:49:36', '2022-08-05 03:49:36'),
(885, 365, 'action complete via WP Cron', '2022-08-05 03:49:36', '2022-08-05 03:49:36'),
(886, 366, 'action created', '2022-08-05 05:09:35', '2022-08-05 05:09:35'),
(887, 366, 'action started via WP Cron', '2022-08-05 06:07:39', '2022-08-05 06:07:39'),
(888, 366, 'action complete via WP Cron', '2022-08-05 06:07:39', '2022-08-05 06:07:39'),
(889, 367, 'action created', '2022-08-05 06:07:39', '2022-08-05 06:07:39'),
(890, 367, 'action started via WP Cron', '2022-08-05 06:29:01', '2022-08-05 06:29:01'),
(891, 367, 'action complete via WP Cron', '2022-08-05 06:29:01', '2022-08-05 06:29:01'),
(892, 368, 'action created', '2022-08-05 06:46:30', '2022-08-05 06:46:30'),
(893, 368, 'action started via WP Cron', '2022-08-05 06:46:30', '2022-08-05 06:46:30'),
(894, 368, 'action complete via WP Cron', '2022-08-05 06:46:30', '2022-08-05 06:46:30'),
(895, 369, 'action created', '2022-08-05 07:44:22', '2022-08-05 07:44:22'),
(896, 370, 'action created', '2022-08-05 07:44:22', '2022-08-05 07:44:22'),
(897, 369, 'action started via WP Cron', '2022-08-05 07:44:22', '2022-08-05 07:44:22'),
(898, 369, 'action complete via WP Cron', '2022-08-05 07:44:22', '2022-08-05 07:44:22'),
(899, 370, 'action started via WP Cron', '2022-08-05 07:44:22', '2022-08-05 07:44:22'),
(900, 370, 'action complete via WP Cron', '2022-08-05 07:44:22', '2022-08-05 07:44:22'),
(901, 371, 'action created', '2022-08-05 09:08:12', '2022-08-05 09:08:12'),
(902, 371, 'action started via WP Cron', '2022-08-05 09:11:23', '2022-08-05 09:11:23'),
(903, 371, 'action complete via WP Cron', '2022-08-05 09:11:23', '2022-08-05 09:11:23'),
(904, 372, 'action created', '2022-08-05 09:50:10', '2022-08-05 09:50:10'),
(905, 372, 'action started via WP Cron', '2022-08-05 10:04:01', '2022-08-05 10:04:01'),
(906, 372, 'action complete via WP Cron', '2022-08-05 10:04:01', '2022-08-05 10:04:01'),
(907, 373, 'action created', '2022-08-05 10:54:28', '2022-08-05 10:54:28'),
(908, 373, 'action started via WP Cron', '2022-08-05 11:04:49', '2022-08-05 11:04:49'),
(909, 373, 'action complete via WP Cron', '2022-08-05 11:04:49', '2022-08-05 11:04:49'),
(910, 374, 'action created', '2022-08-05 11:52:53', '2022-08-05 11:52:53'),
(911, 374, 'action started via WP Cron', '2022-08-05 12:01:11', '2022-08-05 12:01:11'),
(912, 374, 'action complete via WP Cron', '2022-08-05 12:01:11', '2022-08-05 12:01:11'),
(913, 375, 'action created', '2022-08-05 13:15:21', '2022-08-05 13:15:21'),
(914, 375, 'action started via WP Cron', '2022-08-05 18:02:09', '2022-08-05 18:02:09'),
(915, 375, 'action complete via WP Cron', '2022-08-05 18:02:09', '2022-08-05 18:02:09'),
(916, 376, 'action created', '2022-08-05 18:02:09', '2022-08-05 18:02:09'),
(917, 376, 'action started via WP Cron', '2022-08-05 18:02:18', '2022-08-05 18:02:18'),
(918, 376, 'action complete via WP Cron', '2022-08-05 18:02:18', '2022-08-05 18:02:18'),
(919, 377, 'action created', '2022-08-06 00:29:45', '2022-08-06 00:29:45'),
(920, 377, 'action started via WP Cron', '2022-08-06 00:35:06', '2022-08-06 00:35:06'),
(921, 377, 'action complete via WP Cron', '2022-08-06 00:35:06', '2022-08-06 00:35:06'),
(922, 378, 'action created', '2022-08-06 02:46:57', '2022-08-06 02:46:57'),
(923, 378, 'action started via WP Cron', '2022-08-06 02:47:31', '2022-08-06 02:47:31'),
(924, 378, 'action complete via WP Cron', '2022-08-06 02:47:31', '2022-08-06 02:47:31'),
(925, 379, 'action created', '2022-08-06 06:02:26', '2022-08-06 06:02:26'),
(926, 379, 'action started via WP Cron', '2022-08-06 07:09:33', '2022-08-06 07:09:33'),
(927, 379, 'action complete via WP Cron', '2022-08-06 07:09:33', '2022-08-06 07:09:33'),
(928, 380, 'action created', '2022-08-06 07:09:34', '2022-08-06 07:09:34'),
(929, 380, 'action started via WP Cron', '2022-08-06 07:17:03', '2022-08-06 07:17:03'),
(930, 380, 'action complete via WP Cron', '2022-08-06 07:17:03', '2022-08-06 07:17:03'),
(931, 381, 'action created', '2022-08-06 11:47:36', '2022-08-06 11:47:36'),
(932, 382, 'action created', '2022-08-06 11:47:36', '2022-08-06 11:47:36'),
(933, 381, 'action started via WP Cron', '2022-08-06 12:04:50', '2022-08-06 12:04:50'),
(934, 381, 'action complete via WP Cron', '2022-08-06 12:04:51', '2022-08-06 12:04:51'),
(935, 382, 'action started via WP Cron', '2022-08-06 12:04:51', '2022-08-06 12:04:51'),
(936, 382, 'action complete via WP Cron', '2022-08-06 12:04:51', '2022-08-06 12:04:51'),
(937, 383, 'action created', '2022-08-06 12:59:36', '2022-08-06 12:59:36'),
(938, 383, 'action started via WP Cron', '2022-08-06 13:43:31', '2022-08-06 13:43:31'),
(939, 383, 'action complete via WP Cron', '2022-08-06 13:43:31', '2022-08-06 13:43:31'),
(940, 384, 'action created', '2022-08-06 13:43:32', '2022-08-06 13:43:32'),
(941, 384, 'action started via WP Cron', '2022-08-06 16:00:39', '2022-08-06 16:00:39'),
(942, 384, 'action complete via WP Cron', '2022-08-06 16:00:39', '2022-08-06 16:00:39'),
(943, 385, 'action created', '2022-08-06 16:00:48', '2022-08-06 16:00:48'),
(944, 385, 'action started via WP Cron', '2022-08-06 18:42:02', '2022-08-06 18:42:02'),
(945, 385, 'action complete via WP Cron', '2022-08-06 18:42:02', '2022-08-06 18:42:02'),
(946, 386, 'action created', '2022-08-06 18:42:02', '2022-08-06 18:42:02'),
(947, 386, 'action started via WP Cron', '2022-08-06 18:46:19', '2022-08-06 18:46:19'),
(948, 386, 'action complete via WP Cron', '2022-08-06 18:46:19', '2022-08-06 18:46:19'),
(949, 387, 'action created', '2022-08-06 18:46:19', '2022-08-06 18:46:19'),
(950, 387, 'action started via WP Cron', '2022-08-06 18:56:23', '2022-08-06 18:56:23'),
(951, 387, 'action complete via WP Cron', '2022-08-06 18:56:23', '2022-08-06 18:56:23'),
(952, 388, 'action created', '2022-08-06 19:51:23', '2022-08-06 19:51:23'),
(953, 388, 'action started via WP Cron', '2022-08-06 20:11:38', '2022-08-06 20:11:38'),
(954, 388, 'action complete via WP Cron', '2022-08-06 20:11:38', '2022-08-06 20:11:38'),
(955, 389, 'action created', '2022-08-06 23:53:00', '2022-08-06 23:53:00'),
(956, 389, 'action started via WP Cron', '2022-08-07 00:51:37', '2022-08-07 00:51:37'),
(957, 389, 'action complete via WP Cron', '2022-08-07 00:51:37', '2022-08-07 00:51:37'),
(958, 390, 'action created', '2022-08-07 00:51:38', '2022-08-07 00:51:38'),
(959, 390, 'action started via WP Cron', '2022-08-07 01:10:16', '2022-08-07 01:10:16'),
(960, 390, 'action complete via WP Cron', '2022-08-07 01:10:16', '2022-08-07 01:10:16'),
(961, 391, 'action created', '2022-08-07 01:58:52', '2022-08-07 01:58:52'),
(962, 391, 'action started via WP Cron', '2022-08-07 03:00:00', '2022-08-07 03:00:00'),
(963, 391, 'action complete via WP Cron', '2022-08-07 03:00:00', '2022-08-07 03:00:00'),
(964, 392, 'action created', '2022-08-07 03:00:08', '2022-08-07 03:00:08'),
(965, 392, 'action started via WP Cron', '2022-08-07 03:16:09', '2022-08-07 03:16:09'),
(966, 392, 'action complete via WP Cron', '2022-08-07 03:16:09', '2022-08-07 03:16:09'),
(967, 393, 'action created', '2022-08-07 04:19:04', '2022-08-07 04:19:04'),
(968, 393, 'action started via WP Cron', '2022-08-07 04:29:24', '2022-08-07 04:29:24'),
(969, 393, 'action complete via WP Cron', '2022-08-07 04:29:24', '2022-08-07 04:29:24'),
(970, 394, 'action created', '2022-08-07 06:00:14', '2022-08-07 06:00:14'),
(971, 394, 'action started via WP Cron', '2022-08-07 06:08:01', '2022-08-07 06:08:01'),
(972, 394, 'action complete via WP Cron', '2022-08-07 06:08:01', '2022-08-07 06:08:01'),
(973, 395, 'action created', '2022-08-07 06:57:34', '2022-08-07 06:57:34'),
(974, 395, 'action started via WP Cron', '2022-08-07 07:25:55', '2022-08-07 07:25:55'),
(975, 395, 'action complete via WP Cron', '2022-08-07 07:25:55', '2022-08-07 07:25:55'),
(976, 396, 'action created', '2022-08-07 08:15:46', '2022-08-07 08:15:46'),
(977, 397, 'action created', '2022-08-07 08:15:46', '2022-08-07 08:15:46'),
(978, 396, 'action started via WP Cron', '2022-08-07 09:17:33', '2022-08-07 09:17:33'),
(979, 396, 'action complete via WP Cron', '2022-08-07 09:17:33', '2022-08-07 09:17:33'),
(980, 397, 'action started via WP Cron', '2022-08-07 09:17:33', '2022-08-07 09:17:33'),
(981, 397, 'action complete via WP Cron', '2022-08-07 09:17:33', '2022-08-07 09:17:33'),
(982, 398, 'action created', '2022-08-07 09:17:33', '2022-08-07 09:17:33'),
(983, 398, 'action started via WP Cron', '2022-08-07 09:51:19', '2022-08-07 09:51:19'),
(984, 398, 'action complete via WP Cron', '2022-08-07 09:51:19', '2022-08-07 09:51:19'),
(985, 399, 'action created', '2022-08-07 09:51:19', '2022-08-07 09:51:19'),
(986, 399, 'action started via WP Cron', '2022-08-07 09:56:57', '2022-08-07 09:56:57'),
(987, 399, 'action complete via WP Cron', '2022-08-07 09:56:57', '2022-08-07 09:56:57'),
(988, 400, 'action created', '2022-08-07 10:44:11', '2022-08-07 10:44:11'),
(989, 400, 'action started via WP Cron', '2022-08-07 11:59:50', '2022-08-07 11:59:50'),
(990, 400, 'action complete via WP Cron', '2022-08-07 11:59:50', '2022-08-07 11:59:50'),
(991, 401, 'action created', '2022-08-07 11:59:50', '2022-08-07 11:59:50'),
(992, 401, 'action started via WP Cron', '2022-08-07 12:06:38', '2022-08-07 12:06:38'),
(993, 401, 'action complete via WP Cron', '2022-08-07 12:06:38', '2022-08-07 12:06:38'),
(994, 402, 'action created', '2022-08-07 13:01:44', '2022-08-07 13:01:44'),
(995, 402, 'action started via WP Cron', '2022-08-07 15:47:58', '2022-08-07 15:47:58'),
(996, 402, 'action complete via WP Cron', '2022-08-07 15:47:58', '2022-08-07 15:47:58'),
(997, 403, 'action created', '2022-08-07 15:47:58', '2022-08-07 15:47:58'),
(998, 403, 'action started via WP Cron', '2022-08-07 16:33:54', '2022-08-07 16:33:54'),
(999, 403, 'action complete via WP Cron', '2022-08-07 16:33:54', '2022-08-07 16:33:54'),
(1000, 404, 'action created', '2022-08-07 17:56:02', '2022-08-07 17:56:02'),
(1001, 404, 'action started via WP Cron', '2022-08-07 19:17:21', '2022-08-07 19:17:21'),
(1002, 404, 'action complete via WP Cron', '2022-08-07 19:17:21', '2022-08-07 19:17:21'),
(1003, 405, 'action created', '2022-08-07 19:17:21', '2022-08-07 19:17:21'),
(1004, 405, 'action started via WP Cron', '2022-08-07 20:01:12', '2022-08-07 20:01:12'),
(1005, 405, 'action complete via WP Cron', '2022-08-07 20:01:12', '2022-08-07 20:01:12'),
(1006, 406, 'action created', '2022-08-07 20:01:12', '2022-08-07 20:01:12'),
(1007, 406, 'action started via WP Cron', '2022-08-07 21:42:22', '2022-08-07 21:42:22'),
(1008, 406, 'action complete via WP Cron', '2022-08-07 21:42:22', '2022-08-07 21:42:22'),
(1009, 407, 'action created', '2022-08-07 21:42:22', '2022-08-07 21:42:22'),
(1010, 408, 'action created', '2022-08-07 21:43:23', '2022-08-07 21:43:23'),
(1011, 407, 'action started via WP Cron', '2022-08-07 21:43:23', '2022-08-07 21:43:23'),
(1012, 407, 'action complete via WP Cron', '2022-08-07 21:43:23', '2022-08-07 21:43:23'),
(1013, 408, 'action started via WP Cron', '2022-08-07 21:43:23', '2022-08-07 21:43:23'),
(1014, 408, 'action complete via WP Cron', '2022-08-07 21:43:23', '2022-08-07 21:43:23'),
(1015, 409, 'action created', '2022-08-07 22:59:21', '2022-08-07 22:59:21'),
(1016, 409, 'action started via WP Cron', '2022-08-07 23:07:12', '2022-08-07 23:07:12'),
(1017, 409, 'action complete via WP Cron', '2022-08-07 23:07:12', '2022-08-07 23:07:12'),
(1018, 410, 'action created', '2022-08-08 01:50:07', '2022-08-08 01:50:07'),
(1019, 410, 'action started via WP Cron', '2022-08-08 01:50:17', '2022-08-08 01:50:17'),
(1020, 410, 'action complete via WP Cron', '2022-08-08 01:50:17', '2022-08-08 01:50:17'),
(1021, 411, 'action created', '2022-08-08 03:29:22', '2022-08-08 03:29:22'),
(1022, 411, 'action started via WP Cron', '2022-08-08 04:15:40', '2022-08-08 04:15:40'),
(1023, 411, 'action complete via WP Cron', '2022-08-08 04:15:40', '2022-08-08 04:15:40'),
(1024, 412, 'action created', '2022-08-08 04:15:40', '2022-08-08 04:15:40'),
(1025, 412, 'action started via WP Cron', '2022-08-08 05:31:18', '2022-08-08 05:31:18'),
(1026, 412, 'action complete via WP Cron', '2022-08-08 05:31:18', '2022-08-08 05:31:18'),
(1027, 413, 'action created', '2022-08-08 05:31:18', '2022-08-08 05:31:18'),
(1028, 413, 'action started via WP Cron', '2022-08-08 05:59:16', '2022-08-08 05:59:16'),
(1029, 413, 'action complete via WP Cron', '2022-08-08 05:59:16', '2022-08-08 05:59:16'),
(1030, 414, 'action created', '2022-08-08 05:59:16', '2022-08-08 05:59:16'),
(1031, 414, 'action started via WP Cron', '2022-08-08 07:40:36', '2022-08-08 07:40:36'),
(1032, 414, 'action complete via WP Cron', '2022-08-08 07:40:36', '2022-08-08 07:40:36'),
(1033, 415, 'action created', '2022-08-08 07:40:36', '2022-08-08 07:40:36'),
(1034, 415, 'action started via Async Request', '2022-08-08 07:40:36', '2022-08-08 07:40:36'),
(1035, 415, 'action complete via Async Request', '2022-08-08 07:40:36', '2022-08-08 07:40:36'),
(1036, 416, 'action created', '2022-08-08 08:01:14', '2022-08-08 08:01:14'),
(1037, 417, 'action created', '2022-08-08 08:01:14', '2022-08-08 08:01:14'),
(1038, 416, 'action started via WP Cron', '2022-08-08 09:36:20', '2022-08-08 09:36:20'),
(1039, 416, 'action complete via WP Cron', '2022-08-08 09:36:20', '2022-08-08 09:36:20'),
(1040, 417, 'action started via WP Cron', '2022-08-08 09:36:20', '2022-08-08 09:36:20'),
(1041, 417, 'action complete via WP Cron', '2022-08-08 09:36:20', '2022-08-08 09:36:20'),
(1042, 418, 'action created', '2022-08-08 09:36:21', '2022-08-08 09:36:21'),
(1043, 418, 'action started via WP Cron', '2022-08-08 09:45:42', '2022-08-08 09:45:42'),
(1044, 418, 'action complete via WP Cron', '2022-08-08 09:45:42', '2022-08-08 09:45:42'),
(1045, 419, 'action created', '2022-08-08 09:45:42', '2022-08-08 09:45:42'),
(1046, 419, 'action started via WP Cron', '2022-08-08 11:55:54', '2022-08-08 11:55:54'),
(1047, 419, 'action complete via WP Cron', '2022-08-08 11:55:54', '2022-08-08 11:55:54'),
(1048, 420, 'action created', '2022-08-08 11:55:54', '2022-08-08 11:55:54'),
(1049, 420, 'action started via WP Cron', '2022-08-08 11:59:43', '2022-08-08 11:59:43'),
(1050, 420, 'action complete via WP Cron', '2022-08-08 11:59:43', '2022-08-08 11:59:43'),
(1051, 421, 'action created', '2022-08-08 13:02:17', '2022-08-08 13:02:17'),
(1052, 421, 'action started via Async Request', '2022-08-08 13:02:44', '2022-08-08 13:02:44'),
(1053, 421, 'action complete via Async Request', '2022-08-08 13:02:44', '2022-08-08 13:02:44'),
(1054, 422, 'action created', '2022-08-08 15:26:35', '2022-08-08 15:26:35'),
(1055, 422, 'action started via WP Cron', '2022-08-08 17:45:08', '2022-08-08 17:45:08'),
(1056, 422, 'action complete via WP Cron', '2022-08-08 17:45:08', '2022-08-08 17:45:08'),
(1057, 423, 'action created', '2022-08-08 17:45:08', '2022-08-08 17:45:08'),
(1058, 423, 'action started via WP Cron', '2022-08-08 17:45:18', '2022-08-08 17:45:18'),
(1059, 423, 'action complete via WP Cron', '2022-08-08 17:45:18', '2022-08-08 17:45:18'),
(1060, 424, 'action created', '2022-08-08 19:50:58', '2022-08-08 19:50:58'),
(1061, 424, 'action started via WP Cron', '2022-08-08 20:22:04', '2022-08-08 20:22:04'),
(1062, 424, 'action complete via WP Cron', '2022-08-08 20:22:04', '2022-08-08 20:22:04'),
(1063, 425, 'action created', '2022-08-09 00:52:08', '2022-08-09 00:52:08'),
(1064, 425, 'action started via WP Cron', '2022-08-09 01:10:28', '2022-08-09 01:10:28'),
(1065, 425, 'action complete via WP Cron', '2022-08-09 01:10:28', '2022-08-09 01:10:28'),
(1066, 426, 'action created', '2022-08-09 01:45:54', '2022-08-09 01:45:54'),
(1067, 426, 'action started via WP Cron', '2022-08-09 03:25:39', '2022-08-09 03:25:39'),
(1068, 426, 'action complete via WP Cron', '2022-08-09 03:25:39', '2022-08-09 03:25:39'),
(1069, 427, 'action created', '2022-08-09 03:25:50', '2022-08-09 03:25:50'),
(1070, 427, 'action started via WP Cron', '2022-08-09 03:41:57', '2022-08-09 03:41:57'),
(1071, 427, 'action complete via WP Cron', '2022-08-09 03:41:57', '2022-08-09 03:41:57'),
(1072, 428, 'action created', '2022-08-09 04:21:18', '2022-08-09 04:21:18'),
(1073, 428, 'action started via WP Cron', '2022-08-09 05:00:53', '2022-08-09 05:00:53'),
(1074, 428, 'action complete via WP Cron', '2022-08-09 05:00:53', '2022-08-09 05:00:53'),
(1075, 429, 'action created', '2022-08-09 05:00:53', '2022-08-09 05:00:53'),
(1076, 429, 'action started via WP Cron', '2022-08-09 05:55:26', '2022-08-09 05:55:26'),
(1077, 429, 'action complete via WP Cron', '2022-08-09 05:55:26', '2022-08-09 05:55:26'),
(1078, 430, 'action created', '2022-08-09 05:55:26', '2022-08-09 05:55:26'),
(1079, 430, 'action started via WP Cron', '2022-08-09 05:57:03', '2022-08-09 05:57:03'),
(1080, 430, 'action complete via WP Cron', '2022-08-09 05:57:03', '2022-08-09 05:57:03'),
(1081, 431, 'action created', '2022-08-09 07:42:03', '2022-08-09 07:42:03'),
(1082, 431, 'action started via Async Request', '2022-08-09 07:42:03', '2022-08-09 07:42:03'),
(1083, 431, 'action complete via Async Request', '2022-08-09 07:42:03', '2022-08-09 07:42:03'),
(1084, 432, 'action created', '2022-08-09 08:20:20', '2022-08-09 08:20:20'),
(1085, 433, 'action created', '2022-08-09 08:20:20', '2022-08-09 08:20:20'),
(1086, 432, 'action started via WP Cron', '2022-08-09 08:29:42', '2022-08-09 08:29:42'),
(1087, 432, 'action complete via WP Cron', '2022-08-09 08:29:42', '2022-08-09 08:29:42'),
(1088, 433, 'action started via WP Cron', '2022-08-09 08:29:42', '2022-08-09 08:29:42'),
(1089, 433, 'action complete via WP Cron', '2022-08-09 08:29:42', '2022-08-09 08:29:42'),
(1090, 309, 'action started via WP Cron', '2022-08-09 08:53:33', '2022-08-09 08:53:33'),
(1091, 309, 'action complete via WP Cron', '2022-08-09 08:53:33', '2022-08-09 08:53:33'),
(1092, 434, 'action created', '2022-08-09 08:53:33', '2022-08-09 08:53:33'),
(1093, 435, 'action created', '2022-08-09 08:53:33', '2022-08-09 08:53:33'),
(1094, 435, 'action started via WP Cron', '2022-08-09 08:59:42', '2022-08-09 08:59:42'),
(1095, 435, 'action complete via WP Cron', '2022-08-09 08:59:42', '2022-08-09 08:59:42'),
(1096, 436, 'action created', '2022-08-09 09:49:39', '2022-08-09 09:49:39'),
(1097, 436, 'action started via WP Cron', '2022-08-09 10:09:33', '2022-08-09 10:09:33'),
(1098, 436, 'action complete via WP Cron', '2022-08-09 10:09:33', '2022-08-09 10:09:33'),
(1099, 437, 'action created', '2022-08-09 11:36:13', '2022-08-09 11:36:13'),
(1100, 437, 'action started via WP Cron', '2022-08-09 11:36:23', '2022-08-09 11:36:23'),
(1101, 437, 'action complete via WP Cron', '2022-08-09 11:36:23', '2022-08-09 11:36:23'),
(1102, 438, 'action created', '2022-08-09 11:44:00', '2022-08-09 11:44:00'),
(1103, 438, 'action started via WP Cron', '2022-08-09 12:21:14', '2022-08-09 12:21:14'),
(1104, 438, 'action complete via WP Cron', '2022-08-09 12:21:14', '2022-08-09 12:21:14'),
(1105, 439, 'action created', '2022-08-09 13:01:18', '2022-08-09 13:01:18'),
(1106, 439, 'action started via WP Cron', '2022-08-09 13:51:32', '2022-08-09 13:51:32'),
(1107, 439, 'action complete via WP Cron', '2022-08-09 13:51:32', '2022-08-09 13:51:32'),
(1108, 440, 'action created', '2022-08-09 13:51:32', '2022-08-09 13:51:32'),
(1109, 440, 'action started via Async Request', '2022-08-09 13:51:45', '2022-08-09 13:51:45'),
(1110, 440, 'action complete via Async Request', '2022-08-09 13:51:45', '2022-08-09 13:51:45'),
(1111, 441, 'action created', '2022-08-09 15:05:19', '2022-08-09 15:05:19'),
(1112, 441, 'action started via WP Cron', '2022-08-09 16:02:27', '2022-08-09 16:02:27'),
(1113, 441, 'action complete via WP Cron', '2022-08-09 16:02:27', '2022-08-09 16:02:27'),
(1114, 442, 'action created', '2022-08-09 16:02:28', '2022-08-09 16:02:28'),
(1115, 442, 'action started via WP Cron', '2022-08-09 17:48:04', '2022-08-09 17:48:04'),
(1116, 442, 'action complete via WP Cron', '2022-08-09 17:48:04', '2022-08-09 17:48:04'),
(1117, 443, 'action created', '2022-08-09 17:48:05', '2022-08-09 17:48:05'),
(1118, 443, 'action started via WP Cron', '2022-08-09 17:48:15', '2022-08-09 17:48:15'),
(1119, 443, 'action complete via WP Cron', '2022-08-09 17:48:15', '2022-08-09 17:48:15'),
(1120, 444, 'action created', '2022-08-09 20:26:53', '2022-08-09 20:26:53'),
(1121, 444, 'action started via WP Cron', '2022-08-09 21:34:36', '2022-08-09 21:34:36'),
(1122, 444, 'action complete via WP Cron', '2022-08-09 21:34:36', '2022-08-09 21:34:36'),
(1123, 445, 'action created', '2022-08-09 21:34:36', '2022-08-09 21:34:36'),
(1124, 445, 'action started via WP Cron', '2022-08-09 22:56:39', '2022-08-09 22:56:39'),
(1125, 445, 'action complete via WP Cron', '2022-08-09 22:56:39', '2022-08-09 22:56:39'),
(1126, 446, 'action created', '2022-08-09 22:56:39', '2022-08-09 22:56:39'),
(1127, 446, 'action started via WP Cron', '2022-08-09 23:25:59', '2022-08-09 23:25:59'),
(1128, 446, 'action complete via WP Cron', '2022-08-09 23:25:59', '2022-08-09 23:25:59'),
(1129, 447, 'action created', '2022-08-10 01:54:31', '2022-08-10 01:54:31'),
(1130, 447, 'action started via WP Cron', '2022-08-10 04:05:34', '2022-08-10 04:05:34'),
(1131, 447, 'action complete via WP Cron', '2022-08-10 04:05:34', '2022-08-10 04:05:34'),
(1132, 448, 'action created', '2022-08-10 04:05:42', '2022-08-10 04:05:42'),
(1133, 448, 'action started via WP Cron', '2022-08-10 04:27:10', '2022-08-10 04:27:10'),
(1134, 448, 'action complete via WP Cron', '2022-08-10 04:27:10', '2022-08-10 04:27:10'),
(1135, 449, 'action created', '2022-08-10 07:47:37', '2022-08-10 07:47:37'),
(1136, 449, 'action started via Async Request', '2022-08-10 07:47:38', '2022-08-10 07:47:38'),
(1137, 449, 'action complete via Async Request', '2022-08-10 07:47:38', '2022-08-10 07:47:38'),
(1138, 450, 'action created', '2022-08-10 07:47:39', '2022-08-10 07:47:39'),
(1139, 450, 'action started via Async Request', '2022-08-10 07:47:43', '2022-08-10 07:47:43'),
(1140, 450, 'action complete via Async Request', '2022-08-10 07:47:43', '2022-08-10 07:47:43'),
(1141, 451, 'action created', '2022-08-10 08:57:13', '2022-08-10 08:57:13'),
(1142, 451, 'action started via WP Cron', '2022-08-10 09:01:15', '2022-08-10 09:01:15'),
(1143, 451, 'action complete via WP Cron', '2022-08-10 09:01:15', '2022-08-10 09:01:15'),
(1144, 452, 'action created', '2022-08-10 09:57:07', '2022-08-10 09:57:07'),
(1145, 452, 'action started via WP Cron', '2022-08-10 09:57:17', '2022-08-10 09:57:17'),
(1146, 452, 'action complete via WP Cron', '2022-08-10 09:57:17', '2022-08-10 09:57:17'),
(1147, 453, 'action created', '2022-08-10 12:15:15', '2022-08-10 12:15:15'),
(1148, 453, 'action started via WP Cron', '2022-08-10 12:28:27', '2022-08-10 12:28:27'),
(1149, 453, 'action complete via WP Cron', '2022-08-10 12:28:27', '2022-08-10 12:28:27'),
(1150, 454, 'action created', '2022-08-10 13:56:04', '2022-08-10 13:56:04'),
(1151, 454, 'action started via WP Cron', '2022-08-10 16:56:37', '2022-08-10 16:56:37'),
(1152, 454, 'action complete via WP Cron', '2022-08-10 16:56:37', '2022-08-10 16:56:37'),
(1153, 455, 'action created', '2022-08-10 16:56:45', '2022-08-10 16:56:45'),
(1154, 455, 'action started via WP Cron', '2022-08-10 17:25:26', '2022-08-10 17:25:26'),
(1155, 455, 'action complete via WP Cron', '2022-08-10 17:25:26', '2022-08-10 17:25:26'),
(1156, 456, 'action created', '2022-08-10 17:58:53', '2022-08-10 17:58:53'),
(1157, 456, 'action started via WP Cron', '2022-08-10 18:01:52', '2022-08-10 18:01:52'),
(1158, 456, 'action complete via WP Cron', '2022-08-10 18:01:52', '2022-08-10 18:01:52'),
(1159, 457, 'action created', '2022-08-10 20:26:33', '2022-08-10 20:26:33'),
(1160, 457, 'action started via WP Cron', '2022-08-10 21:53:39', '2022-08-10 21:53:39'),
(1161, 457, 'action complete via WP Cron', '2022-08-10 21:53:40', '2022-08-10 21:53:40'),
(1162, 458, 'action created', '2022-08-10 21:53:40', '2022-08-10 21:53:40'),
(1163, 458, 'action started via WP Cron', '2022-08-10 22:36:51', '2022-08-10 22:36:51'),
(1164, 458, 'action complete via WP Cron', '2022-08-10 22:36:51', '2022-08-10 22:36:51'),
(1165, 459, 'action created', '2022-08-10 22:59:00', '2022-08-10 22:59:00'),
(1166, 459, 'action started via WP Cron', '2022-08-10 23:28:04', '2022-08-10 23:28:04'),
(1167, 459, 'action complete via WP Cron', '2022-08-10 23:28:04', '2022-08-10 23:28:04'),
(1168, 460, 'action created', '2022-08-11 01:02:18', '2022-08-11 01:02:18'),
(1169, 460, 'action started via WP Cron', '2022-08-11 02:04:39', '2022-08-11 02:04:39'),
(1170, 460, 'action complete via WP Cron', '2022-08-11 02:04:39', '2022-08-11 02:04:39'),
(1171, 461, 'action created', '2022-08-11 02:04:39', '2022-08-11 02:04:39'),
(1172, 461, 'action started via WP Cron', '2022-08-11 03:56:33', '2022-08-11 03:56:33'),
(1173, 461, 'action complete via WP Cron', '2022-08-11 03:56:33', '2022-08-11 03:56:33'),
(1174, 462, 'action created', '2022-08-11 03:56:43', '2022-08-11 03:56:43'),
(1175, 462, 'action started via WP Cron', '2022-08-11 04:12:46', '2022-08-11 04:12:46'),
(1176, 462, 'action complete via WP Cron', '2022-08-11 04:12:46', '2022-08-11 04:12:46'),
(1177, 463, 'action created', '2022-08-11 04:52:28', '2022-08-11 04:52:28'),
(1178, 463, 'action started via WP Cron', '2022-08-11 05:59:13', '2022-08-11 05:59:13'),
(1179, 463, 'action complete via WP Cron', '2022-08-11 05:59:13', '2022-08-11 05:59:13'),
(1180, 464, 'action created', '2022-08-11 05:59:13', '2022-08-11 05:59:13'),
(1181, 464, 'action started via WP Cron', '2022-08-11 08:43:52', '2022-08-11 08:43:52'),
(1182, 464, 'action complete via WP Cron', '2022-08-11 08:43:52', '2022-08-11 08:43:52'),
(1183, 465, 'action created', '2022-08-11 08:43:52', '2022-08-11 08:43:52'),
(1184, 465, 'action started via Async Request', '2022-08-11 08:43:53', '2022-08-11 08:43:53'),
(1185, 465, 'action complete via Async Request', '2022-08-11 08:43:53', '2022-08-11 08:43:53'),
(1186, 466, 'action created', '2022-08-11 08:43:53', '2022-08-11 08:43:53'),
(1187, 466, 'action started via Async Request', '2022-08-11 08:43:58', '2022-08-11 08:43:58'),
(1188, 466, 'action complete via Async Request', '2022-08-11 08:43:58', '2022-08-11 08:43:58'),
(1189, 467, 'action created', '2022-08-11 10:11:15', '2022-08-11 10:11:15'),
(1190, 467, 'action started via WP Cron', '2022-08-11 10:23:53', '2022-08-11 10:23:53'),
(1191, 467, 'action complete via WP Cron', '2022-08-11 10:23:54', '2022-08-11 10:23:54'),
(1192, 468, 'action created', '2022-08-11 10:52:18', '2022-08-11 10:52:18'),
(1193, 468, 'action started via WP Cron', '2022-08-11 12:21:18', '2022-08-11 12:21:18'),
(1194, 468, 'action complete via WP Cron', '2022-08-11 12:21:18', '2022-08-11 12:21:18'),
(1195, 469, 'action created', '2022-08-11 12:21:18', '2022-08-11 12:21:18'),
(1196, 469, 'action started via WP Cron', '2022-08-11 12:30:08', '2022-08-11 12:30:08'),
(1197, 469, 'action complete via WP Cron', '2022-08-11 12:30:08', '2022-08-11 12:30:08'),
(1198, 470, 'action created', '2022-08-11 14:38:49', '2022-08-11 14:38:49'),
(1199, 470, 'action started via Async Request', '2022-08-11 14:39:06', '2022-08-11 14:39:06'),
(1200, 470, 'action complete via Async Request', '2022-08-11 14:39:06', '2022-08-11 14:39:06'),
(1201, 471, 'action created', '2022-08-11 18:17:32', '2022-08-11 18:17:32'),
(1202, 471, 'action started via WP Cron', '2022-08-11 18:47:24', '2022-08-11 18:47:24'),
(1203, 471, 'action complete via WP Cron', '2022-08-11 18:47:25', '2022-08-11 18:47:25'),
(1204, 472, 'action created', '2022-08-11 18:47:25', '2022-08-11 18:47:25'),
(1205, 472, 'action started via WP Cron', '2022-08-11 20:42:07', '2022-08-11 20:42:07'),
(1206, 472, 'action complete via WP Cron', '2022-08-11 20:42:07', '2022-08-11 20:42:07'),
(1207, 473, 'action created', '2022-08-11 20:42:07', '2022-08-11 20:42:07'),
(1208, 473, 'action started via WP Cron', '2022-08-11 21:33:32', '2022-08-11 21:33:32'),
(1209, 473, 'action complete via WP Cron', '2022-08-11 21:33:32', '2022-08-11 21:33:32'),
(1210, 474, 'action created', '2022-08-11 21:33:32', '2022-08-11 21:33:32'),
(1211, 474, 'action started via WP Cron', '2022-08-11 21:47:53', '2022-08-11 21:47:53'),
(1212, 474, 'action complete via WP Cron', '2022-08-11 21:47:53', '2022-08-11 21:47:53'),
(1213, 475, 'action created', '2022-08-11 21:47:53', '2022-08-11 21:47:53'),
(1214, 475, 'action started via WP Cron', '2022-08-12 01:09:10', '2022-08-12 01:09:10'),
(1215, 475, 'action complete via WP Cron', '2022-08-12 01:09:10', '2022-08-12 01:09:10'),
(1216, 476, 'action created', '2022-08-12 01:09:10', '2022-08-12 01:09:10'),
(1217, 476, 'action started via WP Cron', '2022-08-12 02:32:38', '2022-08-12 02:32:38'),
(1218, 476, 'action complete via WP Cron', '2022-08-12 02:32:38', '2022-08-12 02:32:38'),
(1219, 477, 'action created', '2022-08-12 02:32:39', '2022-08-12 02:32:39'),
(1220, 477, 'action started via WP Cron', '2022-08-12 04:27:42', '2022-08-12 04:27:42'),
(1221, 477, 'action complete via WP Cron', '2022-08-12 04:27:42', '2022-08-12 04:27:42'),
(1222, 478, 'action created', '2022-08-12 04:27:42', '2022-08-12 04:27:42'),
(1223, 478, 'action started via WP Cron', '2022-08-12 04:59:03', '2022-08-12 04:59:03'),
(1224, 478, 'action complete via WP Cron', '2022-08-12 04:59:03', '2022-08-12 04:59:03'),
(1225, 479, 'action created', '2022-08-12 04:59:04', '2022-08-12 04:59:04'),
(1226, 479, 'action started via WP Cron', '2022-08-12 05:15:20', '2022-08-12 05:15:20'),
(1227, 479, 'action complete via WP Cron', '2022-08-12 05:15:20', '2022-08-12 05:15:20'),
(1228, 480, 'action created', '2022-08-12 07:38:07', '2022-08-12 07:38:07'),
(1229, 480, 'action started via Async Request', '2022-08-12 07:38:08', '2022-08-12 07:38:08'),
(1230, 480, 'action complete via Async Request', '2022-08-12 07:38:08', '2022-08-12 07:38:08'),
(1231, 481, 'action created', '2022-08-12 10:37:05', '2022-08-12 10:37:05'),
(1232, 482, 'action created', '2022-08-12 10:37:05', '2022-08-12 10:37:05'),
(1233, 481, 'action started via WP Cron', '2022-08-12 10:37:15', '2022-08-12 10:37:15'),
(1234, 481, 'action complete via WP Cron', '2022-08-12 10:37:15', '2022-08-12 10:37:15'),
(1235, 482, 'action started via WP Cron', '2022-08-12 10:37:15', '2022-08-12 10:37:15'),
(1236, 482, 'action complete via WP Cron', '2022-08-12 10:37:15', '2022-08-12 10:37:15'),
(1237, 483, 'action created', '2022-08-12 10:59:38', '2022-08-12 10:59:38'),
(1238, 483, 'action started via WP Cron', '2022-08-12 11:29:49', '2022-08-12 11:29:49'),
(1239, 483, 'action complete via WP Cron', '2022-08-12 11:29:49', '2022-08-12 11:29:49'),
(1240, 484, 'action created', '2022-08-12 12:28:49', '2022-08-12 12:28:49'),
(1241, 484, 'action started via WP Cron', '2022-08-12 14:04:35', '2022-08-12 14:04:35'),
(1242, 484, 'action complete via WP Cron', '2022-08-12 14:04:35', '2022-08-12 14:04:35'),
(1243, 485, 'action created', '2022-08-12 14:04:35', '2022-08-12 14:04:35'),
(1244, 485, 'action started via WP Cron', '2022-08-12 15:21:00', '2022-08-12 15:21:00'),
(1245, 485, 'action complete via WP Cron', '2022-08-12 15:21:00', '2022-08-12 15:21:00'),
(1246, 486, 'action created', '2022-08-12 15:21:09', '2022-08-12 15:21:09'),
(1247, 486, 'action started via WP Cron', '2022-08-12 15:47:46', '2022-08-12 15:47:46'),
(1248, 486, 'action complete via WP Cron', '2022-08-12 15:47:46', '2022-08-12 15:47:46'),
(1249, 487, 'action created', '2022-08-12 15:47:47', '2022-08-12 15:47:47'),
(1250, 487, 'action started via WP Cron', '2022-08-12 17:55:59', '2022-08-12 17:55:59'),
(1251, 487, 'action complete via WP Cron', '2022-08-12 17:55:59', '2022-08-12 17:55:59'),
(1252, 488, 'action created', '2022-08-12 17:55:59', '2022-08-12 17:55:59'),
(1253, 488, 'action started via WP Cron', '2022-08-12 18:39:31', '2022-08-12 18:39:31'),
(1254, 488, 'action complete via WP Cron', '2022-08-12 18:39:31', '2022-08-12 18:39:31'),
(1255, 489, 'action created', '2022-08-12 20:28:54', '2022-08-12 20:28:54'),
(1256, 489, 'action started via WP Cron', '2022-08-12 20:35:05', '2022-08-12 20:35:05'),
(1257, 489, 'action complete via WP Cron', '2022-08-12 20:35:05', '2022-08-12 20:35:05'),
(1258, 490, 'action created', '2022-08-12 21:29:19', '2022-08-12 21:29:19'),
(1259, 490, 'action started via WP Cron', '2022-08-12 21:55:50', '2022-08-12 21:55:50'),
(1260, 490, 'action complete via WP Cron', '2022-08-12 21:55:50', '2022-08-12 21:55:50'),
(1261, 491, 'action created', '2022-08-12 21:55:50', '2022-08-12 21:55:50'),
(1262, 491, 'action started via WP Cron', '2022-08-12 22:18:07', '2022-08-12 22:18:07'),
(1263, 491, 'action complete via WP Cron', '2022-08-12 22:18:07', '2022-08-12 22:18:07'),
(1264, 492, 'action created', '2022-08-12 23:22:41', '2022-08-12 23:22:41'),
(1265, 492, 'action started via WP Cron', '2022-08-13 01:00:59', '2022-08-13 01:00:59'),
(1266, 492, 'action complete via WP Cron', '2022-08-13 01:00:59', '2022-08-13 01:00:59'),
(1267, 493, 'action created', '2022-08-13 01:00:59', '2022-08-13 01:00:59'),
(1268, 493, 'action started via WP Cron', '2022-08-13 02:47:37', '2022-08-13 02:47:37'),
(1269, 493, 'action complete via WP Cron', '2022-08-13 02:47:37', '2022-08-13 02:47:37'),
(1270, 494, 'action created', '2022-08-13 02:47:37', '2022-08-13 02:47:37'),
(1271, 494, 'action started via WP Cron', '2022-08-13 03:00:58', '2022-08-13 03:00:58'),
(1272, 494, 'action complete via WP Cron', '2022-08-13 03:00:58', '2022-08-13 03:00:58'),
(1273, 495, 'action created', '2022-08-13 03:51:53', '2022-08-13 03:51:53'),
(1274, 495, 'action started via WP Cron', '2022-08-13 04:37:02', '2022-08-13 04:37:02'),
(1275, 495, 'action complete via WP Cron', '2022-08-13 04:37:02', '2022-08-13 04:37:02'),
(1276, 496, 'action created', '2022-08-13 05:00:49', '2022-08-13 05:00:49'),
(1277, 496, 'action started via WP Cron', '2022-08-13 05:57:56', '2022-08-13 05:57:56'),
(1278, 496, 'action complete via WP Cron', '2022-08-13 05:57:57', '2022-08-13 05:57:57'),
(1279, 497, 'action created', '2022-08-13 05:57:57', '2022-08-13 05:57:57'),
(1280, 497, 'action started via WP Cron', '2022-08-13 06:14:13', '2022-08-13 06:14:13'),
(1281, 497, 'action complete via WP Cron', '2022-08-13 06:14:13', '2022-08-13 06:14:13'),
(1282, 498, 'action created', '2022-08-13 07:21:19', '2022-08-13 07:21:19'),
(1283, 498, 'action started via WP Cron', '2022-08-13 09:22:14', '2022-08-13 09:22:14'),
(1284, 498, 'action complete via WP Cron', '2022-08-13 09:22:14', '2022-08-13 09:22:14'),
(1285, 499, 'action created', '2022-08-13 09:22:14', '2022-08-13 09:22:14'),
(1286, 500, 'action created', '2022-08-13 09:22:14', '2022-08-13 09:22:14'),
(1287, 499, 'action started via WP Cron', '2022-08-13 11:21:54', '2022-08-13 11:21:54'),
(1288, 499, 'action complete via WP Cron', '2022-08-13 11:21:54', '2022-08-13 11:21:54'),
(1289, 500, 'action started via WP Cron', '2022-08-13 11:21:54', '2022-08-13 11:21:54'),
(1290, 500, 'action complete via WP Cron', '2022-08-13 11:21:54', '2022-08-13 11:21:54'),
(1291, 501, 'action created', '2022-08-13 11:21:54', '2022-08-13 11:21:54'),
(1292, 501, 'action started via WP Cron', '2022-08-13 12:38:18', '2022-08-13 12:38:18'),
(1293, 501, 'action complete via WP Cron', '2022-08-13 12:38:18', '2022-08-13 12:38:18'),
(1294, 502, 'action created', '2022-08-13 12:38:18', '2022-08-13 12:38:18'),
(1295, 502, 'action started via WP Cron', '2022-08-13 15:44:06', '2022-08-13 15:44:06'),
(1296, 502, 'action complete via WP Cron', '2022-08-13 15:44:06', '2022-08-13 15:44:06'),
(1297, 503, 'action created', '2022-08-13 15:44:06', '2022-08-13 15:44:06'),
(1298, 503, 'action started via WP Cron', '2022-08-13 15:45:00', '2022-08-13 15:45:00'),
(1299, 503, 'action complete via WP Cron', '2022-08-13 15:45:00', '2022-08-13 15:45:00'),
(1300, 504, 'action created', '2022-08-13 17:24:23', '2022-08-13 17:24:23'),
(1301, 504, 'action started via WP Cron', '2022-08-13 17:39:54', '2022-08-13 17:39:54'),
(1302, 504, 'action complete via WP Cron', '2022-08-13 17:39:54', '2022-08-13 17:39:54'),
(1303, 505, 'action created', '2022-08-13 17:50:08', '2022-08-13 17:50:08'),
(1304, 505, 'action started via WP Cron', '2022-08-13 19:01:29', '2022-08-13 19:01:29'),
(1305, 505, 'action complete via WP Cron', '2022-08-13 19:01:29', '2022-08-13 19:01:29'),
(1306, 506, 'action created', '2022-08-13 19:01:29', '2022-08-13 19:01:29'),
(1307, 506, 'action started via WP Cron', '2022-08-13 20:39:33', '2022-08-13 20:39:33'),
(1308, 506, 'action complete via WP Cron', '2022-08-13 20:39:33', '2022-08-13 20:39:33'),
(1309, 507, 'action created', '2022-08-13 20:39:33', '2022-08-13 20:39:33'),
(1310, 507, 'action started via WP Cron', '2022-08-13 20:53:50', '2022-08-13 20:53:50'),
(1311, 507, 'action complete via WP Cron', '2022-08-13 20:53:50', '2022-08-13 20:53:50'),
(1312, 508, 'action created', '2022-08-13 20:53:50', '2022-08-13 20:53:50'),
(1313, 508, 'action started via WP Cron', '2022-08-13 22:13:37', '2022-08-13 22:13:37'),
(1314, 508, 'action complete via WP Cron', '2022-08-13 22:13:37', '2022-08-13 22:13:37'),
(1315, 509, 'action created', '2022-08-13 22:13:38', '2022-08-13 22:13:38'),
(1316, 509, 'action started via WP Cron', '2022-08-14 01:47:27', '2022-08-14 01:47:27'),
(1317, 509, 'action complete via WP Cron', '2022-08-14 01:47:27', '2022-08-14 01:47:27'),
(1318, 510, 'action created', '2022-08-14 01:47:27', '2022-08-14 01:47:27'),
(1319, 510, 'action started via WP Cron', '2022-08-14 03:03:24', '2022-08-14 03:03:24'),
(1320, 510, 'action complete via WP Cron', '2022-08-14 03:03:24', '2022-08-14 03:03:24'),
(1321, 511, 'action created', '2022-08-14 03:03:34', '2022-08-14 03:03:34'),
(1322, 511, 'action started via WP Cron', '2022-08-14 03:05:26', '2022-08-14 03:05:26'),
(1323, 511, 'action complete via WP Cron', '2022-08-14 03:05:26', '2022-08-14 03:05:26'),
(1324, 512, 'action created', '2022-08-14 03:55:58', '2022-08-14 03:55:58'),
(1325, 512, 'action started via WP Cron', '2022-08-14 03:59:10', '2022-08-14 03:59:10'),
(1326, 512, 'action complete via WP Cron', '2022-08-14 03:59:10', '2022-08-14 03:59:10'),
(1327, 513, 'action created', '2022-08-14 05:58:33', '2022-08-14 05:58:33'),
(1328, 513, 'action started via WP Cron', '2022-08-14 07:47:22', '2022-08-14 07:47:22'),
(1329, 513, 'action complete via WP Cron', '2022-08-14 07:47:22', '2022-08-14 07:47:22'),
(1330, 514, 'action created', '2022-08-14 07:47:22', '2022-08-14 07:47:22'),
(1331, 514, 'action started via Async Request', '2022-08-14 07:47:22', '2022-08-14 07:47:22'),
(1332, 514, 'action complete via Async Request', '2022-08-14 07:47:22', '2022-08-14 07:47:22'),
(1333, 515, 'action created', '2022-08-14 07:47:23', '2022-08-14 07:47:23'),
(1334, 515, 'action started via Async Request', '2022-08-14 07:47:27', '2022-08-14 07:47:27'),
(1335, 515, 'action complete via Async Request', '2022-08-14 07:47:27', '2022-08-14 07:47:27'),
(1336, 516, 'action created', '2022-08-14 08:50:19', '2022-08-14 08:50:19'),
(1337, 516, 'action started via WP Cron', '2022-08-14 09:11:21', '2022-08-14 09:11:21'),
(1338, 516, 'action complete via WP Cron', '2022-08-14 09:11:21', '2022-08-14 09:11:21'),
(1339, 517, 'action created', '2022-08-14 10:17:09', '2022-08-14 10:17:09'),
(1340, 517, 'action started via WP Cron', '2022-08-14 10:17:31', '2022-08-14 10:17:31'),
(1341, 517, 'action complete via WP Cron', '2022-08-14 10:17:31', '2022-08-14 10:17:31'),
(1342, 518, 'action created', '2022-08-14 10:47:50', '2022-08-14 10:47:50'),
(1343, 518, 'action started via WP Cron', '2022-08-14 11:42:15', '2022-08-14 11:42:15'),
(1344, 518, 'action complete via WP Cron', '2022-08-14 11:42:15', '2022-08-14 11:42:15'),
(1345, 519, 'action created', '2022-08-14 11:43:18', '2022-08-14 11:43:18'),
(1346, 519, 'action started via WP Cron', '2022-08-14 11:43:18', '2022-08-14 11:43:18'),
(1347, 519, 'action complete via WP Cron', '2022-08-14 11:43:18', '2022-08-14 11:43:18'),
(1348, 520, 'action created', '2022-08-14 13:16:19', '2022-08-14 13:16:19'),
(1349, 520, 'action started via WP Cron', '2022-08-14 13:30:53', '2022-08-14 13:30:53'),
(1350, 520, 'action complete via WP Cron', '2022-08-14 13:30:53', '2022-08-14 13:30:53'),
(1351, 521, 'action created', '2022-08-14 14:39:56', '2022-08-14 14:39:56'),
(1352, 521, 'action started via WP Cron', '2022-08-14 14:56:43', '2022-08-14 14:56:43'),
(1353, 521, 'action complete via WP Cron', '2022-08-14 14:56:43', '2022-08-14 14:56:43'),
(1354, 522, 'action created', '2022-08-14 14:56:43', '2022-08-14 14:56:43'),
(1355, 522, 'action started via WP Cron', '2022-08-14 15:20:19', '2022-08-14 15:20:19'),
(1356, 522, 'action complete via WP Cron', '2022-08-14 15:20:19', '2022-08-14 15:20:19'),
(1357, 523, 'action created', '2022-08-14 16:08:29', '2022-08-14 16:08:29'),
(1358, 523, 'action started via WP Cron', '2022-08-14 16:45:26', '2022-08-14 16:45:26'),
(1359, 523, 'action complete via WP Cron', '2022-08-14 16:45:26', '2022-08-14 16:45:26'),
(1360, 524, 'action created', '2022-08-14 16:45:26', '2022-08-14 16:45:26'),
(1361, 524, 'action started via WP Cron', '2022-08-14 19:10:25', '2022-08-14 19:10:25'),
(1362, 524, 'action complete via WP Cron', '2022-08-14 19:10:25', '2022-08-14 19:10:25'),
(1363, 525, 'action created', '2022-08-14 19:10:25', '2022-08-14 19:10:25'),
(1364, 525, 'action started via WP Cron', '2022-08-14 19:58:46', '2022-08-14 19:58:46'),
(1365, 525, 'action complete via WP Cron', '2022-08-14 19:58:46', '2022-08-14 19:58:46'),
(1366, 526, 'action created', '2022-08-14 19:58:47', '2022-08-14 19:58:47'),
(1367, 526, 'action started via WP Cron', '2022-08-14 22:18:38', '2022-08-14 22:18:38'),
(1368, 526, 'action complete via WP Cron', '2022-08-14 22:18:38', '2022-08-14 22:18:38'),
(1369, 527, 'action created', '2022-08-14 22:18:38', '2022-08-14 22:18:38'),
(1370, 527, 'action started via WP Cron', '2022-08-14 22:52:08', '2022-08-14 22:52:08'),
(1371, 527, 'action complete via WP Cron', '2022-08-14 22:52:08', '2022-08-14 22:52:08'),
(1372, 528, 'action created', '2022-08-14 22:52:08', '2022-08-14 22:52:08'),
(1373, 528, 'action started via WP Cron', '2022-08-14 22:52:18', '2022-08-14 22:52:18'),
(1374, 528, 'action complete via WP Cron', '2022-08-14 22:52:18', '2022-08-14 22:52:18'),
(1375, 529, 'action created', '2022-08-15 01:40:28', '2022-08-15 01:40:28'),
(1376, 529, 'action started via WP Cron', '2022-08-15 01:46:49', '2022-08-15 01:46:49'),
(1377, 529, 'action complete via WP Cron', '2022-08-15 01:46:49', '2022-08-15 01:46:49'),
(1378, 530, 'action created', '2022-08-15 01:46:49', '2022-08-15 01:46:49'),
(1379, 530, 'action started via WP Cron', '2022-08-15 01:47:54', '2022-08-15 01:47:54'),
(1380, 530, 'action complete via WP Cron', '2022-08-15 01:47:54', '2022-08-15 01:47:54'),
(1381, 531, 'action created', '2022-08-15 07:34:38', '2022-08-15 07:34:38'),
(1382, 531, 'action started via Async Request', '2022-08-15 07:34:38', '2022-08-15 07:34:38'),
(1383, 531, 'action complete via Async Request', '2022-08-15 07:34:38', '2022-08-15 07:34:38'),
(1384, 532, 'action created', '2022-08-15 07:44:52', '2022-08-15 07:44:52'),
(1385, 533, 'action created', '2022-08-15 07:44:52', '2022-08-15 07:44:52'),
(1386, 532, 'action started via WP Cron', '2022-08-15 07:45:23', '2022-08-15 07:45:23'),
(1387, 532, 'action complete via WP Cron', '2022-08-15 07:45:23', '2022-08-15 07:45:23'),
(1388, 533, 'action started via WP Cron', '2022-08-15 07:45:23', '2022-08-15 07:45:23'),
(1389, 533, 'action complete via WP Cron', '2022-08-15 07:45:23', '2022-08-15 07:45:23'),
(1390, 534, 'action created', '2022-08-15 08:55:25', '2022-08-15 08:55:25'),
(1391, 534, 'action started via WP Cron', '2022-08-15 09:13:37', '2022-08-15 09:13:37'),
(1392, 534, 'action complete via WP Cron', '2022-08-15 09:13:37', '2022-08-15 09:13:37'),
(1393, 535, 'action created', '2022-08-15 10:13:14', '2022-08-15 10:13:14'),
(1394, 535, 'action started via WP Cron', '2022-08-15 10:23:48', '2022-08-15 10:23:48'),
(1395, 535, 'action complete via WP Cron', '2022-08-15 10:23:48', '2022-08-15 10:23:48'),
(1396, 536, 'action created', '2022-08-15 12:41:08', '2022-08-15 12:41:08'),
(1397, 536, 'action started via WP Cron', '2022-08-15 13:47:20', '2022-08-15 13:47:20'),
(1398, 536, 'action complete via WP Cron', '2022-08-15 13:47:20', '2022-08-15 13:47:20'),
(1399, 537, 'action created', '2022-08-15 13:47:20', '2022-08-15 13:47:20'),
(1400, 537, 'action started via WP Cron', '2022-08-15 15:37:47', '2022-08-15 15:37:47'),
(1401, 537, 'action complete via WP Cron', '2022-08-15 15:37:47', '2022-08-15 15:37:47'),
(1402, 538, 'action created', '2022-08-15 15:37:56', '2022-08-15 15:37:56'),
(1403, 538, 'action started via WP Cron', '2022-08-15 15:56:41', '2022-08-15 15:56:41'),
(1404, 538, 'action complete via WP Cron', '2022-08-15 15:56:41', '2022-08-15 15:56:41'),
(1405, 539, 'action created', '2022-08-15 15:56:41', '2022-08-15 15:56:41'),
(1406, 539, 'action started via WP Cron', '2022-08-15 15:57:48', '2022-08-15 15:57:48'),
(1407, 539, 'action complete via WP Cron', '2022-08-15 15:57:48', '2022-08-15 15:57:48'),
(1408, 540, 'action created', '2022-08-15 17:06:36', '2022-08-15 17:06:36'),
(1409, 540, 'action started via WP Cron', '2022-08-15 17:15:39', '2022-08-15 17:15:39'),
(1410, 540, 'action complete via WP Cron', '2022-08-15 17:15:39', '2022-08-15 17:15:39'),
(1411, 541, 'action created', '2022-08-15 18:03:01', '2022-08-15 18:03:01'),
(1412, 541, 'action started via WP Cron', '2022-08-15 18:45:15', '2022-08-15 18:45:15'),
(1413, 541, 'action complete via WP Cron', '2022-08-15 18:45:15', '2022-08-15 18:45:15'),
(1414, 542, 'action created', '2022-08-15 18:45:15', '2022-08-15 18:45:15'),
(1415, 542, 'action started via WP Cron', '2022-08-15 19:35:33', '2022-08-15 19:35:33'),
(1416, 542, 'action complete via WP Cron', '2022-08-15 19:35:33', '2022-08-15 19:35:33'),
(1417, 543, 'action created', '2022-08-15 21:18:55', '2022-08-15 21:18:55'),
(1418, 543, 'action started via WP Cron', '2022-08-15 21:38:24', '2022-08-15 21:38:24'),
(1419, 543, 'action complete via WP Cron', '2022-08-15 21:38:24', '2022-08-15 21:38:24'),
(1420, 544, 'action created', '2022-08-15 22:11:14', '2022-08-15 22:11:14'),
(1421, 544, 'action started via WP Cron', '2022-08-15 22:41:44', '2022-08-15 22:41:44'),
(1422, 544, 'action complete via WP Cron', '2022-08-15 22:41:44', '2022-08-15 22:41:44'),
(1423, 545, 'action created', '2022-08-16 00:28:18', '2022-08-16 00:28:18'),
(1424, 545, 'action started via WP Cron', '2022-08-16 01:49:12', '2022-08-16 01:49:12'),
(1425, 545, 'action complete via WP Cron', '2022-08-16 01:49:12', '2022-08-16 01:49:12'),
(1426, 546, 'action created', '2022-08-16 01:49:12', '2022-08-16 01:49:12'),
(1427, 546, 'action started via WP Cron', '2022-08-16 02:47:36', '2022-08-16 02:47:36'),
(1428, 546, 'action complete via WP Cron', '2022-08-16 02:47:36', '2022-08-16 02:47:36'),
(1429, 547, 'action created', '2022-08-16 02:47:46', '2022-08-16 02:47:46'),
(1430, 547, 'action started via WP Cron', '2022-08-16 02:52:38', '2022-08-16 02:52:38'),
(1431, 547, 'action complete via WP Cron', '2022-08-16 02:52:38', '2022-08-16 02:52:38'),
(1432, 548, 'action created', '2022-08-16 04:04:45', '2022-08-16 04:04:45'),
(1433, 548, 'action started via WP Cron', '2022-08-16 04:04:45', '2022-08-16 04:04:45'),
(1434, 548, 'action complete via WP Cron', '2022-08-16 04:04:45', '2022-08-16 04:04:45'),
(1435, 549, 'action created', '2022-08-16 05:20:53', '2022-08-16 05:20:53'),
(1436, 549, 'action started via WP Cron', '2022-08-16 06:49:56', '2022-08-16 06:49:56'),
(1437, 549, 'action complete via WP Cron', '2022-08-16 06:49:56', '2022-08-16 06:49:56'),
(1438, 550, 'action created', '2022-08-16 06:49:56', '2022-08-16 06:49:56'),
(1439, 550, 'action started via WP Cron', '2022-08-16 08:31:18', '2022-08-16 08:31:18'),
(1440, 550, 'action complete via WP Cron', '2022-08-16 08:31:18', '2022-08-16 08:31:18'),
(1441, 551, 'action created', '2022-08-16 08:31:18', '2022-08-16 08:31:18'),
(1442, 552, 'action created', '2022-08-16 08:31:18', '2022-08-16 08:31:18'),
(1443, 551, 'action started via WP Cron', '2022-08-16 10:30:12', '2022-08-16 10:30:12'),
(1444, 551, 'action complete via WP Cron', '2022-08-16 10:30:12', '2022-08-16 10:30:12'),
(1445, 552, 'action started via WP Cron', '2022-08-16 10:30:12', '2022-08-16 10:30:12'),
(1446, 552, 'action complete via WP Cron', '2022-08-16 10:30:12', '2022-08-16 10:30:12'),
(1447, 434, 'action started via WP Cron', '2022-08-16 10:30:12', '2022-08-16 10:30:12'),
(1448, 434, 'action complete via WP Cron', '2022-08-16 10:30:12', '2022-08-16 10:30:12'),
(1449, 553, 'action created', '2022-08-16 10:30:12', '2022-08-16 10:30:12'),
(1450, 554, 'action created', '2022-08-16 10:30:12', '2022-08-16 10:30:12'),
(1451, 554, 'action started via WP Cron', '2022-08-16 10:30:34', '2022-08-16 10:30:34'),
(1452, 554, 'action complete via WP Cron', '2022-08-16 10:30:34', '2022-08-16 10:30:34'),
(1453, 555, 'action created', '2022-08-16 11:14:34', '2022-08-16 11:14:34'),
(1454, 555, 'action started via WP Cron', '2022-08-16 11:31:39', '2022-08-16 11:31:39'),
(1455, 555, 'action complete via WP Cron', '2022-08-16 11:31:39', '2022-08-16 11:31:39'),
(1456, 556, 'action created', '2022-08-16 11:49:16', '2022-08-16 11:49:16'),
(1457, 556, 'action started via WP Cron', '2022-08-16 12:23:17', '2022-08-16 12:23:17'),
(1458, 556, 'action complete via WP Cron', '2022-08-16 12:23:17', '2022-08-16 12:23:17'),
(1459, 557, 'action created', '2022-08-16 12:50:25', '2022-08-16 12:50:25'),
(1460, 557, 'action started via WP Cron', '2022-08-16 15:20:11', '2022-08-16 15:20:11'),
(1461, 557, 'action complete via WP Cron', '2022-08-16 15:20:11', '2022-08-16 15:20:11'),
(1462, 558, 'action created', '2022-08-16 15:20:11', '2022-08-16 15:20:11'),
(1463, 558, 'action started via WP Cron', '2022-08-16 15:27:08', '2022-08-16 15:27:08'),
(1464, 558, 'action complete via WP Cron', '2022-08-16 15:27:08', '2022-08-16 15:27:08'),
(1465, 559, 'action created', '2022-08-16 16:07:43', '2022-08-16 16:07:43'),
(1466, 559, 'action started via WP Cron', '2022-08-16 17:35:33', '2022-08-16 17:35:33'),
(1467, 559, 'action complete via WP Cron', '2022-08-16 17:35:33', '2022-08-16 17:35:33'),
(1468, 560, 'action created', '2022-08-16 17:35:33', '2022-08-16 17:35:33'),
(1469, 560, 'action started via WP Cron', '2022-08-16 18:55:38', '2022-08-16 18:55:38'),
(1470, 560, 'action complete via WP Cron', '2022-08-16 18:55:38', '2022-08-16 18:55:38'),
(1471, 561, 'action created', '2022-08-16 18:55:38', '2022-08-16 18:55:38'),
(1472, 561, 'action started via WP Cron', '2022-08-16 19:15:35', '2022-08-16 19:15:35'),
(1473, 561, 'action complete via WP Cron', '2022-08-16 19:15:35', '2022-08-16 19:15:35'),
(1474, 562, 'action created', '2022-08-17 00:56:43', '2022-08-17 00:56:43'),
(1475, 562, 'action started via WP Cron', '2022-08-17 01:27:44', '2022-08-17 01:27:44'),
(1476, 562, 'action complete via WP Cron', '2022-08-17 01:27:44', '2022-08-17 01:27:44'),
(1477, 563, 'action created', '2022-08-17 01:55:38', '2022-08-17 01:55:38'),
(1478, 563, 'action started via WP Cron', '2022-08-17 01:55:38', '2022-08-17 01:55:38'),
(1479, 563, 'action complete via WP Cron', '2022-08-17 01:55:38', '2022-08-17 01:55:38'),
(1480, 564, 'action created', '2022-08-17 02:46:30', '2022-08-17 02:46:30'),
(1481, 564, 'action started via WP Cron', '2022-08-17 03:39:02', '2022-08-17 03:39:02'),
(1482, 564, 'action complete via WP Cron', '2022-08-17 03:39:02', '2022-08-17 03:39:02'),
(1483, 565, 'action created', '2022-08-17 03:48:31', '2022-08-17 03:48:31'),
(1484, 565, 'action started via WP Cron', '2022-08-17 04:30:01', '2022-08-17 04:30:01'),
(1485, 565, 'action complete via WP Cron', '2022-08-17 04:30:01', '2022-08-17 04:30:01'),
(1486, 566, 'action created', '2022-08-17 04:44:46', '2022-08-17 04:44:46'),
(1487, 566, 'action started via WP Cron', '2022-08-17 04:46:26', '2022-08-17 04:46:26'),
(1488, 566, 'action complete via WP Cron', '2022-08-17 04:46:26', '2022-08-17 04:46:26'),
(1489, 567, 'action created', '2022-08-17 06:01:24', '2022-08-17 06:01:24'),
(1490, 567, 'action started via WP Cron', '2022-08-17 06:26:16', '2022-08-17 06:26:16'),
(1491, 567, 'action complete via WP Cron', '2022-08-17 06:26:16', '2022-08-17 06:26:16'),
(1492, 568, 'action created', '2022-08-17 07:32:30', '2022-08-17 07:32:30'),
(1493, 568, 'action started via Async Request', '2022-08-17 07:44:12', '2022-08-17 07:44:12'),
(1494, 568, 'action complete via Async Request', '2022-08-17 07:44:12', '2022-08-17 07:44:12'),
(1495, 569, 'action created', '2022-08-17 07:44:13', '2022-08-17 07:44:13'),
(1496, 570, 'action created', '2022-08-17 07:44:13', '2022-08-17 07:44:13'),
(1497, 569, 'action started via Async Request', '2022-08-17 07:44:17', '2022-08-17 07:44:17'),
(1498, 569, 'action complete via Async Request', '2022-08-17 07:44:17', '2022-08-17 07:44:17'),
(1499, 570, 'action started via Async Request', '2022-08-17 07:44:17', '2022-08-17 07:44:17'),
(1500, 570, 'action complete via Async Request', '2022-08-17 07:44:17', '2022-08-17 07:44:17'),
(1501, 571, 'action created', '2022-08-17 09:54:26', '2022-08-17 09:54:26'),
(1502, 571, 'action started via WP Cron', '2022-08-17 10:29:03', '2022-08-17 10:29:03'),
(1503, 571, 'action complete via WP Cron', '2022-08-17 10:29:03', '2022-08-17 10:29:03'),
(1504, 572, 'action created', '2022-08-17 11:22:31', '2022-08-17 11:22:31'),
(1505, 572, 'action started via WP Cron', '2022-08-17 13:12:23', '2022-08-17 13:12:23'),
(1506, 572, 'action complete via WP Cron', '2022-08-17 13:12:23', '2022-08-17 13:12:23'),
(1507, 573, 'action created', '2022-08-17 13:12:23', '2022-08-17 13:12:23'),
(1508, 573, 'action started via WP Cron', '2022-08-17 13:14:26', '2022-08-17 13:14:26'),
(1509, 573, 'action complete via WP Cron', '2022-08-17 13:14:26', '2022-08-17 13:14:26'),
(1510, 574, 'action created', '2022-08-17 14:04:57', '2022-08-17 14:04:57'),
(1511, 574, 'action started via WP Cron', '2022-08-17 15:12:00', '2022-08-17 15:12:00'),
(1512, 574, 'action complete via WP Cron', '2022-08-17 15:12:00', '2022-08-17 15:12:00'),
(1513, 575, 'action created', '2022-08-17 15:12:09', '2022-08-17 15:12:09'),
(1514, 575, 'action started via WP Cron', '2022-08-17 15:12:17', '2022-08-17 15:12:17'),
(1515, 575, 'action complete via WP Cron', '2022-08-17 15:12:17', '2022-08-17 15:12:17'),
(1516, 576, 'action created', '2022-08-17 16:55:44', '2022-08-17 16:55:44'),
(1517, 576, 'action started via WP Cron', '2022-08-17 18:14:03', '2022-08-17 18:14:03'),
(1518, 576, 'action complete via WP Cron', '2022-08-17 18:14:03', '2022-08-17 18:14:03'),
(1519, 577, 'action created', '2022-08-17 18:14:03', '2022-08-17 18:14:03'),
(1520, 577, 'action started via WP Cron', '2022-08-17 19:10:37', '2022-08-17 19:10:37'),
(1521, 577, 'action complete via WP Cron', '2022-08-17 19:10:37', '2022-08-17 19:10:37'),
(1522, 578, 'action created', '2022-08-17 19:10:37', '2022-08-17 19:10:37'),
(1523, 578, 'action started via WP Cron', '2022-08-17 21:20:18', '2022-08-17 21:20:18'),
(1524, 578, 'action complete via WP Cron', '2022-08-17 21:20:18', '2022-08-17 21:20:18'),
(1525, 579, 'action created', '2022-08-17 21:20:19', '2022-08-17 21:20:19'),
(1526, 579, 'action started via WP Cron', '2022-08-17 23:05:00', '2022-08-17 23:05:00'),
(1527, 579, 'action complete via WP Cron', '2022-08-17 23:05:00', '2022-08-17 23:05:00'),
(1528, 580, 'action created', '2022-08-17 23:05:00', '2022-08-17 23:05:00'),
(1529, 580, 'action started via WP Cron', '2022-08-17 23:21:57', '2022-08-17 23:21:57'),
(1530, 580, 'action complete via WP Cron', '2022-08-17 23:21:57', '2022-08-17 23:21:57'),
(1531, 581, 'action created', '2022-08-18 01:29:10', '2022-08-18 01:29:10'),
(1532, 581, 'action started via WP Cron', '2022-08-18 03:09:44', '2022-08-18 03:09:44'),
(1533, 581, 'action complete via WP Cron', '2022-08-18 03:09:44', '2022-08-18 03:09:44'),
(1534, 582, 'action created', '2022-08-18 03:09:45', '2022-08-18 03:09:45'),
(1535, 582, 'action started via WP Cron', '2022-08-18 03:10:22', '2022-08-18 03:10:22'),
(1536, 582, 'action complete via WP Cron', '2022-08-18 03:10:22', '2022-08-18 03:10:22'),
(1537, 583, 'action created', '2022-08-18 03:52:47', '2022-08-18 03:52:47'),
(1538, 583, 'action started via WP Cron', '2022-08-18 03:54:07', '2022-08-18 03:54:07'),
(1539, 583, 'action complete via WP Cron', '2022-08-18 03:54:07', '2022-08-18 03:54:07'),
(1540, 584, 'action created', '2022-08-18 07:53:25', '2022-08-18 07:53:25'),
(1541, 584, 'action started via Async Request', '2022-08-18 07:53:25', '2022-08-18 07:53:25'),
(1542, 584, 'action complete via Async Request', '2022-08-18 07:53:25', '2022-08-18 07:53:25'),
(1543, 585, 'action created', '2022-08-18 07:53:26', '2022-08-18 07:53:26'),
(1544, 585, 'action started via Async Request', '2022-08-18 07:53:30', '2022-08-18 07:53:30'),
(1545, 585, 'action complete via Async Request', '2022-08-18 07:53:30', '2022-08-18 07:53:30'),
(1546, 586, 'action created', '2022-08-18 10:25:13', '2022-08-18 10:25:13'),
(1547, 586, 'action started via WP Cron', '2022-08-18 11:34:08', '2022-08-18 11:34:08'),
(1548, 586, 'action complete via WP Cron', '2022-08-18 11:34:08', '2022-08-18 11:34:08'),
(1549, 587, 'action created', '2022-08-18 11:34:08', '2022-08-18 11:34:08'),
(1550, 587, 'action started via WP Cron', '2022-08-18 11:56:30', '2022-08-18 11:56:30'),
(1551, 587, 'action complete via WP Cron', '2022-08-18 11:56:30', '2022-08-18 11:56:30'),
(1552, 588, 'action created', '2022-08-18 11:56:30', '2022-08-18 11:56:30'),
(1553, 588, 'action started via WP Cron', '2022-08-18 12:25:36', '2022-08-18 12:25:36'),
(1554, 588, 'action complete via WP Cron', '2022-08-18 12:25:37', '2022-08-18 12:25:37'),
(1555, 589, 'action created', '2022-08-18 13:14:58', '2022-08-18 13:14:58'),
(1556, 589, 'action started via WP Cron', '2022-08-18 14:28:35', '2022-08-18 14:28:35'),
(1557, 589, 'action complete via WP Cron', '2022-08-18 14:28:35', '2022-08-18 14:28:35'),
(1558, 590, 'action created', '2022-08-18 14:28:35', '2022-08-18 14:28:35'),
(1559, 590, 'action started via WP Cron', '2022-08-18 15:01:46', '2022-08-18 15:01:46'),
(1560, 590, 'action complete via WP Cron', '2022-08-18 15:01:46', '2022-08-18 15:01:46'),
(1561, 591, 'action created', '2022-08-18 15:01:55', '2022-08-18 15:01:55'),
(1562, 591, 'action started via WP Cron', '2022-08-18 15:23:28', '2022-08-18 15:23:28'),
(1563, 591, 'action complete via WP Cron', '2022-08-18 15:23:28', '2022-08-18 15:23:28'),
(1564, 592, 'action created', '2022-08-18 16:58:20', '2022-08-18 16:58:20'),
(1565, 592, 'action started via WP Cron', '2022-08-18 18:31:20', '2022-08-18 18:31:20'),
(1566, 592, 'action complete via WP Cron', '2022-08-18 18:31:20', '2022-08-18 18:31:20'),
(1567, 593, 'action created', '2022-08-18 18:31:20', '2022-08-18 18:31:20'),
(1568, 593, 'action started via WP Cron', '2022-08-18 20:56:15', '2022-08-18 20:56:15'),
(1569, 593, 'action complete via WP Cron', '2022-08-18 20:56:15', '2022-08-18 20:56:15'),
(1570, 594, 'action created', '2022-08-18 20:56:15', '2022-08-18 20:56:15'),
(1571, 594, 'action started via WP Cron', '2022-08-18 23:31:48', '2022-08-18 23:31:48'),
(1572, 594, 'action complete via WP Cron', '2022-08-18 23:31:48', '2022-08-18 23:31:48'),
(1573, 595, 'action created', '2022-08-18 23:31:48', '2022-08-18 23:31:48'),
(1574, 595, 'action started via WP Cron', '2022-08-19 00:03:14', '2022-08-19 00:03:14'),
(1575, 595, 'action complete via WP Cron', '2022-08-19 00:03:14', '2022-08-19 00:03:14'),
(1576, 596, 'action created', '2022-08-19 00:03:14', '2022-08-19 00:03:14'),
(1577, 596, 'action started via WP Cron', '2022-08-19 04:11:35', '2022-08-19 04:11:35'),
(1578, 596, 'action complete via WP Cron', '2022-08-19 04:11:35', '2022-08-19 04:11:35'),
(1579, 597, 'action created', '2022-08-19 04:11:35', '2022-08-19 04:11:35'),
(1580, 597, 'action started via WP Cron', '2022-08-19 04:14:16', '2022-08-19 04:14:16'),
(1581, 597, 'action complete via WP Cron', '2022-08-19 04:14:16', '2022-08-19 04:14:16'),
(1582, 598, 'action created', '2022-08-19 05:36:34', '2022-08-19 05:36:34'),
(1583, 598, 'action started via WP Cron', '2022-08-19 06:11:29', '2022-08-19 06:11:29'),
(1584, 598, 'action complete via WP Cron', '2022-08-19 06:11:29', '2022-08-19 06:11:29'),
(1585, 599, 'action created', '2022-08-19 06:11:29', '2022-08-19 06:11:29'),
(1586, 599, 'action started via WP Cron', '2022-08-19 06:27:48', '2022-08-19 06:27:48'),
(1587, 599, 'action complete via WP Cron', '2022-08-19 06:27:48', '2022-08-19 06:27:48'),
(1588, 600, 'action created', '2022-08-19 07:26:14', '2022-08-19 07:26:14'),
(1589, 600, 'action started via WP Cron', '2022-08-19 07:27:05', '2022-08-19 07:27:05'),
(1590, 600, 'action complete via WP Cron', '2022-08-19 07:27:05', '2022-08-19 07:27:05'),
(1591, 601, 'action created', '2022-08-19 09:40:29', '2022-08-19 09:40:29'),
(1592, 602, 'action created', '2022-08-19 09:40:29', '2022-08-19 09:40:29'),
(1593, 601, 'action started via WP Cron', '2022-08-19 11:05:20', '2022-08-19 11:05:20'),
(1594, 601, 'action complete via WP Cron', '2022-08-19 11:05:20', '2022-08-19 11:05:20'),
(1595, 602, 'action started via WP Cron', '2022-08-19 11:05:20', '2022-08-19 11:05:20'),
(1596, 602, 'action complete via WP Cron', '2022-08-19 11:05:20', '2022-08-19 11:05:20'),
(1597, 603, 'action created', '2022-08-19 11:05:20', '2022-08-19 11:05:20'),
(1598, 603, 'action started via WP Cron', '2022-08-19 11:27:14', '2022-08-19 11:27:14'),
(1599, 603, 'action complete via WP Cron', '2022-08-19 11:27:14', '2022-08-19 11:27:14'),
(1600, 604, 'action created', '2022-08-19 12:24:39', '2022-08-19 12:24:39'),
(1601, 604, 'action started via WP Cron', '2022-08-19 12:37:43', '2022-08-19 12:37:43'),
(1602, 604, 'action complete via WP Cron', '2022-08-19 12:37:43', '2022-08-19 12:37:43'),
(1603, 605, 'action created', '2022-08-19 13:52:03', '2022-08-19 13:52:03'),
(1604, 605, 'action started via WP Cron', '2022-08-19 14:10:23', '2022-08-19 14:10:23'),
(1605, 605, 'action complete via WP Cron', '2022-08-19 14:10:23', '2022-08-19 14:10:23'),
(1606, 606, 'action created', '2022-08-19 15:17:34', '2022-08-19 15:17:34'),
(1607, 606, 'action started via WP Cron', '2022-08-19 15:30:56', '2022-08-19 15:30:56'),
(1608, 606, 'action complete via WP Cron', '2022-08-19 15:30:56', '2022-08-19 15:30:56'),
(1609, 607, 'action created', '2022-08-19 18:28:46', '2022-08-19 18:28:46'),
(1610, 607, 'action started via WP Cron', '2022-08-19 19:09:09', '2022-08-19 19:09:09'),
(1611, 607, 'action complete via WP Cron', '2022-08-19 19:09:09', '2022-08-19 19:09:09'),
(1612, 608, 'action created', '2022-08-19 19:09:09', '2022-08-19 19:09:09'),
(1613, 608, 'action started via WP Cron', '2022-08-19 22:01:20', '2022-08-19 22:01:20'),
(1614, 608, 'action complete via WP Cron', '2022-08-19 22:01:20', '2022-08-19 22:01:20'),
(1615, 609, 'action created', '2022-08-19 22:01:20', '2022-08-19 22:01:20'),
(1616, 609, 'action started via WP Cron', '2022-08-19 22:52:53', '2022-08-19 22:52:53'),
(1617, 609, 'action complete via WP Cron', '2022-08-19 22:52:53', '2022-08-19 22:52:53'),
(1618, 610, 'action created', '2022-08-19 22:52:53', '2022-08-19 22:52:53'),
(1619, 610, 'action started via WP Cron', '2022-08-19 23:43:47', '2022-08-19 23:43:47'),
(1620, 610, 'action complete via WP Cron', '2022-08-19 23:43:47', '2022-08-19 23:43:47'),
(1621, 611, 'action created', '2022-08-19 23:43:47', '2022-08-19 23:43:47'),
(1622, 611, 'action started via WP Cron', '2022-08-20 00:12:31', '2022-08-20 00:12:31'),
(1623, 611, 'action complete via WP Cron', '2022-08-20 00:12:31', '2022-08-20 00:12:31'),
(1624, 612, 'action created', '2022-08-20 01:50:58', '2022-08-20 01:50:58'),
(1625, 612, 'action started via WP Cron', '2022-08-20 02:35:38', '2022-08-20 02:35:38'),
(1626, 612, 'action complete via WP Cron', '2022-08-20 02:35:38', '2022-08-20 02:35:38'),
(1627, 613, 'action created', '2022-08-20 05:13:24', '2022-08-20 05:13:24'),
(1628, 613, 'action started via WP Cron', '2022-08-20 06:12:27', '2022-08-20 06:12:27'),
(1629, 613, 'action complete via WP Cron', '2022-08-20 06:12:28', '2022-08-20 06:12:28'),
(1630, 614, 'action created', '2022-08-20 06:12:28', '2022-08-20 06:12:28'),
(1631, 614, 'action started via WP Cron', '2022-08-20 06:50:05', '2022-08-20 06:50:05'),
(1632, 614, 'action complete via WP Cron', '2022-08-20 06:50:05', '2022-08-20 06:50:05'),
(1633, 615, 'action created', '2022-08-20 06:50:05', '2022-08-20 06:50:05'),
(1634, 615, 'action started via WP Cron', '2022-08-20 07:26:39', '2022-08-20 07:26:39'),
(1635, 615, 'action complete via WP Cron', '2022-08-20 07:26:39', '2022-08-20 07:26:39'),
(1636, 616, 'action created', '2022-08-20 07:47:53', '2022-08-20 07:47:53'),
(1637, 617, 'action created', '2022-08-20 07:47:53', '2022-08-20 07:47:53'),
(1638, 616, 'action started via WP Cron', '2022-08-20 08:16:56', '2022-08-20 08:16:56'),
(1639, 616, 'action complete via WP Cron', '2022-08-20 08:16:56', '2022-08-20 08:16:56'),
(1640, 617, 'action started via WP Cron', '2022-08-20 08:16:56', '2022-08-20 08:16:56'),
(1641, 617, 'action complete via WP Cron', '2022-08-20 08:16:56', '2022-08-20 08:16:56'),
(1642, 618, 'action created', '2022-08-20 09:00:00', '2022-08-20 09:00:00'),
(1643, 618, 'action started via WP Cron', '2022-08-20 10:06:44', '2022-08-20 10:06:44'),
(1644, 618, 'action complete via WP Cron', '2022-08-20 10:06:44', '2022-08-20 10:06:44'),
(1645, 619, 'action created', '2022-08-20 10:06:44', '2022-08-20 10:06:44'),
(1646, 619, 'action started via WP Cron', '2022-08-20 11:23:21', '2022-08-20 11:23:21'),
(1647, 619, 'action complete via WP Cron', '2022-08-20 11:23:21', '2022-08-20 11:23:21'),
(1648, 620, 'action created', '2022-08-20 11:23:21', '2022-08-20 11:23:21'),
(1649, 620, 'action started via WP Cron', '2022-08-20 11:27:01', '2022-08-20 11:27:01'),
(1650, 620, 'action complete via WP Cron', '2022-08-20 11:27:01', '2022-08-20 11:27:01'),
(1651, 621, 'action created', '2022-08-20 13:26:02', '2022-08-20 13:26:02'),
(1652, 621, 'action started via WP Cron', '2022-08-20 15:04:32', '2022-08-20 15:04:32'),
(1653, 621, 'action complete via WP Cron', '2022-08-20 15:04:32', '2022-08-20 15:04:32'),
(1654, 622, 'action created', '2022-08-20 15:04:32', '2022-08-20 15:04:32'),
(1655, 622, 'action started via WP Cron', '2022-08-20 15:11:20', '2022-08-20 15:11:20'),
(1656, 622, 'action complete via WP Cron', '2022-08-20 15:11:20', '2022-08-20 15:11:20'),
(1657, 623, 'action created', '2022-08-20 15:59:39', '2022-08-20 15:59:39'),
(1658, 623, 'action started via WP Cron', '2022-08-20 18:29:53', '2022-08-20 18:29:53'),
(1659, 623, 'action complete via WP Cron', '2022-08-20 18:29:53', '2022-08-20 18:29:53'),
(1660, 624, 'action created', '2022-08-20 18:29:54', '2022-08-20 18:29:54'),
(1661, 624, 'action started via WP Cron', '2022-08-20 18:46:09', '2022-08-20 18:46:09'),
(1662, 624, 'action complete via WP Cron', '2022-08-20 18:46:09', '2022-08-20 18:46:09'),
(1663, 625, 'action created', '2022-08-20 18:46:09', '2022-08-20 18:46:09'),
(1664, 625, 'action started via WP Cron', '2022-08-20 21:37:50', '2022-08-20 21:37:50'),
(1665, 625, 'action complete via WP Cron', '2022-08-20 21:37:50', '2022-08-20 21:37:50'),
(1666, 626, 'action created', '2022-08-20 21:37:50', '2022-08-20 21:37:50'),
(1667, 626, 'action started via WP Cron', '2022-08-21 00:34:49', '2022-08-21 00:34:49'),
(1668, 626, 'action complete via WP Cron', '2022-08-21 00:34:49', '2022-08-21 00:34:49'),
(1669, 627, 'action created', '2022-08-21 00:34:49', '2022-08-21 00:34:49'),
(1670, 627, 'action started via WP Cron', '2022-08-21 00:43:21', '2022-08-21 00:43:21'),
(1671, 627, 'action complete via WP Cron', '2022-08-21 00:43:21', '2022-08-21 00:43:21'),
(1672, 628, 'action created', '2022-08-21 00:43:21', '2022-08-21 00:43:21'),
(1673, 628, 'action started via WP Cron', '2022-08-21 01:12:42', '2022-08-21 01:12:42'),
(1674, 628, 'action complete via WP Cron', '2022-08-21 01:12:42', '2022-08-21 01:12:42'),
(1675, 629, 'action created', '2022-08-21 02:37:09', '2022-08-21 02:37:09'),
(1676, 629, 'action started via WP Cron', '2022-08-21 02:44:22', '2022-08-21 02:44:22'),
(1677, 629, 'action complete via WP Cron', '2022-08-21 02:44:22', '2022-08-21 02:44:22'),
(1678, 630, 'action created', '2022-08-21 02:44:22', '2022-08-21 02:44:22'),
(1679, 630, 'action started via WP Cron', '2022-08-21 04:12:48', '2022-08-21 04:12:48'),
(1680, 630, 'action complete via WP Cron', '2022-08-21 04:12:48', '2022-08-21 04:12:48'),
(1681, 631, 'action created', '2022-08-21 04:12:48', '2022-08-21 04:12:48'),
(1682, 631, 'action started via WP Cron', '2022-08-21 04:14:11', '2022-08-21 04:14:11'),
(1683, 631, 'action complete via WP Cron', '2022-08-21 04:14:11', '2022-08-21 04:14:11'),
(1684, 632, 'action created', '2022-08-21 05:21:25', '2022-08-21 05:21:25'),
(1685, 632, 'action started via WP Cron', '2022-08-21 06:04:20', '2022-08-21 06:04:20'),
(1686, 632, 'action complete via WP Cron', '2022-08-21 06:04:20', '2022-08-21 06:04:20'),
(1687, 633, 'action created', '2022-08-21 06:04:20', '2022-08-21 06:04:20'),
(1688, 633, 'action started via WP Cron', '2022-08-21 06:11:28', '2022-08-21 06:11:28'),
(1689, 633, 'action complete via WP Cron', '2022-08-21 06:11:28', '2022-08-21 06:11:28'),
(1690, 634, 'action created', '2022-08-21 07:10:03', '2022-08-21 07:10:03'),
(1691, 634, 'action started via WP Cron', '2022-08-21 07:32:53', '2022-08-21 07:32:53'),
(1692, 634, 'action complete via WP Cron', '2022-08-21 07:32:53', '2022-08-21 07:32:53'),
(1693, 635, 'action created', '2022-08-21 08:32:16', '2022-08-21 08:32:16'),
(1694, 636, 'action created', '2022-08-21 08:32:16', '2022-08-21 08:32:16'),
(1695, 635, 'action started via WP Cron', '2022-08-21 09:00:13', '2022-08-21 09:00:13'),
(1696, 635, 'action complete via WP Cron', '2022-08-21 09:00:13', '2022-08-21 09:00:13'),
(1697, 636, 'action started via WP Cron', '2022-08-21 09:00:13', '2022-08-21 09:00:13'),
(1698, 636, 'action complete via WP Cron', '2022-08-21 09:00:13', '2022-08-21 09:00:13'),
(1699, 637, 'action created', '2022-08-21 09:00:13', '2022-08-21 09:00:13'),
(1700, 637, 'action started via WP Cron', '2022-08-21 09:00:30', '2022-08-21 09:00:30'),
(1701, 637, 'action complete via WP Cron', '2022-08-21 09:00:30', '2022-08-21 09:00:30'),
(1702, 638, 'action created', '2022-08-21 11:13:38', '2022-08-21 11:13:38'),
(1703, 638, 'action started via WP Cron', '2022-08-21 11:26:17', '2022-08-21 11:26:17'),
(1704, 638, 'action complete via WP Cron', '2022-08-21 11:26:17', '2022-08-21 11:26:17'),
(1705, 639, 'action created', '2022-08-21 12:14:27', '2022-08-21 12:14:27'),
(1706, 639, 'action started via WP Cron', '2022-08-21 12:15:21', '2022-08-21 12:15:21'),
(1707, 639, 'action complete via WP Cron', '2022-08-21 12:15:21', '2022-08-21 12:15:21'),
(1708, 640, 'action created', '2022-08-21 15:12:08', '2022-08-21 15:12:08'),
(1709, 640, 'action started via WP Cron', '2022-08-21 15:27:29', '2022-08-21 15:27:29'),
(1710, 640, 'action complete via WP Cron', '2022-08-21 15:27:29', '2022-08-21 15:27:29'),
(1711, 641, 'action created', '2022-08-21 16:20:08', '2022-08-21 16:20:08'),
(1712, 641, 'action started via WP Cron', '2022-08-21 16:20:08', '2022-08-21 16:20:08'),
(1713, 641, 'action complete via WP Cron', '2022-08-21 16:20:08', '2022-08-21 16:20:08'),
(1714, 642, 'action created', '2022-08-21 17:49:35', '2022-08-21 17:49:35'),
(1715, 642, 'action started via WP Cron', '2022-08-21 18:11:30', '2022-08-21 18:11:30'),
(1716, 642, 'action complete via WP Cron', '2022-08-21 18:11:30', '2022-08-21 18:11:30'),
(1717, 643, 'action created', '2022-08-21 21:13:56', '2022-08-21 21:13:56'),
(1718, 643, 'action started via WP Cron', '2022-08-22 00:24:42', '2022-08-22 00:24:42'),
(1719, 643, 'action complete via WP Cron', '2022-08-22 00:24:42', '2022-08-22 00:24:42'),
(1720, 644, 'action created', '2022-08-22 00:24:42', '2022-08-22 00:24:42'),
(1721, 644, 'action started via WP Cron', '2022-08-22 01:43:29', '2022-08-22 01:43:29'),
(1722, 644, 'action complete via WP Cron', '2022-08-22 01:43:29', '2022-08-22 01:43:29'),
(1723, 645, 'action created', '2022-08-22 01:43:29', '2022-08-22 01:43:29'),
(1724, 645, 'action started via WP Cron', '2022-08-22 02:13:17', '2022-08-22 02:13:17'),
(1725, 645, 'action complete via WP Cron', '2022-08-22 02:13:17', '2022-08-22 02:13:17'),
(1726, 646, 'action created', '2022-08-22 02:45:37', '2022-08-22 02:45:37'),
(1727, 646, 'action started via WP Cron', '2022-08-22 03:13:15', '2022-08-22 03:13:15'),
(1728, 646, 'action complete via WP Cron', '2022-08-22 03:13:15', '2022-08-22 03:13:15'),
(1729, 647, 'action created', '2022-08-22 04:58:50', '2022-08-22 04:58:50'),
(1730, 647, 'action started via WP Cron', '2022-08-22 04:59:16', '2022-08-22 04:59:16'),
(1731, 647, 'action complete via WP Cron', '2022-08-22 04:59:16', '2022-08-22 04:59:16'),
(1732, 648, 'action created', '2022-08-22 06:19:00', '2022-08-22 06:19:00'),
(1733, 648, 'action started via WP Cron', '2022-08-22 06:59:00', '2022-08-22 06:59:00'),
(1734, 648, 'action complete via WP Cron', '2022-08-22 06:59:00', '2022-08-22 06:59:00'),
(1735, 649, 'action created', '2022-08-22 06:59:00', '2022-08-22 06:59:00'),
(1736, 649, 'action started via WP Cron', '2022-08-22 07:06:16', '2022-08-22 07:06:16'),
(1737, 649, 'action complete via WP Cron', '2022-08-22 07:06:16', '2022-08-22 07:06:16'),
(1738, 650, 'action created', '2022-08-22 07:46:35', '2022-08-22 07:46:35'),
(1739, 651, 'action created', '2022-08-22 07:46:35', '2022-08-22 07:46:35'),
(1740, 650, 'action started via WP Cron', '2022-08-22 07:56:10', '2022-08-22 07:56:10'),
(1741, 650, 'action complete via WP Cron', '2022-08-22 07:56:10', '2022-08-22 07:56:10'),
(1742, 651, 'action started via WP Cron', '2022-08-22 07:56:10', '2022-08-22 07:56:10'),
(1743, 651, 'action complete via WP Cron', '2022-08-22 07:56:10', '2022-08-22 07:56:10'),
(1744, 652, 'action created', '2022-08-22 11:17:28', '2022-08-22 11:17:28'),
(1745, 652, 'action started via WP Cron', '2022-08-22 13:29:17', '2022-08-22 13:29:17'),
(1746, 652, 'action complete via WP Cron', '2022-08-22 13:29:17', '2022-08-22 13:29:17'),
(1747, 653, 'action created', '2022-08-22 13:29:17', '2022-08-22 13:29:17'),
(1748, 653, 'action started via WP Cron', '2022-08-22 13:33:48', '2022-08-22 13:33:48'),
(1749, 653, 'action complete via WP Cron', '2022-08-22 13:33:48', '2022-08-22 13:33:48'),
(1750, 654, 'action created', '2022-08-22 15:29:16', '2022-08-22 15:29:16'),
(1751, 654, 'action started via WP Cron', '2022-08-22 15:29:16', '2022-08-22 15:29:16'),
(1752, 654, 'action complete via WP Cron', '2022-08-22 15:29:16', '2022-08-22 15:29:16'),
(1753, 655, 'action created', '2022-08-22 16:56:57', '2022-08-22 16:56:57'),
(1754, 655, 'action started via WP Cron', '2022-08-22 18:02:39', '2022-08-22 18:02:39'),
(1755, 655, 'action complete via WP Cron', '2022-08-22 18:02:39', '2022-08-22 18:02:39'),
(1756, 656, 'action created', '2022-08-22 18:02:40', '2022-08-22 18:02:40'),
(1757, 656, 'action started via WP Cron', '2022-08-22 18:33:40', '2022-08-22 18:33:40'),
(1758, 656, 'action complete via WP Cron', '2022-08-22 18:33:40', '2022-08-22 18:33:40'),
(1759, 657, 'action created', '2022-08-22 18:50:00', '2022-08-22 18:50:00'),
(1760, 657, 'action started via WP Cron', '2022-08-22 20:08:56', '2022-08-22 20:08:56'),
(1761, 657, 'action complete via WP Cron', '2022-08-22 20:08:56', '2022-08-22 20:08:56'),
(1762, 658, 'action created', '2022-08-22 20:08:56', '2022-08-22 20:08:56'),
(1763, 658, 'action started via WP Cron', '2022-08-22 22:20:44', '2022-08-22 22:20:44'),
(1764, 658, 'action complete via WP Cron', '2022-08-22 22:20:44', '2022-08-22 22:20:44'),
(1765, 659, 'action created', '2022-08-22 22:20:44', '2022-08-22 22:20:44'),
(1766, 659, 'action started via WP Cron', '2022-08-22 22:31:50', '2022-08-22 22:31:50'),
(1767, 659, 'action complete via WP Cron', '2022-08-22 22:31:50', '2022-08-22 22:31:50'),
(1768, 660, 'action created', '2022-08-22 23:37:21', '2022-08-22 23:37:21'),
(1769, 660, 'action started via WP Cron', '2022-08-23 02:42:14', '2022-08-23 02:42:14'),
(1770, 660, 'action complete via WP Cron', '2022-08-23 02:42:14', '2022-08-23 02:42:14'),
(1771, 661, 'action created', '2022-08-23 02:42:15', '2022-08-23 02:42:15'),
(1772, 662, 'action created', '2022-08-23 03:01:17', '2022-08-23 03:01:17'),
(1773, 661, 'action started via WP Cron', '2022-08-23 03:01:18', '2022-08-23 03:01:18'),
(1774, 661, 'action complete via WP Cron', '2022-08-23 03:01:18', '2022-08-23 03:01:18'),
(1775, 662, 'action started via WP Cron', '2022-08-23 03:01:18', '2022-08-23 03:01:18'),
(1776, 662, 'action complete via WP Cron', '2022-08-23 03:01:18', '2022-08-23 03:01:18'),
(1777, 663, 'action created', '2022-08-23 04:13:04', '2022-08-23 04:13:04'),
(1778, 663, 'action started via WP Cron', '2022-08-23 04:13:23', '2022-08-23 04:13:23'),
(1779, 663, 'action complete via WP Cron', '2022-08-23 04:13:23', '2022-08-23 04:13:23'),
(1780, 664, 'action created', '2022-08-23 04:52:14', '2022-08-23 04:52:14'),
(1781, 664, 'action started via WP Cron', '2022-08-23 05:07:25', '2022-08-23 05:07:25'),
(1782, 664, 'action complete via WP Cron', '2022-08-23 05:07:25', '2022-08-23 05:07:25'),
(1783, 665, 'action created', '2022-08-23 05:43:59', '2022-08-23 05:43:59'),
(1784, 665, 'action started via WP Cron', '2022-08-23 05:44:36', '2022-08-23 05:44:36'),
(1785, 665, 'action complete via WP Cron', '2022-08-23 05:44:36', '2022-08-23 05:44:36'),
(1786, 666, 'action created', '2022-08-23 07:30:59', '2022-08-23 07:30:59'),
(1787, 666, 'action started via WP Cron', '2022-08-23 09:17:11', '2022-08-23 09:17:11'),
(1788, 666, 'action complete via WP Cron', '2022-08-23 09:17:11', '2022-08-23 09:17:11'),
(1789, 667, 'action created', '2022-08-23 09:17:11', '2022-08-23 09:17:11'),
(1790, 668, 'action created', '2022-08-23 09:17:11', '2022-08-23 09:17:11'),
(1791, 667, 'action started via WP Cron', '2022-08-23 13:25:35', '2022-08-23 13:25:35'),
(1792, 667, 'action complete via WP Cron', '2022-08-23 13:25:35', '2022-08-23 13:25:35'),
(1793, 668, 'action started via WP Cron', '2022-08-23 13:25:35', '2022-08-23 13:25:35'),
(1794, 668, 'action complete via WP Cron', '2022-08-23 13:25:35', '2022-08-23 13:25:35'),
(1795, 553, 'action started via WP Cron', '2022-08-23 13:25:35', '2022-08-23 13:25:35'),
(1796, 553, 'action complete via WP Cron', '2022-08-23 13:25:35', '2022-08-23 13:25:35'),
(1797, 669, 'action created', '2022-08-23 13:25:35', '2022-08-23 13:25:35'),
(1798, 670, 'action created', '2022-08-23 13:25:35', '2022-08-23 13:25:35'),
(1799, 670, 'action started via WP Cron', '2022-08-23 13:33:55', '2022-08-23 13:33:55'),
(1800, 670, 'action complete via WP Cron', '2022-08-23 13:33:55', '2022-08-23 13:33:55'),
(1801, 671, 'action created', '2022-08-23 15:11:02', '2022-08-23 15:11:02'),
(1802, 671, 'action started via WP Cron', '2022-08-23 15:24:32', '2022-08-23 15:24:32'),
(1803, 671, 'action complete via WP Cron', '2022-08-23 15:24:32', '2022-08-23 15:24:32'),
(1804, 672, 'action created', '2022-08-23 15:50:49', '2022-08-23 15:50:49'),
(1805, 672, 'action started via WP Cron', '2022-08-23 15:59:27', '2022-08-23 15:59:27'),
(1806, 672, 'action complete via WP Cron', '2022-08-23 15:59:27', '2022-08-23 15:59:27'),
(1807, 673, 'action created', '2022-08-23 18:27:35', '2022-08-23 18:27:35'),
(1808, 673, 'action started via WP Cron', '2022-08-23 21:41:35', '2022-08-23 21:41:35'),
(1809, 673, 'action complete via WP Cron', '2022-08-23 21:41:35', '2022-08-23 21:41:35'),
(1810, 674, 'action created', '2022-08-23 21:41:35', '2022-08-23 21:41:35'),
(1811, 674, 'action started via WP Cron', '2022-08-23 22:24:08', '2022-08-23 22:24:08'),
(1812, 674, 'action complete via WP Cron', '2022-08-23 22:24:08', '2022-08-23 22:24:08'),
(1813, 675, 'action created', '2022-08-23 22:24:09', '2022-08-23 22:24:09'),
(1814, 675, 'action started via WP Cron', '2022-08-23 22:41:30', '2022-08-23 22:41:30'),
(1815, 675, 'action complete via WP Cron', '2022-08-23 22:41:30', '2022-08-23 22:41:30'),
(1816, 676, 'action created', '2022-08-23 23:30:58', '2022-08-23 23:30:58'),
(1817, 676, 'action started via WP Cron', '2022-08-24 00:54:43', '2022-08-24 00:54:43'),
(1818, 676, 'action complete via WP Cron', '2022-08-24 00:54:43', '2022-08-24 00:54:43'),
(1819, 677, 'action created', '2022-08-24 00:54:43', '2022-08-24 00:54:43'),
(1820, 677, 'action started via WP Cron', '2022-08-24 01:27:05', '2022-08-24 01:27:05'),
(1821, 677, 'action complete via WP Cron', '2022-08-24 01:27:05', '2022-08-24 01:27:05'),
(1822, 678, 'action created', '2022-08-24 02:46:52', '2022-08-24 02:46:52'),
(1823, 678, 'action started via WP Cron', '2022-08-24 03:06:16', '2022-08-24 03:06:16'),
(1824, 678, 'action complete via WP Cron', '2022-08-24 03:06:16', '2022-08-24 03:06:16'),
(1825, 679, 'action created', '2022-08-24 04:20:45', '2022-08-24 04:20:45');

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `comment_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint UNSIGNED NOT NULL,
  `comment_post_ID` bigint UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Một người bình luận WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-07-01 02:30:09', '2022-07-01 02:30:09', 'Xin chào, đây là một bình luận\nĐể bắt đầu với quản trị bình luận, chỉnh sửa hoặc xóa bình luận, vui lòng truy cập vào khu vực Bình luận trong trang quản trị.\nAvatar của người bình luận sử dụng <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE `wp_links` (
  `link_id` bigint UNSIGNED NOT NULL,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint UNSIGNED NOT NULL,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'https://traininghub-uat.vus.edu.vn', 'yes'),
(2, 'home', 'https://traininghub-uat.vus.edu.vn', 'yes'),
(3, 'blogname', 'Training HUB', 'yes'),
(4, 'blogdescription', 'VUS', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'heckmanle@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '20', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '20', 'yes'),
(23, 'date_format', 'j F, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'j F, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:324:{s:29:\"courses/(.+?)/lesson/(.+?)/?$\";s:43:\"index.php?post_type=lesson&name=$matches[2]\";s:33:\"courses/(.+?)/tutor_quiz/(.+?)/?$\";s:47:\"index.php?post_type=tutor_quiz&name=$matches[2]\";s:34:\"courses/(.+?)/assignments/(.+?)/?$\";s:54:\"index.php?post_type=tutor_assignments&name=$matches[2]\";s:35:\"courses/(.+?)/zoom-meeting/(.+?)/?$\";s:55:\"index.php?post_type=tutor_zoom_meeting&name=$matches[2]\";s:18:\"video-url/(.+?)/?$\";s:61:\"index.php?post_type=lesson&lesson_video=true&name=$matches[1]\";s:16:\"profile/(.+?)/?$\";s:44:\"index.php?tutor_profile_username=$matches[1]\";s:20:\"(dashboard)/index/?$\";s:57:\"index.php?pagename=$matches[1]&tutor_dashboard_page=index\";s:26:\"(dashboard)/index/(.+?)/?$\";s:94:\"index.php?pagename=$matches[1]&tutor_dashboard_page=index&tutor_dashboard_sub_page=$matches[2]\";s:25:\"(dashboard)/my-profile/?$\";s:62:\"index.php?pagename=$matches[1]&tutor_dashboard_page=my-profile\";s:31:\"(dashboard)/my-profile/(.+?)/?$\";s:99:\"index.php?pagename=$matches[1]&tutor_dashboard_page=my-profile&tutor_dashboard_sub_page=$matches[2]\";s:31:\"(dashboard)/enrolled-courses/?$\";s:68:\"index.php?pagename=$matches[1]&tutor_dashboard_page=enrolled-courses\";s:37:\"(dashboard)/enrolled-courses/(.+?)/?$\";s:105:\"index.php?pagename=$matches[1]&tutor_dashboard_page=enrolled-courses&tutor_dashboard_sub_page=$matches[2]\";s:23:\"(dashboard)/wishlist/?$\";s:60:\"index.php?pagename=$matches[1]&tutor_dashboard_page=wishlist\";s:29:\"(dashboard)/wishlist/(.+?)/?$\";s:97:\"index.php?pagename=$matches[1]&tutor_dashboard_page=wishlist&tutor_dashboard_sub_page=$matches[2]\";s:22:\"(dashboard)/reviews/?$\";s:59:\"index.php?pagename=$matches[1]&tutor_dashboard_page=reviews\";s:28:\"(dashboard)/reviews/(.+?)/?$\";s:96:\"index.php?pagename=$matches[1]&tutor_dashboard_page=reviews&tutor_dashboard_sub_page=$matches[2]\";s:31:\"(dashboard)/my-quiz-attempts/?$\";s:68:\"index.php?pagename=$matches[1]&tutor_dashboard_page=my-quiz-attempts\";s:37:\"(dashboard)/my-quiz-attempts/(.+?)/?$\";s:105:\"index.php?pagename=$matches[1]&tutor_dashboard_page=my-quiz-attempts&tutor_dashboard_sub_page=$matches[2]\";s:31:\"(dashboard)/purchase_history/?$\";s:68:\"index.php?pagename=$matches[1]&tutor_dashboard_page=purchase_history\";s:37:\"(dashboard)/purchase_history/(.+?)/?$\";s:105:\"index.php?pagename=$matches[1]&tutor_dashboard_page=purchase_history&tutor_dashboard_sub_page=$matches[2]\";s:30:\"(dashboard)/question-answer/?$\";s:67:\"index.php?pagename=$matches[1]&tutor_dashboard_page=question-answer\";s:36:\"(dashboard)/question-answer/(.+?)/?$\";s:104:\"index.php?pagename=$matches[1]&tutor_dashboard_page=question-answer&tutor_dashboard_sub_page=$matches[2]\";s:23:\"(dashboard)/calendar/?$\";s:60:\"index.php?pagename=$matches[1]&tutor_dashboard_page=calendar\";s:29:\"(dashboard)/calendar/(.+?)/?$\";s:97:\"index.php?pagename=$matches[1]&tutor_dashboard_page=calendar&tutor_dashboard_sub_page=$matches[2]\";s:26:\"(dashboard)/separator-1/?$\";s:63:\"index.php?pagename=$matches[1]&tutor_dashboard_page=separator-1\";s:32:\"(dashboard)/separator-1/(.+?)/?$\";s:100:\"index.php?pagename=$matches[1]&tutor_dashboard_page=separator-1&tutor_dashboard_sub_page=$matches[2]\";s:28:\"(dashboard)/create-course/?$\";s:65:\"index.php?pagename=$matches[1]&tutor_dashboard_page=create-course\";s:34:\"(dashboard)/create-course/(.+?)/?$\";s:102:\"index.php?pagename=$matches[1]&tutor_dashboard_page=create-course&tutor_dashboard_sub_page=$matches[2]\";s:25:\"(dashboard)/my-courses/?$\";s:62:\"index.php?pagename=$matches[1]&tutor_dashboard_page=my-courses\";s:31:\"(dashboard)/my-courses/(.+?)/?$\";s:99:\"index.php?pagename=$matches[1]&tutor_dashboard_page=my-courses&tutor_dashboard_sub_page=$matches[2]\";s:28:\"(dashboard)/announcements/?$\";s:65:\"index.php?pagename=$matches[1]&tutor_dashboard_page=announcements\";s:34:\"(dashboard)/announcements/(.+?)/?$\";s:102:\"index.php?pagename=$matches[1]&tutor_dashboard_page=announcements&tutor_dashboard_sub_page=$matches[2]\";s:23:\"(dashboard)/withdraw/?$\";s:60:\"index.php?pagename=$matches[1]&tutor_dashboard_page=withdraw\";s:29:\"(dashboard)/withdraw/(.+?)/?$\";s:97:\"index.php?pagename=$matches[1]&tutor_dashboard_page=withdraw&tutor_dashboard_sub_page=$matches[2]\";s:28:\"(dashboard)/quiz-attempts/?$\";s:65:\"index.php?pagename=$matches[1]&tutor_dashboard_page=quiz-attempts\";s:34:\"(dashboard)/quiz-attempts/(.+?)/?$\";s:102:\"index.php?pagename=$matches[1]&tutor_dashboard_page=quiz-attempts&tutor_dashboard_sub_page=$matches[2]\";s:26:\"(dashboard)/assignments/?$\";s:63:\"index.php?pagename=$matches[1]&tutor_dashboard_page=assignments\";s:32:\"(dashboard)/assignments/(.+?)/?$\";s:100:\"index.php?pagename=$matches[1]&tutor_dashboard_page=assignments&tutor_dashboard_sub_page=$matches[2]\";s:24:\"(dashboard)/analytics/?$\";s:61:\"index.php?pagename=$matches[1]&tutor_dashboard_page=analytics\";s:30:\"(dashboard)/analytics/(.+?)/?$\";s:98:\"index.php?pagename=$matches[1]&tutor_dashboard_page=analytics&tutor_dashboard_sub_page=$matches[2]\";s:26:\"(dashboard)/separator-2/?$\";s:63:\"index.php?pagename=$matches[1]&tutor_dashboard_page=separator-2\";s:32:\"(dashboard)/separator-2/(.+?)/?$\";s:100:\"index.php?pagename=$matches[1]&tutor_dashboard_page=separator-2&tutor_dashboard_sub_page=$matches[2]\";s:23:\"(dashboard)/settings/?$\";s:60:\"index.php?pagename=$matches[1]&tutor_dashboard_page=settings\";s:29:\"(dashboard)/settings/(.+?)/?$\";s:97:\"index.php?pagename=$matches[1]&tutor_dashboard_page=settings&tutor_dashboard_sub_page=$matches[2]\";s:21:\"(dashboard)/logout/?$\";s:58:\"index.php?pagename=$matches[1]&tutor_dashboard_page=logout\";s:27:\"(dashboard)/logout/(.+?)/?$\";s:95:\"index.php?pagename=$matches[1]&tutor_dashboard_page=logout&tutor_dashboard_sub_page=$matches[2]\";s:32:\"(dashboard)/retrieve-password/?$\";s:69:\"index.php?pagename=$matches[1]&tutor_dashboard_page=retrieve-password\";s:38:\"(dashboard)/retrieve-password/(.+?)/?$\";s:106:\"index.php?pagename=$matches[1]&tutor_dashboard_page=retrieve-password&tutor_dashboard_sub_page=$matches[2]\";s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:10:\"courses/?$\";s:27:\"index.php?post_type=courses\";s:40:\"courses/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=courses&feed=$matches[1]\";s:35:\"courses/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=courses&feed=$matches[1]\";s:27:\"courses/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=courses&paged=$matches[1]\";s:9:\"lesson/?$\";s:37:\"index.php?post_type=tutor_assignments\";s:39:\"lesson/feed/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?post_type=tutor_assignments&feed=$matches[1]\";s:34:\"lesson/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?post_type=tutor_assignments&feed=$matches[1]\";s:26:\"lesson/page/([0-9]{1,})/?$\";s:55:\"index.php?post_type=tutor_assignments&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"courses/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"courses/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"courses/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"courses/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"courses/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"courses/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"courses/([^/]+)/embed/?$\";s:40:\"index.php?courses=$matches[1]&embed=true\";s:28:\"courses/([^/]+)/trackback/?$\";s:34:\"index.php?courses=$matches[1]&tb=1\";s:48:\"courses/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?courses=$matches[1]&feed=$matches[2]\";s:43:\"courses/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?courses=$matches[1]&feed=$matches[2]\";s:36:\"courses/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?courses=$matches[1]&paged=$matches[2]\";s:43:\"courses/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?courses=$matches[1]&cpage=$matches[2]\";s:33:\"courses/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?courses=$matches[1]&wc-api=$matches[3]\";s:39:\"courses/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"courses/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"courses/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?courses=$matches[1]&page=$matches[2]\";s:24:\"courses/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"courses/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"courses/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"courses/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"courses/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"courses/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:56:\"course-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?course-category=$matches[1]&feed=$matches[2]\";s:51:\"course-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?course-category=$matches[1]&feed=$matches[2]\";s:32:\"course-category/([^/]+)/embed/?$\";s:48:\"index.php?course-category=$matches[1]&embed=true\";s:44:\"course-category/([^/]+)/page/?([0-9]{1,})/?$\";s:55:\"index.php?course-category=$matches[1]&paged=$matches[2]\";s:26:\"course-category/([^/]+)/?$\";s:37:\"index.php?course-category=$matches[1]\";s:51:\"course-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?course-tag=$matches[1]&feed=$matches[2]\";s:46:\"course-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?course-tag=$matches[1]&feed=$matches[2]\";s:27:\"course-tag/([^/]+)/embed/?$\";s:43:\"index.php?course-tag=$matches[1]&embed=true\";s:39:\"course-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:50:\"index.php?course-tag=$matches[1]&paged=$matches[2]\";s:21:\"course-tag/([^/]+)/?$\";s:32:\"index.php?course-tag=$matches[1]\";s:34:\"lesson/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"lesson/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"lesson/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"lesson/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"lesson/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"lesson/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:23:\"lesson/([^/]+)/embed/?$\";s:50:\"index.php?tutor_assignments=$matches[1]&embed=true\";s:27:\"lesson/([^/]+)/trackback/?$\";s:44:\"index.php?tutor_assignments=$matches[1]&tb=1\";s:47:\"lesson/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:56:\"index.php?tutor_assignments=$matches[1]&feed=$matches[2]\";s:42:\"lesson/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:56:\"index.php?tutor_assignments=$matches[1]&feed=$matches[2]\";s:35:\"lesson/([^/]+)/page/?([0-9]{1,})/?$\";s:57:\"index.php?tutor_assignments=$matches[1]&paged=$matches[2]\";s:42:\"lesson/([^/]+)/comment-page-([0-9]{1,})/?$\";s:57:\"index.php?tutor_assignments=$matches[1]&cpage=$matches[2]\";s:32:\"lesson/([^/]+)/wc-api(/(.*))?/?$\";s:58:\"index.php?tutor_assignments=$matches[1]&wc-api=$matches[3]\";s:38:\"lesson/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:49:\"lesson/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:31:\"lesson/([^/]+)(?:/([0-9]+))?/?$\";s:56:\"index.php?tutor_assignments=$matches[1]&page=$matches[2]\";s:23:\"lesson/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:33:\"lesson/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:53:\"lesson/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"lesson/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"lesson/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:29:\"lesson/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:34:\"topics/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"topics/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"topics/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"topics/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"topics/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"topics/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:23:\"topics/([^/]+)/embed/?$\";s:54:\"index.php?post_type=topics&name=$matches[1]&embed=true\";s:27:\"topics/([^/]+)/trackback/?$\";s:48:\"index.php?post_type=topics&name=$matches[1]&tb=1\";s:35:\"topics/([^/]+)/page/?([0-9]{1,})/?$\";s:61:\"index.php?post_type=topics&name=$matches[1]&paged=$matches[2]\";s:42:\"topics/([^/]+)/comment-page-([0-9]{1,})/?$\";s:61:\"index.php?post_type=topics&name=$matches[1]&cpage=$matches[2]\";s:32:\"topics/([^/]+)/wc-api(/(.*))?/?$\";s:62:\"index.php?post_type=topics&name=$matches[1]&wc-api=$matches[3]\";s:38:\"topics/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:49:\"topics/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:31:\"topics/([^/]+)(?:/([0-9]+))?/?$\";s:60:\"index.php?post_type=topics&name=$matches[1]&page=$matches[2]\";s:23:\"topics/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:33:\"topics/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:53:\"topics/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"topics/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"topics/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:29:\"topics/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:42:\"tutor_enrolled/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:52:\"tutor_enrolled/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:72:\"tutor_enrolled/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"tutor_enrolled/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"tutor_enrolled/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\"tutor_enrolled/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"tutor_enrolled/([^/]+)/embed/?$\";s:62:\"index.php?post_type=tutor_enrolled&name=$matches[1]&embed=true\";s:35:\"tutor_enrolled/([^/]+)/trackback/?$\";s:56:\"index.php?post_type=tutor_enrolled&name=$matches[1]&tb=1\";s:43:\"tutor_enrolled/([^/]+)/page/?([0-9]{1,})/?$\";s:69:\"index.php?post_type=tutor_enrolled&name=$matches[1]&paged=$matches[2]\";s:50:\"tutor_enrolled/([^/]+)/comment-page-([0-9]{1,})/?$\";s:69:\"index.php?post_type=tutor_enrolled&name=$matches[1]&cpage=$matches[2]\";s:40:\"tutor_enrolled/([^/]+)/wc-api(/(.*))?/?$\";s:70:\"index.php?post_type=tutor_enrolled&name=$matches[1]&wc-api=$matches[3]\";s:46:\"tutor_enrolled/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:57:\"tutor_enrolled/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:39:\"tutor_enrolled/([^/]+)(?:/([0-9]+))?/?$\";s:68:\"index.php?post_type=tutor_enrolled&name=$matches[1]&page=$matches[2]\";s:31:\"tutor_enrolled/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"tutor_enrolled/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"tutor_enrolled/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"tutor_enrolled/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"tutor_enrolled/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"tutor_enrolled/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:45:\"sp_wps_shortcodes/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:55:\"sp_wps_shortcodes/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:75:\"sp_wps_shortcodes/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"sp_wps_shortcodes/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"sp_wps_shortcodes/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:51:\"sp_wps_shortcodes/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:34:\"sp_wps_shortcodes/([^/]+)/embed/?$\";s:65:\"index.php?post_type=sp_wps_shortcodes&name=$matches[1]&embed=true\";s:38:\"sp_wps_shortcodes/([^/]+)/trackback/?$\";s:59:\"index.php?post_type=sp_wps_shortcodes&name=$matches[1]&tb=1\";s:46:\"sp_wps_shortcodes/([^/]+)/page/?([0-9]{1,})/?$\";s:72:\"index.php?post_type=sp_wps_shortcodes&name=$matches[1]&paged=$matches[2]\";s:53:\"sp_wps_shortcodes/([^/]+)/comment-page-([0-9]{1,})/?$\";s:72:\"index.php?post_type=sp_wps_shortcodes&name=$matches[1]&cpage=$matches[2]\";s:43:\"sp_wps_shortcodes/([^/]+)/wc-api(/(.*))?/?$\";s:73:\"index.php?post_type=sp_wps_shortcodes&name=$matches[1]&wc-api=$matches[3]\";s:49:\"sp_wps_shortcodes/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:60:\"sp_wps_shortcodes/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"sp_wps_shortcodes/([^/]+)(?:/([0-9]+))?/?$\";s:71:\"index.php?post_type=sp_wps_shortcodes&name=$matches[1]&page=$matches[2]\";s:34:\"sp_wps_shortcodes/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"sp_wps_shortcodes/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"sp_wps_shortcodes/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"sp_wps_shortcodes/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"sp_wps_shortcodes/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"sp_wps_shortcodes/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:55:\"fb_product_set/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:53:\"index.php?fb_product_set=$matches[1]&feed=$matches[2]\";s:50:\"fb_product_set/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:53:\"index.php?fb_product_set=$matches[1]&feed=$matches[2]\";s:31:\"fb_product_set/([^/]+)/embed/?$\";s:47:\"index.php?fb_product_set=$matches[1]&embed=true\";s:43:\"fb_product_set/([^/]+)/page/?([0-9]{1,})/?$\";s:54:\"index.php?fb_product_set=$matches[1]&paged=$matches[2]\";s:25:\"fb_product_set/([^/]+)/?$\";s:36:\"index.php?fb_product_set=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=93&cpage=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:25:\"([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?name=$matches[1]&wc-api=$matches[3]\";s:31:\"[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:15:{i:0;s:33:\"admin-menu-editor/menu-editor.php\";i:1;s:34:\"advanced-custom-fields-pro/acf.php\";i:2;s:32:\"dc-custom-admin/custom-admin.php\";i:3;s:53:\"facebook-for-woocommerce/facebook-for-woocommerce.php\";i:4;s:20:\"lmspro/tutor-pro.php\";i:5;s:37:\"post-types-order/post-types-order.php\";i:6;s:21:\"safe-svg/safe-svg.php\";i:7;s:45:\"taxonomy-terms-order/taxonomy-terms-order.php\";i:8;s:15:\"tutor/tutor.php\";i:9;s:37:\"user-role-editor/user-role-editor.php\";i:10;s:42:\"woo-product-bundle/wpc-product-bundles.php\";i:11;s:27:\"woo-product-slider/main.php\";i:12;s:37:\"woocommerce-ajax-cart/wooajaxcart.php\";i:13;s:27:\"woocommerce/woocommerce.php\";i:14;s:29:\"wp-mail-smtp/wp_mail_smtp.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'site_el', 'yes'),
(41, 'stylesheet', 'site_el', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '45805', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '93', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'admin_email_lifespan', '1672194609', 'yes'),
(94, 'initial_db_version', '45805', 'yes'),
(95, 'wp_user_roles', 'a:8:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:161:{s:16:\"activate_plugins\";b:1;s:20:\"assign_product_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:12:\"create_posts\";b:1;s:12:\"create_users\";b:1;s:19:\"delete_others_pages\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_others_products\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:12:\"delete_pages\";b:1;s:14:\"delete_plugins\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:23:\"delete_private_products\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:14:\"delete_product\";b:1;s:20:\"delete_product_terms\";b:1;s:15:\"delete_products\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:25:\"delete_published_products\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:18:\"delete_shop_coupon\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:19:\"delete_shop_coupons\";b:1;s:17:\"delete_shop_order\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:18:\"delete_shop_orders\";b:1;s:13:\"delete_themes\";b:1;s:24:\"delete_tutor_assignments\";b:1;s:19:\"delete_tutor_course\";b:1;s:20:\"delete_tutor_courses\";b:1;s:19:\"delete_tutor_lesson\";b:1;s:20:\"delete_tutor_lessons\";b:1;s:21:\"delete_tutor_question\";b:1;s:22:\"delete_tutor_questions\";b:1;s:17:\"delete_tutor_quiz\";b:1;s:20:\"delete_tutor_quizzes\";b:1;s:12:\"delete_users\";b:1;s:14:\"edit_dashboard\";b:1;s:10:\"edit_files\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_others_products\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:29:\"edit_others_tutor_assignments\";b:1;s:25:\"edit_others_tutor_courses\";b:1;s:25:\"edit_others_tutor_lessons\";b:1;s:27:\"edit_others_tutor_questions\";b:1;s:25:\"edit_others_tutor_quizzes\";b:1;s:10:\"edit_pages\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:21:\"edit_private_products\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:12:\"edit_product\";b:1;s:18:\"edit_product_terms\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_published_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:23:\"edit_published_products\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:16:\"edit_shop_coupon\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:17:\"edit_shop_coupons\";b:1;s:15:\"edit_shop_order\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:16:\"edit_shop_orders\";b:1;s:18:\"edit_theme_options\";b:1;s:11:\"edit_themes\";b:1;s:22:\"edit_tutor_assignments\";b:1;s:17:\"edit_tutor_course\";b:1;s:18:\"edit_tutor_courses\";b:1;s:17:\"edit_tutor_lesson\";b:1;s:18:\"edit_tutor_lessons\";b:1;s:19:\"edit_tutor_question\";b:1;s:20:\"edit_tutor_questions\";b:1;s:15:\"edit_tutor_quiz\";b:1;s:18:\"edit_tutor_quizzes\";b:1;s:10:\"edit_users\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:15:\"install_plugins\";b:1;s:14:\"install_themes\";b:1;s:7:\"level_0\";b:1;s:7:\"level_1\";b:1;s:8:\"level_10\";b:1;s:7:\"level_2\";b:1;s:7:\"level_3\";b:1;s:7:\"level_4\";b:1;s:7:\"level_5\";b:1;s:7:\"level_6\";b:1;s:7:\"level_7\";b:1;s:7:\"level_8\";b:1;s:7:\"level_9\";b:1;s:10:\"list_users\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:14:\"manage_options\";b:1;s:20:\"manage_product_terms\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:12:\"manage_tutor\";b:1;s:23:\"manage_tutor_instructor\";b:1;s:18:\"manage_woocommerce\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"promote_users\";b:1;s:13:\"publish_pages\";b:1;s:13:\"publish_posts\";b:1;s:16:\"publish_products\";b:1;s:20:\"publish_shop_coupons\";b:1;s:19:\"publish_shop_orders\";b:1;s:25:\"publish_tutor_assignments\";b:1;s:21:\"publish_tutor_courses\";b:1;s:21:\"publish_tutor_lessons\";b:1;s:23:\"publish_tutor_questions\";b:1;s:21:\"publish_tutor_quizzes\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:21:\"read_private_products\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:24:\"read_private_shop_orders\";b:1;s:30:\"read_private_tutor_assignments\";b:1;s:26:\"read_private_tutor_courses\";b:1;s:26:\"read_private_tutor_lessons\";b:1;s:28:\"read_private_tutor_questions\";b:1;s:26:\"read_private_tutor_quizzes\";b:1;s:12:\"read_product\";b:1;s:16:\"read_shop_coupon\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"read_tutor_course\";b:1;s:17:\"read_tutor_lesson\";b:1;s:19:\"read_tutor_question\";b:1;s:15:\"read_tutor_quiz\";b:1;s:12:\"remove_users\";b:1;s:13:\"switch_themes\";b:1;s:15:\"unfiltered_html\";b:1;s:17:\"unfiltered_upload\";b:1;s:11:\"update_core\";b:1;s:14:\"update_plugins\";b:1;s:13:\"update_themes\";b:1;s:12:\"upload_files\";b:1;s:23:\"ure_create_capabilities\";b:1;s:16:\"ure_create_roles\";b:1;s:23:\"ure_delete_capabilities\";b:1;s:16:\"ure_delete_roles\";b:1;s:14:\"ure_edit_roles\";b:1;s:18:\"ure_manage_options\";b:1;s:15:\"ure_reset_roles\";b:1;s:24:\"view_woocommerce_reports\";b:1;}}s:6:\"admins\";a:2:{s:4:\"name\";s:6:\"Admins\";s:12:\"capabilities\";a:151:{s:20:\"assign_product_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:12:\"create_posts\";b:1;s:12:\"create_users\";b:1;s:19:\"delete_others_pages\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_others_products\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:12:\"delete_pages\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:23:\"delete_private_products\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:14:\"delete_product\";b:1;s:20:\"delete_product_terms\";b:1;s:15:\"delete_products\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:25:\"delete_published_products\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:18:\"delete_shop_coupon\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:19:\"delete_shop_coupons\";b:1;s:17:\"delete_shop_order\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:18:\"delete_shop_orders\";b:1;s:24:\"delete_tutor_assignments\";b:1;s:19:\"delete_tutor_course\";b:1;s:20:\"delete_tutor_courses\";b:1;s:19:\"delete_tutor_lesson\";b:1;s:20:\"delete_tutor_lessons\";b:1;s:21:\"delete_tutor_question\";b:1;s:22:\"delete_tutor_questions\";b:1;s:17:\"delete_tutor_quiz\";b:1;s:20:\"delete_tutor_quizzes\";b:1;s:12:\"delete_users\";b:1;s:14:\"edit_dashboard\";b:1;s:10:\"edit_files\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_others_products\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:29:\"edit_others_tutor_assignments\";b:1;s:25:\"edit_others_tutor_courses\";b:1;s:25:\"edit_others_tutor_lessons\";b:1;s:27:\"edit_others_tutor_questions\";b:1;s:25:\"edit_others_tutor_quizzes\";b:1;s:10:\"edit_pages\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:21:\"edit_private_products\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:12:\"edit_product\";b:1;s:18:\"edit_product_terms\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_published_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:23:\"edit_published_products\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:16:\"edit_shop_coupon\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:17:\"edit_shop_coupons\";b:1;s:15:\"edit_shop_order\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:16:\"edit_shop_orders\";b:1;s:22:\"edit_tutor_assignments\";b:1;s:17:\"edit_tutor_course\";b:1;s:18:\"edit_tutor_courses\";b:1;s:17:\"edit_tutor_lesson\";b:1;s:18:\"edit_tutor_lessons\";b:1;s:19:\"edit_tutor_question\";b:1;s:20:\"edit_tutor_questions\";b:1;s:15:\"edit_tutor_quiz\";b:1;s:18:\"edit_tutor_quizzes\";b:1;s:10:\"edit_users\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:7:\"level_0\";b:1;s:7:\"level_1\";b:1;s:8:\"level_10\";b:1;s:7:\"level_2\";b:1;s:7:\"level_3\";b:1;s:7:\"level_4\";b:1;s:7:\"level_5\";b:1;s:7:\"level_6\";b:1;s:7:\"level_7\";b:1;s:7:\"level_8\";b:1;s:7:\"level_9\";b:1;s:10:\"list_users\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:14:\"manage_options\";b:1;s:20:\"manage_product_terms\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:12:\"manage_tutor\";b:1;s:23:\"manage_tutor_instructor\";b:1;s:18:\"manage_woocommerce\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"promote_users\";b:1;s:13:\"publish_pages\";b:1;s:13:\"publish_posts\";b:1;s:16:\"publish_products\";b:1;s:20:\"publish_shop_coupons\";b:1;s:19:\"publish_shop_orders\";b:1;s:25:\"publish_tutor_assignments\";b:1;s:21:\"publish_tutor_courses\";b:1;s:21:\"publish_tutor_lessons\";b:1;s:23:\"publish_tutor_questions\";b:1;s:21:\"publish_tutor_quizzes\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:21:\"read_private_products\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:24:\"read_private_shop_orders\";b:1;s:30:\"read_private_tutor_assignments\";b:1;s:26:\"read_private_tutor_courses\";b:1;s:26:\"read_private_tutor_lessons\";b:1;s:28:\"read_private_tutor_questions\";b:1;s:26:\"read_private_tutor_quizzes\";b:1;s:12:\"read_product\";b:1;s:16:\"read_shop_coupon\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"read_tutor_course\";b:1;s:17:\"read_tutor_lesson\";b:1;s:19:\"read_tutor_question\";b:1;s:15:\"read_tutor_quiz\";b:1;s:12:\"remove_users\";b:1;s:13:\"switch_themes\";b:1;s:15:\"unfiltered_html\";b:1;s:17:\"unfiltered_upload\";b:1;s:12:\"upload_files\";b:1;s:23:\"ure_create_capabilities\";b:1;s:16:\"ure_create_roles\";b:1;s:23:\"ure_delete_capabilities\";b:1;s:16:\"ure_delete_roles\";b:1;s:14:\"ure_edit_roles\";b:1;s:18:\"ure_manage_options\";b:1;s:15:\"ure_reset_roles\";b:1;s:24:\"view_woocommerce_reports\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:16:\"tutor_instructor\";a:2:{s:4:\"name\";s:10:\"Instructor\";s:12:\"capabilities\";a:36:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:12:\"upload_files\";b:1;s:23:\"manage_tutor_instructor\";b:1;s:17:\"edit_tutor_course\";b:1;s:17:\"read_tutor_course\";b:1;s:19:\"delete_tutor_course\";b:1;s:20:\"delete_tutor_courses\";b:1;s:18:\"edit_tutor_courses\";b:1;s:25:\"edit_others_tutor_courses\";b:1;s:26:\"read_private_tutor_courses\";b:1;s:17:\"edit_tutor_lesson\";b:1;s:17:\"read_tutor_lesson\";b:1;s:19:\"delete_tutor_lesson\";b:1;s:20:\"delete_tutor_lessons\";b:1;s:18:\"edit_tutor_lessons\";b:1;s:25:\"edit_others_tutor_lessons\";b:1;s:26:\"read_private_tutor_lessons\";b:1;s:21:\"publish_tutor_lessons\";b:1;s:15:\"edit_tutor_quiz\";b:1;s:15:\"read_tutor_quiz\";b:1;s:17:\"delete_tutor_quiz\";b:1;s:20:\"delete_tutor_quizzes\";b:1;s:18:\"edit_tutor_quizzes\";b:1;s:25:\"edit_others_tutor_quizzes\";b:1;s:26:\"read_private_tutor_quizzes\";b:1;s:21:\"publish_tutor_quizzes\";b:1;s:19:\"edit_tutor_question\";b:1;s:19:\"read_tutor_question\";b:1;s:21:\"delete_tutor_question\";b:1;s:22:\"delete_tutor_questions\";b:1;s:20:\"edit_tutor_questions\";b:1;s:27:\"edit_others_tutor_questions\";b:1;s:23:\"publish_tutor_questions\";b:1;s:28:\"read_private_tutor_questions\";b:1;s:21:\"publish_tutor_courses\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:7:\"Learner\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:5:\"Staff\";s:12:\"capabilities\";a:86:{s:24:\"assign_shop_coupon_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_others_products\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:23:\"delete_private_products\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:14:\"delete_product\";b:1;s:20:\"delete_product_terms\";b:1;s:15:\"delete_products\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:25:\"delete_published_products\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:18:\"delete_shop_coupon\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:19:\"delete_shop_coupons\";b:1;s:17:\"delete_shop_order\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:18:\"delete_shop_orders\";b:1;s:24:\"delete_tutor_assignments\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_others_products\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:29:\"edit_others_tutor_assignments\";b:1;s:10:\"edit_pages\";b:1;s:10:\"edit_posts\";b:1;s:21:\"edit_private_products\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:12:\"edit_product\";b:1;s:18:\"edit_product_terms\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_published_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:23:\"edit_published_products\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:16:\"edit_shop_coupon\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:17:\"edit_shop_coupons\";b:1;s:15:\"edit_shop_order\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:16:\"edit_shop_orders\";b:1;s:18:\"edit_theme_options\";b:1;s:22:\"edit_tutor_assignments\";b:1;s:7:\"level_0\";b:1;s:7:\"level_1\";b:1;s:7:\"level_2\";b:1;s:7:\"level_3\";b:1;s:7:\"level_4\";b:1;s:7:\"level_5\";b:1;s:7:\"level_6\";b:1;s:7:\"level_7\";b:1;s:7:\"level_8\";b:1;s:7:\"level_9\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:20:\"manage_product_terms\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:18:\"manage_woocommerce\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"publish_pages\";b:1;s:13:\"publish_posts\";b:1;s:16:\"publish_products\";b:1;s:20:\"publish_shop_coupons\";b:1;s:19:\"publish_shop_orders\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:21:\"read_private_products\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:24:\"read_private_shop_orders\";b:1;s:12:\"read_product\";b:1;s:16:\"read_shop_coupon\";b:1;s:15:\"read_shop_order\";b:1;s:12:\"upload_files\";b:1;s:24:\"view_woocommerce_reports\";b:1;}}}', 'yes'),
(96, 'fresh_site', '0', 'yes'),
(97, 'WPLANG', '', 'yes'),
(98, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(104, 'cron', 'a:17:{i:1661314874;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1661315416;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1661316191;a:1:{s:46:\"facebook_for_woocommerce_hourly_heartbeat_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1661318445;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1661326352;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661326362;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661326991;a:1:{s:45:\"facebook_for_woocommerce_daily_heartbeat_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661337152;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661347952;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1661351416;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1661353049;a:1:{s:30:\"tutor_once_in_day_run_schedule\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1661385600;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661394615;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661394631;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1661394633;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1662033600;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}', 'yes'),
(105, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'recovery_keys', 'a:0:{}', 'yes'),
(143, 'can_compress_scripts', '1', 'no'),
(148, 'recently_activated', 'a:0:{}', 'yes'),
(149, 'tutor_license_info', 'a:2:{s:9:\"activated\";b:1;s:10:\"license_to\";s:26:\"traininghub-uat.vus.edu.vn\";}', 'yes'),
(150, 'tutor_pro_version', '2.0.3', 'yes'),
(151, 'tutor_option', 'a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:2:\"on\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:3:\"off\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:2:\"wc\";s:24:\"enable_guest_course_cart\";a:2:{i:0;s:2:\"on\";i:1;s:2:\"on\";}s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:2:\"on\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:2:\"-1\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:2:\"on\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:4:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";s:3:\"tag\";s:3:\"tag\";s:10:\"price_type\";s:10:\"price_type\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:3:\"off\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:2:\"on\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:2:\"on\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:1:\"6\";s:17:\"email_footer_text\";s:0:\"\";}', 'yes'),
(153, 'tutor_version', '2.0.0', 'yes'),
(154, 'tutor_first_activation_time', '1656644249', 'yes'),
(155, 'tutor_wizard', 'active', 'yes'),
(156, 'widget_tutor_course_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(158, 'tutor_default_option', 'a:13:{s:25:\"enable_course_marketplace\";s:3:\"off\";s:21:\"public_profile_layout\";s:12:\"pp-rectangle\";s:29:\"student_public_profile_layout\";s:12:\"pp-rectangle\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:26:\"display_course_instructors\";s:2:\"on\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:19:\"courses_col_per_row\";s:1:\"4\";s:16:\"courses_per_page\";s:1:\"8\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";}', 'yes'),
(160, 'tutor_welcome_page_visited', '1', 'yes'),
(161, 'tutor_settings_log', 'a:10:{s:22:\"tutor-saved-1658932618\";a:4:{s:8:\"datetime\";i:1658932618;s:12:\"history_date\";s:21:\"27 Jul, 2022, 2:36 pm\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:2:\"on\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:3:\"off\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:2:\"wc\";s:24:\"enable_guest_course_cart\";a:2:{i:0;s:2:\"on\";i:1;s:2:\"on\";}s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:2:\"on\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:2:\"-1\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:2:\"on\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:4:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";s:3:\"tag\";s:3:\"tag\";s:10:\"price_type\";s:10:\"price_type\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:3:\"off\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:2:\"on\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:2:\"on\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:1:\"6\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1657719874\";a:4:{s:8:\"datetime\";i:1657719874;s:12:\"history_date\";s:21:\"13 Jul, 2022, 1:44 pm\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:2:\"on\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:2:\"wc\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:2:\"on\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:2:\"-1\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:2:\"on\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:4:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";s:3:\"tag\";s:3:\"tag\";s:10:\"price_type\";s:10:\"price_type\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:3:\"off\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:2:\"on\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:2:\"on\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:1:\"6\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1657719840\";a:4:{s:8:\"datetime\";i:1657719840;s:12:\"history_date\";s:21:\"13 Jul, 2022, 1:44 pm\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:2:\"on\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:4:\"free\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:2:\"on\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:2:\"-1\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:2:\"on\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:4:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";s:3:\"tag\";s:3:\"tag\";s:10:\"price_type\";s:10:\"price_type\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:3:\"off\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:2:\"on\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:2:\"on\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:1:\"6\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1657719763\";a:4:{s:8:\"datetime\";i:1657719763;s:12:\"history_date\";s:21:\"13 Jul, 2022, 1:42 pm\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:3:\"off\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:4:\"free\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:2:\"on\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:2:\"-1\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:2:\"on\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:4:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";s:3:\"tag\";s:3:\"tag\";s:10:\"price_type\";s:10:\"price_type\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:3:\"off\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:2:\"on\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:2:\"on\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:1:\"6\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1657719727\";a:4:{s:8:\"datetime\";i:1657719727;s:12:\"history_date\";s:21:\"13 Jul, 2022, 1:42 pm\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:3:\"off\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:4:\"free\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:2:\"on\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:2:\"-1\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:2:\"on\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:4:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";s:3:\"tag\";s:3:\"tag\";s:10:\"price_type\";s:10:\"price_type\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:3:\"off\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:2:\"on\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:3:\"off\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:3:\"4.0\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1657719696\";a:4:{s:8:\"datetime\";i:1657719696;s:12:\"history_date\";s:21:\"13 Jul, 2022, 1:41 pm\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:3:\"off\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:4:\"free\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:2:\"on\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:2:\"-1\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:2:\"on\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:4:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";s:3:\"tag\";s:3:\"tag\";s:10:\"price_type\";s:10:\"price_type\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:3:\"off\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:3:\"off\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:3:\"off\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:3:\"4.0\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1657704033\";a:4:{s:8:\"datetime\";i:1657704033;s:12:\"history_date\";s:21:\"13 Jul, 2022, 9:20 am\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:3:\"off\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:4:\"free\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:3:\"off\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:5:\"fixed\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:2:\"on\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:4:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";s:3:\"tag\";s:3:\"tag\";s:10:\"price_type\";s:10:\"price_type\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:3:\"off\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:3:\"off\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:3:\"off\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:3:\"4.0\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1657703829\";a:4:{s:8:\"datetime\";i:1657703829;s:12:\"history_date\";s:21:\"13 Jul, 2022, 9:17 am\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:86:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:3:\"off\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:2:\"on\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:22:\"quiz_when_time_expires\";s:12:\"auto_abandon\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:3:\"off\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:4:\"free\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:3:\"off\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:5:\"fixed\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:3:\"off\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:2:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:2:\"on\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:3:\"off\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:28:\"gradebook_enable_grade_point\";s:3:\"off\";s:26:\"gradebook_show_grade_scale\";s:3:\"off\";s:25:\"gradebook_scale_separator\";s:1:\"/\";s:15:\"gradebook_scale\";s:3:\"4.0\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1656666882\";a:4:{s:8:\"datetime\";i:1656666882;s:12:\"history_date\";s:20:\"1 Jul, 2022, 9:14 am\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:81:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:3:\"off\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:3:\"off\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:2:\"on\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:4:\"free\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:3:\"off\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:5:\"fixed\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:3:\"off\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:2:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:2:\"on\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:2:\"on\";s:26:\"hide_course_from_shop_page\";s:3:\"off\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:2:\"on\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:2:\"on\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:17:\"email_footer_text\";s:0:\"\";}}s:22:\"tutor-saved-1656666779\";a:4:{s:8:\"datetime\";i:1656666779;s:12:\"history_date\";s:20:\"1 Jul, 2022, 9:12 am\";s:8:\"datatype\";s:5:\"saved\";s:7:\"dataset\";a:81:{s:23:\"tutor_dashboard_page_id\";s:1:\"6\";s:25:\"enable_course_marketplace\";s:3:\"off\";s:19:\"pagination_per_page\";s:2:\"20\";s:29:\"instructor_can_publish_course\";s:2:\"on\";s:28:\"enable_become_instructor_btn\";s:2:\"on\";s:28:\"course_content_access_for_ia\";s:3:\"off\";s:21:\"enable_spotlight_mode\";s:3:\"off\";s:25:\"course_completion_process\";s:8:\"flexible\";s:21:\"course_retake_feature\";s:3:\"off\";s:25:\"enrollment_expiry_enabled\";s:2:\"on\";s:28:\"enable_lesson_classic_editor\";s:3:\"off\";s:28:\"autoload_next_course_content\";s:2:\"on\";s:25:\"enable_comment_for_lesson\";s:3:\"off\";s:21:\"quiz_attempts_allowed\";s:3:\"100\";s:28:\"quiz_previous_button_enabled\";s:2:\"on\";s:17:\"quiz_grade_method\";s:13:\"highest_grade\";s:23:\"supported_video_sources\";a:2:{i:0;s:8:\"embedded\";i:1;s:9:\"shortcode\";}s:11:\"monetize_by\";s:4:\"free\";s:24:\"enable_guest_course_cart\";s:2:\"on\";s:29:\"earning_instructor_commission\";s:2:\"80\";s:24:\"earning_admin_commission\";s:2:\"20\";s:22:\"enable_revenue_sharing\";s:3:\"off\";s:23:\"statement_show_per_page\";s:2:\"20\";s:21:\"enable_fees_deducting\";s:3:\"off\";s:9:\"fees_name\";s:0:\"\";s:15:\"fee_amount_type\";a:2:{s:9:\"fees_type\";s:5:\"fixed\";s:11:\"fees_amount\";s:1:\"0\";}s:19:\"min_withdraw_amount\";s:2:\"80\";s:40:\"minimum_days_for_balance_to_be_available\";s:1:\"7\";s:24:\"tutor_withdrawal_methods\";a:3:{s:22:\"bank_transfer_withdraw\";s:22:\"bank_transfer_withdraw\";s:15:\"echeck_withdraw\";s:15:\"echeck_withdraw\";s:15:\"paypal_withdraw\";s:15:\"paypal_withdraw\";}s:40:\"tutor_bank_transfer_withdraw_instruction\";s:0:\"\";s:34:\"tutor_frontend_course_page_logo_id\";s:0:\"\";s:19:\"courses_col_per_row\";s:1:\"4\";s:21:\"course_archive_filter\";s:3:\"off\";s:16:\"courses_per_page\";s:1:\"8\";s:24:\"supported_course_filters\";a:2:{s:6:\"search\";s:6:\"search\";s:8:\"category\";s:8:\"category\";}s:22:\"instructor_list_layout\";s:12:\"pp-left-full\";s:21:\"public_profile_layout\";s:9:\"pp-circle\";s:29:\"student_public_profile_layout\";s:9:\"pp-circle\";s:26:\"display_course_instructors\";s:2:\"on\";s:24:\"enable_q_and_a_on_course\";s:2:\"on\";s:20:\"enable_course_author\";s:3:\"off\";s:19:\"enable_course_level\";s:2:\"on\";s:19:\"enable_course_share\";s:2:\"on\";s:22:\"enable_course_duration\";s:2:\"on\";s:28:\"enable_course_total_enrolled\";s:2:\"on\";s:25:\"enable_course_update_date\";s:2:\"on\";s:26:\"enable_course_progress_bar\";s:2:\"on\";s:22:\"enable_course_material\";s:2:\"on\";s:19:\"enable_course_about\";s:2:\"on\";s:25:\"enable_course_description\";s:2:\"on\";s:22:\"enable_course_benefits\";s:2:\"on\";s:26:\"enable_course_requirements\";s:2:\"on\";s:29:\"enable_course_target_audience\";s:2:\"on\";s:27:\"enable_course_announcements\";s:2:\"on\";s:20:\"enable_course_review\";s:2:\"on\";s:17:\"color_preset_type\";s:6:\"custom\";s:19:\"tutor_primary_color\";s:7:\"#3e64de\";s:25:\"tutor_primary_hover_color\";s:7:\"#28408e\";s:16:\"tutor_text_color\";s:7:\"#1a1b1e\";s:22:\"tutor_background_color\";s:7:\"#f6f8fd\";s:18:\"tutor_border_color\";s:7:\"#cdcfd5\";s:19:\"tutor_success_color\";s:7:\"#24a148\";s:19:\"tutor_warning_color\";s:7:\"#ed9700\";s:18:\"tutor_danger_color\";s:7:\"#d8d8d8\";s:19:\"tutor_disable_color\";s:7:\"#e3e6eb\";s:28:\"tutor_table_background_color\";s:7:\"#eff1f6\";s:30:\"disable_default_player_youtube\";s:3:\"off\";s:28:\"disable_default_player_vimeo\";s:3:\"off\";s:28:\"enable_gutenberg_course_edit\";s:3:\"off\";s:26:\"hide_course_from_shop_page\";s:3:\"off\";s:19:\"course_archive_page\";s:2:\"-1\";s:24:\"instructor_register_page\";s:1:\"8\";s:21:\"student_register_page\";s:1:\"7\";s:21:\"lesson_permalink_base\";s:6:\"lesson\";s:37:\"lesson_video_duration_youtube_api_key\";s:0:\"\";s:25:\"enable_profile_completion\";s:3:\"off\";s:25:\"enable_tutor_native_login\";s:2:\"on\";s:24:\"hide_admin_bar_for_users\";s:3:\"off\";s:19:\"delete_on_uninstall\";s:3:\"off\";s:29:\"enable_tutor_maintenance_mode\";s:3:\"off\";s:17:\"email_footer_text\";s:0:\"\";}}}', 'yes'),
(162, 'tutor_option_update_time', '27 Jul, 2022, 2:36 pm', 'yes'),
(164, 'tutor_addons_config', 'a:21:{s:39:\"lmspro/addons/buddypress/buddypress.php\";a:1:{s:9:\"is_enable\";i:0;}s:35:\"lmspro/addons/calendar/calendar.php\";a:1:{s:9:\"is_enable\";i:1;}s:43:\"lmspro/addons/content-drip/content-drip.php\";a:1:{s:9:\"is_enable\";i:0;}s:41:\"lmspro/addons/enrollments/enrollments.php\";a:1:{s:9:\"is_enable\";i:1;}s:51:\"lmspro/addons/google-classroom/google-classroom.php\";a:1:{s:9:\"is_enable\";i:0;}s:37:\"lmspro/addons/gradebook/gradebook.php\";a:1:{s:9:\"is_enable\";i:1;}s:29:\"lmspro/addons/pmpro/pmpro.php\";a:1:{s:9:\"is_enable\";i:0;}s:55:\"lmspro/addons/quiz-import-export/quiz-import-export.php\";a:1:{s:9:\"is_enable\";i:1;}s:59:\"lmspro/addons/restrict-content-pro/restrict-content-pro.php\";a:1:{s:9:\"is_enable\";i:0;}s:53:\"lmspro/addons/tutor-assignments/tutor-assignments.php\";a:1:{s:9:\"is_enable\";i:1;}s:53:\"lmspro/addons/tutor-certificate/tutor-certificate.php\";a:1:{s:9:\"is_enable\";i:0;}s:67:\"lmspro/addons/tutor-course-attachments/tutor-course-attachments.php\";a:1:{s:9:\"is_enable\";i:0;}s:59:\"lmspro/addons/tutor-course-preview/tutor-course-preview.php\";a:1:{s:9:\"is_enable\";i:0;}s:41:\"lmspro/addons/tutor-email/tutor-email.php\";a:1:{s:9:\"is_enable\";i:0;}s:65:\"lmspro/addons/tutor-multi-instructors/tutor-multi-instructors.php\";a:1:{s:9:\"is_enable\";i:0;}s:57:\"lmspro/addons/tutor-notifications/tutor-notifications.php\";a:1:{s:9:\"is_enable\";i:0;}s:57:\"lmspro/addons/tutor-prerequisites/tutor-prerequisites.php\";a:1:{s:9:\"is_enable\";i:0;}s:43:\"lmspro/addons/tutor-report/tutor-report.php\";a:1:{s:9:\"is_enable\";i:1;}s:39:\"lmspro/addons/tutor-wpml/tutor-wpml.php\";a:1:{s:9:\"is_enable\";i:0;}s:39:\"lmspro/addons/tutor-zoom/tutor-zoom.php\";a:1:{s:9:\"is_enable\";i:0;}s:51:\"lmspro/addons/wc-subscriptions/wc-subscriptions.php\";a:1:{s:9:\"is_enable\";i:0;}}', 'yes'),
(165, 'sp_woo_product_slider_review_notice_dismiss', 'a:2:{s:4:\"time\";i:1656951340;s:9:\"dismissed\";b:1;}', 'yes'),
(169, 'new_admin_email', 'heckmanle@gmail.com', 'yes'),
(173, 'themeum_update_error_lmspro/tutor-pro.php', 'Please submit a valid license key.', 'yes'),
(181, 'woocommerce_store_address', 'HCMC', 'yes'),
(182, 'woocommerce_store_address_2', '', 'yes'),
(183, 'woocommerce_store_city', 'HCMC', 'yes'),
(184, 'woocommerce_default_country', 'VN', 'yes'),
(185, 'woocommerce_store_postcode', '760000', 'yes'),
(186, 'woocommerce_allowed_countries', 'all', 'yes'),
(187, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(188, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(189, 'woocommerce_ship_to_countries', '', 'yes'),
(190, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(191, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(192, 'woocommerce_calc_taxes', 'no', 'yes'),
(193, 'woocommerce_enable_coupons', 'no', 'yes'),
(194, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(195, 'woocommerce_currency', 'VND', 'yes'),
(196, 'woocommerce_currency_pos', 'right_space', 'yes'),
(197, 'woocommerce_price_thousand_sep', ',', 'yes'),
(198, 'woocommerce_price_decimal_sep', '.', 'yes'),
(199, 'woocommerce_price_num_decimals', '0', 'yes'),
(200, 'woocommerce_shop_page_id', '125', 'yes'),
(201, 'woocommerce_cart_redirect_after_add', 'yes', 'yes'),
(202, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(203, 'woocommerce_placeholder_image', '11', 'yes'),
(204, 'woocommerce_weight_unit', 'kg', 'yes'),
(205, 'woocommerce_dimension_unit', 'cm', 'yes'),
(206, 'woocommerce_enable_reviews', 'yes', 'yes'),
(207, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(208, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(209, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(210, 'woocommerce_review_rating_required', 'yes', 'no'),
(211, 'woocommerce_manage_stock', 'yes', 'yes'),
(212, 'woocommerce_hold_stock_minutes', '60', 'no'),
(213, 'woocommerce_notify_low_stock', 'yes', 'no'),
(214, 'woocommerce_notify_no_stock', 'yes', 'no'),
(215, 'woocommerce_stock_email_recipient', 'heckmanle@gmail.com', 'no'),
(216, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(217, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(218, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(219, 'woocommerce_stock_format', '', 'yes'),
(220, 'woocommerce_file_download_method', 'force', 'no'),
(221, 'woocommerce_downloads_require_login', 'no', 'no'),
(222, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(223, 'woocommerce_prices_include_tax', 'no', 'yes'),
(224, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(225, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(226, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(227, 'woocommerce_tax_classes', '', 'yes'),
(228, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(229, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(230, 'woocommerce_price_display_suffix', '', 'yes'),
(231, 'woocommerce_tax_total_display', 'itemized', 'no'),
(232, 'woocommerce_enable_shipping_calc', 'no', 'no'),
(233, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(234, 'woocommerce_ship_to_destination', 'billing_only', 'no'),
(235, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(236, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(237, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(238, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(239, 'woocommerce_enable_myaccount_registration', 'yes', 'no'),
(240, 'woocommerce_registration_generate_username', 'yes', 'no'),
(241, 'woocommerce_registration_generate_password', 'yes', 'no'),
(242, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(243, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(244, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(245, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(246, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(247, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(248, 'woocommerce_trash_pending_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(249, 'woocommerce_trash_failed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(250, 'woocommerce_trash_cancelled_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(251, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(252, 'woocommerce_email_from_name', 'Training HUB', 'no'),
(253, 'woocommerce_email_from_address', 'heckmanle@gmail.com', 'no'),
(254, 'woocommerce_email_header_image', '', 'no'),
(255, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(256, 'woocommerce_email_base_color', '#96588a', 'no'),
(257, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(258, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(259, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(260, 'woocommerce_cart_page_id', '13', 'no'),
(261, 'woocommerce_checkout_page_id', '14', 'no'),
(262, 'woocommerce_myaccount_page_id', '15', 'no'),
(263, 'woocommerce_terms_page_id', '3', 'no'),
(264, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(265, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(266, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(267, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(268, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(269, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(270, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(271, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(272, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(273, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(274, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(275, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(276, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(277, 'woocommerce_api_enabled', 'no', 'yes'),
(278, 'woocommerce_allow_tracking', 'no', 'no'),
(279, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(280, 'woocommerce_single_image_width', '600', 'yes'),
(281, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(282, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(283, 'woocommerce_demo_store', 'no', 'no'),
(284, 'woocommerce_permalinks', 'a:5:{s:12:\"product_base\";s:8:\"/product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}', 'yes'),
(285, 'current_theme_supports_woocommerce', 'no', 'yes'),
(286, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(287, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'),
(289, 'default_product_cat', '15', 'yes'),
(292, 'woocommerce_version', '3.7.0', 'yes'),
(293, 'woocommerce_db_version', '3.7.0', 'yes'),
(294, 'woocommerce_admin_notices', 'a:0:{}', 'yes'),
(295, '_transient_woocommerce_webhook_ids_status_active', 'a:0:{}', 'yes'),
(296, 'widget_woocommerce_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(297, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(298, 'widget_woocommerce_layered_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(299, 'widget_woocommerce_price_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(300, 'widget_woocommerce_product_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(301, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(302, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(303, 'widget_woocommerce_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(304, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(305, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(306, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(307, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(312, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(318, 'woocommerce_product_type', 'both', 'yes'),
(319, 'woocommerce_sell_in_person', '1', 'yes'),
(321, 'woocommerce_cheque_settings', 'a:1:{s:7:\"enabled\";s:2:\"no\";}', 'yes'),
(322, 'woocommerce_bacs_settings', 'a:1:{s:7:\"enabled\";s:2:\"no\";}', 'yes'),
(323, 'woocommerce_cod_settings', 'a:6:{s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:16:\"Cash on delivery\";s:11:\"description\";s:28:\"Pay with cash upon delivery.\";s:12:\"instructions\";s:28:\"Pay with cash upon delivery.\";s:18:\"enable_for_methods\";a:0:{}s:18:\"enable_for_virtual\";s:3:\"yes\";}', 'yes'),
(328, 'woocommerce_admin_notice_woocommerce-admin_install_error', 'WooCommerce Admin was installed but could not be activated. <a href=\"https://traininghub-uat.vus.edu.vn/wp-admin/plugins.php\">Please activate it manually by clicking here.</a>', 'yes'),
(329, 'facebook_config', 'a:4:{s:8:\"pixel_id\";s:1:\"0\";s:7:\"use_pii\";b:1;s:7:\"use_s2s\";b:0;s:12:\"access_token\";s:0:\"\";}', 'yes'),
(330, 'wc_facebook_for_woocommerce_is_active', 'yes', 'yes'),
(331, 'wc_facebook_for_woocommerce_lifecycle_events', '[{\"name\":\"install\",\"time\":1656661391,\"version\":\"2.6.16\"}]', 'no'),
(332, 'wc_facebook_for_woocommerce_version', '2.6.16', 'yes'),
(343, '_transient_shipping-transient-version', '1658304458', 'yes'),
(350, '_transient_product_query-transient-version', '1659691385', 'yes'),
(366, 'cpto_options', 'a:7:{s:23:\"show_reorder_interfaces\";a:10:{s:4:\"post\";s:4:\"show\";s:10:\"attachment\";s:4:\"show\";s:8:\"wp_block\";s:4:\"show\";s:7:\"product\";s:4:\"show\";s:10:\"shop_order\";s:4:\"show\";s:11:\"shop_coupon\";s:4:\"show\";s:7:\"courses\";s:4:\"show\";s:6:\"lesson\";s:4:\"show\";s:18:\"tutor_zoom_meeting\";s:4:\"show\";s:17:\"sp_wps_shortcodes\";s:4:\"show\";}s:8:\"autosort\";i:1;s:9:\"adminsort\";i:1;s:18:\"use_query_ASC_DESC\";s:0:\"\";s:17:\"archive_drag_drop\";i:1;s:10:\"capability\";s:14:\"manage_options\";s:21:\"navigation_sort_apply\";i:1;}', 'yes'),
(367, 'CPT_configured', 'TRUE', 'yes'),
(369, 'recovery_mode_email_last_sent', '1657697906', 'yes'),
(397, 'theme_mods_twentytwenty', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1656951382;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}', 'yes'),
(425, 'sp-wqv-notice-dismissed', '1', 'yes'),
(591, 'woocommerce_marketplace_suggestions', 'a:2:{s:11:\"suggestions\";a:27:{i:0;a:4:{s:4:\"slug\";s:28:\"product-edit-meta-tab-header\";s:7:\"context\";s:28:\"product-edit-meta-tab-header\";s:5:\"title\";s:22:\"Recommended extensions\";s:13:\"allow-dismiss\";b:0;}i:1;a:6:{s:4:\"slug\";s:39:\"product-edit-meta-tab-footer-browse-all\";s:7:\"context\";s:28:\"product-edit-meta-tab-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:2;a:9:{s:4:\"slug\";s:46:\"product-edit-mailchimp-woocommerce-memberships\";s:7:\"product\";s:33:\"woocommerce-memberships-mailchimp\";s:14:\"show-if-active\";a:1:{i:0;s:23:\"woocommerce-memberships\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:116:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/mailchimp-for-memberships.svg\";s:5:\"title\";s:25:\"Mailchimp for Memberships\";s:4:\"copy\";s:79:\"Completely automate your email lists by syncing membership changes to Mailchimp\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:67:\"https://woocommerce.com/products/mailchimp-woocommerce-memberships/\";}i:3;a:9:{s:4:\"slug\";s:19:\"product-edit-addons\";s:7:\"product\";s:26:\"woocommerce-product-addons\";s:14:\"show-if-active\";a:2:{i:0;s:25:\"woocommerce-subscriptions\";i:1;s:20:\"woocommerce-bookings\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-add-ons.svg\";s:5:\"title\";s:15:\"Product Add-Ons\";s:4:\"copy\";s:93:\"Offer add-ons like gift wrapping, special messages or other special options for your products\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-add-ons/\";}i:4;a:9:{s:4:\"slug\";s:46:\"product-edit-woocommerce-subscriptions-gifting\";s:7:\"product\";s:33:\"woocommerce-subscriptions-gifting\";s:14:\"show-if-active\";a:1:{i:0;s:25:\"woocommerce-subscriptions\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:116:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/gifting-for-subscriptions.svg\";s:5:\"title\";s:25:\"Gifting for Subscriptions\";s:4:\"copy\";s:70:\"Let customers buy subscriptions for others - they\'re the ultimate gift\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:67:\"https://woocommerce.com/products/woocommerce-subscriptions-gifting/\";}i:5;a:9:{s:4:\"slug\";s:42:\"product-edit-teams-woocommerce-memberships\";s:7:\"product\";s:33:\"woocommerce-memberships-for-teams\";s:14:\"show-if-active\";a:1:{i:0;s:23:\"woocommerce-memberships\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:112:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/teams-for-memberships.svg\";s:5:\"title\";s:21:\"Teams for Memberships\";s:4:\"copy\";s:123:\"Adds B2B functionality to WooCommerce Memberships, allowing sites to sell team, group, corporate, or family member accounts\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:63:\"https://woocommerce.com/products/teams-woocommerce-memberships/\";}i:6;a:8:{s:4:\"slug\";s:29:\"product-edit-variation-images\";s:7:\"product\";s:39:\"woocommerce-additional-variation-images\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:118:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/additional-variation-images.svg\";s:5:\"title\";s:27:\"Additional Variation Images\";s:4:\"copy\";s:72:\"Showcase your products in the best light with a image for each variation\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:73:\"https://woocommerce.com/products/woocommerce-additional-variation-images/\";}i:7;a:9:{s:4:\"slug\";s:47:\"product-edit-woocommerce-subscription-downloads\";s:7:\"product\";s:34:\"woocommerce-subscription-downloads\";s:14:\"show-if-active\";a:1:{i:0;s:25:\"woocommerce-subscriptions\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:113:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscription-downloads.svg\";s:5:\"title\";s:22:\"Subscription Downloads\";s:4:\"copy\";s:57:\"Give customers special downloads with their subscriptions\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:68:\"https://woocommerce.com/products/woocommerce-subscription-downloads/\";}i:8;a:8:{s:4:\"slug\";s:31:\"product-edit-min-max-quantities\";s:7:\"product\";s:30:\"woocommerce-min-max-quantities\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:109:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/min-max-quantities.svg\";s:5:\"title\";s:18:\"Min/Max Quantities\";s:4:\"copy\";s:81:\"Specify minimum and maximum allowed product quantities for orders to be completed\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:52:\"https://woocommerce.com/products/min-max-quantities/\";}i:9;a:8:{s:4:\"slug\";s:28:\"product-edit-name-your-price\";s:7:\"product\";s:27:\"woocommerce-name-your-price\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/name-your-price.svg\";s:5:\"title\";s:15:\"Name Your Price\";s:4:\"copy\";s:70:\"Let customers pay what they want - useful for donations, tips and more\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/name-your-price/\";}i:10;a:8:{s:4:\"slug\";s:42:\"product-edit-woocommerce-one-page-checkout\";s:7:\"product\";s:29:\"woocommerce-one-page-checkout\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:108:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/one-page-checkout.svg\";s:5:\"title\";s:17:\"One Page Checkout\";s:4:\"copy\";s:92:\"Don\'t make customers click around - let them choose products, checkout & pay all on one page\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:63:\"https://woocommerce.com/products/woocommerce-one-page-checkout/\";}i:11;a:4:{s:4:\"slug\";s:19:\"orders-empty-header\";s:7:\"context\";s:24:\"orders-list-empty-header\";s:5:\"title\";s:20:\"Tools for your store\";s:13:\"allow-dismiss\";b:0;}i:12;a:6:{s:4:\"slug\";s:30:\"orders-empty-footer-browse-all\";s:7:\"context\";s:24:\"orders-list-empty-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:13;a:8:{s:4:\"slug\";s:19:\"orders-empty-wc-pay\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-payments\";s:4:\"icon\";s:111:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/woocommerce-payments.svg\";s:5:\"title\";s:20:\"WooCommerce Payments\";s:4:\"copy\";s:125:\"Securely accept payments and manage transactions directly from your WooCommerce dashboard – no setup costs or monthly fees.\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-payments/\";}i:14;a:8:{s:4:\"slug\";s:19:\"orders-empty-zapier\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:18:\"woocommerce-zapier\";s:4:\"icon\";s:97:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/zapier.svg\";s:5:\"title\";s:6:\"Zapier\";s:4:\"copy\";s:88:\"Save time and increase productivity by connecting your store to more than 1000+ services\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:52:\"https://woocommerce.com/products/woocommerce-zapier/\";}i:15;a:8:{s:4:\"slug\";s:30:\"orders-empty-shipment-tracking\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:29:\"woocommerce-shipment-tracking\";s:4:\"icon\";s:108:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipment-tracking.svg\";s:5:\"title\";s:17:\"Shipment Tracking\";s:4:\"copy\";s:86:\"Let customers know when their orders will arrive by adding shipment tracking to emails\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:51:\"https://woocommerce.com/products/shipment-tracking/\";}i:16;a:8:{s:4:\"slug\";s:32:\"orders-empty-table-rate-shipping\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:31:\"woocommerce-table-rate-shipping\";s:4:\"icon\";s:110:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/table-rate-shipping.svg\";s:5:\"title\";s:19:\"Table Rate Shipping\";s:4:\"copy\";s:122:\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:53:\"https://woocommerce.com/products/table-rate-shipping/\";}i:17;a:8:{s:4:\"slug\";s:40:\"orders-empty-shipping-carrier-extensions\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:4:\"icon\";s:118:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipping-carrier-extensions.svg\";s:5:\"title\";s:27:\"Shipping Carrier Extensions\";s:4:\"copy\";s:116:\"Show live rates from FedEx, UPS, USPS and more directly on your store - never under or overcharge for shipping again\";s:11:\"button-text\";s:13:\"Find Carriers\";s:8:\"promoted\";s:26:\"category-shipping-carriers\";s:3:\"url\";s:99:\"https://woocommerce.com/product-category/woocommerce-extensions/shipping-methods/shipping-carriers/\";}i:18;a:8:{s:4:\"slug\";s:32:\"orders-empty-google-product-feed\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:25:\"woocommerce-product-feeds\";s:4:\"icon\";s:110:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/google-product-feed.svg\";s:5:\"title\";s:19:\"Google Product Feed\";s:4:\"copy\";s:76:\"Increase sales by letting customers find you when they\'re shopping on Google\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:53:\"https://woocommerce.com/products/google-product-feed/\";}i:19;a:4:{s:4:\"slug\";s:35:\"products-empty-header-product-types\";s:7:\"context\";s:26:\"products-list-empty-header\";s:5:\"title\";s:23:\"Other types of products\";s:13:\"allow-dismiss\";b:0;}i:20;a:6:{s:4:\"slug\";s:32:\"products-empty-footer-browse-all\";s:7:\"context\";s:26:\"products-list-empty-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:21;a:8:{s:4:\"slug\";s:30:\"products-empty-product-vendors\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:27:\"woocommerce-product-vendors\";s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-vendors.svg\";s:5:\"title\";s:15:\"Product Vendors\";s:4:\"copy\";s:47:\"Turn your store into a multi-vendor marketplace\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-vendors/\";}i:22;a:8:{s:4:\"slug\";s:26:\"products-empty-memberships\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:23:\"woocommerce-memberships\";s:4:\"icon\";s:102:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/memberships.svg\";s:5:\"title\";s:11:\"Memberships\";s:4:\"copy\";s:76:\"Give members access to restricted content or products, for a fee or for free\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:57:\"https://woocommerce.com/products/woocommerce-memberships/\";}i:23;a:9:{s:4:\"slug\";s:35:\"products-empty-woocommerce-deposits\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-deposits\";s:14:\"show-if-active\";a:1:{i:0;s:20:\"woocommerce-bookings\";}s:4:\"icon\";s:99:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/deposits.svg\";s:5:\"title\";s:8:\"Deposits\";s:4:\"copy\";s:75:\"Make it easier for customers to pay by offering a deposit or a payment plan\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-deposits/\";}i:24;a:8:{s:4:\"slug\";s:40:\"products-empty-woocommerce-subscriptions\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:25:\"woocommerce-subscriptions\";s:4:\"icon\";s:104:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg\";s:5:\"title\";s:13:\"Subscriptions\";s:4:\"copy\";s:97:\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:59:\"https://woocommerce.com/products/woocommerce-subscriptions/\";}i:25;a:8:{s:4:\"slug\";s:35:\"products-empty-woocommerce-bookings\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-bookings\";s:4:\"icon\";s:99:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/bookings.svg\";s:5:\"title\";s:8:\"Bookings\";s:4:\"copy\";s:99:\"Allow customers to book appointments, make reservations or rent equipment without leaving your site\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-bookings/\";}i:26;a:8:{s:4:\"slug\";s:30:\"products-empty-product-bundles\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:27:\"woocommerce-product-bundles\";s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-bundles.svg\";s:5:\"title\";s:15:\"Product Bundles\";s:4:\"copy\";s:49:\"Offer customizable bundles and assembled products\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-bundles/\";}}s:7:\"updated\";i:1657696459;}', 'no'),
(762, 'current_theme', 'Drag &amp; drop layout', 'yes'),
(763, 'theme_mods_site_el', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:5:{s:15:\"header_top_menu\";i:16;s:7:\"primary\";i:0;s:14:\"primary_mobile\";i:0;s:19:\"primary_menu_footer\";i:0;s:6:\"social\";i:0;}s:18:\"custom_css_post_id\";i:151;}', 'yes'),
(764, 'theme_switched', '', 'yes'),
(765, 'woocommerce_maybe_regenerate_images_hash', '991b1ca641921cf0f5baf7a2fe85861b', 'yes'),
(1076, 'ws_menu_editor', 'a:28:{s:22:\"hide_advanced_settings\";b:1;s:16:\"show_extra_icons\";b:0;s:11:\"custom_menu\";a:7:{s:4:\"tree\";a:19:{s:9:\"index.php\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:10:\">index.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:3:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:19:\"index.php>index.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:4:\"Home\";s:12:\"access_level\";s:4:\"read\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:9:\"index.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"index.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:9:\"index.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:25:\"index.php>update-core.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:89:\"Updates <span class=\"update-plugins count-19\"><span class=\"update-count\">19</span></span>\";s:12:\"access_level\";s:11:\"update_core\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:15:\"update-core.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"index.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:15:\"update-core.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"index.php>tutor-setup\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:0:\"\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"tutor-setup\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"index.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:11:\"tutor-setup\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:9:\"Dashboard\";s:12:\"access_level\";s:4:\"read\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:9:\"index.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:43:\"menu-top menu-top-first menu-icon-dashboard\";s:8:\"hookname\";s:14:\"menu-dashboard\";s:8:\"icon_url\";s:19:\"dashicons-dashboard\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:9:\"index.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:5:\"tutor\";a:33:{s:10:\"page_title\";N;s:10:\"menu_title\";s:12:\"LMS Contents\";s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:6:\">tutor\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:15:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:11:\"tutor>tutor\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:7:\"Courses\";s:10:\"menu_title\";s:7:\"Courses\";s:12:\"access_level\";s:23:\"manage_tutor_instructor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:5:\"tutor\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:20:\"admin.php?page=tutor\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:62:\"tutor>edit-tags.php?taxonomy=course-category&post_type=courses\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:10:\"Categories\";s:10:\"menu_title\";s:10:\"Categories\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:56:\"edit-tags.php?taxonomy=course-category&post_type=courses\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:56:\"edit-tags.php?taxonomy=course-category&post_type=courses\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:57:\"tutor>edit-tags.php?taxonomy=course-tag&post_type=courses\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:4:\"Tags\";s:10:\"menu_title\";s:4:\"Tags\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:51:\"edit-tags.php?taxonomy=course-tag&post_type=courses\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:51:\"edit-tags.php?taxonomy=course-tag&post_type=courses\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:3;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:20:\"tutor>tutor-students\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:8:\"Students\";s:10:\"menu_title\";s:8:\"Students\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:14:\"tutor-students\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:29:\"admin.php?page=tutor-students\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:4;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:4;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:25:\"tutor>tutor_announcements\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:13:\"Announcements\";s:10:\"menu_title\";s:13:\"Announcements\";s:12:\"access_level\";s:23:\"manage_tutor_instructor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:19:\"tutor_announcements\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:34:\"admin.php?page=tutor_announcements\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:5;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:5;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"tutor>question_answer\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:5:\"Q & A\";s:10:\"menu_title\";s:6:\"Q & A \";s:12:\"access_level\";s:23:\"manage_tutor_instructor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:15:\"question_answer\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:30:\"admin.php?page=question_answer\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:6;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:6;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:25:\"tutor>tutor_quiz_attempts\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:13:\"Quiz Attempts\";s:10:\"menu_title\";s:13:\"Quiz Attempts\";s:12:\"access_level\";s:23:\"manage_tutor_instructor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:19:\"tutor_quiz_attempts\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:34:\"admin.php?page=tutor_quiz_attempts\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:7;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:7;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:18:\"tutor>tutor-addons\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:7:\"Add-ons\";s:10:\"menu_title\";s:7:\"Add-ons\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:12:\"tutor-addons\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:27:\"admin.php?page=tutor-addons\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:8;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:8;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:17:\"tutor>enrollments\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:9:\"Enrolment\";s:10:\"menu_title\";s:9:\"Enrolment\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"enrollments\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:26:\"admin.php?page=enrollments\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:9;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:9;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"tutor>tutor_gradebook\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:9:\"Gradebook\";s:10:\"menu_title\";s:9:\"Gradebook\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:15:\"tutor_gradebook\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:30:\"admin.php?page=tutor_gradebook\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:10;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:10;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:23:\"tutor>tutor-assignments\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:21:\"Submitted Assignments\";s:10:\"menu_title\";s:11:\"Assignments\";s:12:\"access_level\";s:23:\"manage_tutor_instructor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:17:\"tutor-assignments\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:32:\"admin.php?page=tutor-assignments\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:11;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:11;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:18:\"tutor>tutor_report\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:7:\"Reports\";s:10:\"menu_title\";s:7:\"Reports\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:12:\"tutor_report\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:27:\"admin.php?page=tutor_report\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:12;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:12;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:17:\"tutor>tutor-tools\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:5:\"Tools\";s:10:\"menu_title\";s:5:\"Tools\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"tutor-tools\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:26:\"admin.php?page=tutor-tools\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:13;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:13;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:20:\"tutor>tutor_settings\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:8:\"Settings\";s:10:\"menu_title\";s:8:\"Settings\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:14:\"tutor_settings\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:29:\"admin.php?page=tutor_settings\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:14;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:14;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:23:\"tutor>tutor-pro-license\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:7:\"License\";s:10:\"menu_title\";s:7:\"License\";s:12:\"access_level\";s:12:\"manage_tutor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:17:\"tutor-pro-license\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:5:\"tutor\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:32:\"admin.php?page=tutor-pro-license\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:7:\"LMS Pro\";s:10:\"menu_title\";s:7:\"LMS Pro\";s:12:\"access_level\";s:23:\"manage_tutor_instructor\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:5:\"tutor\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:28:\"menu-top toplevel_page_tutor\";s:8:\"hookname\";s:19:\"toplevel_page_tutor\";s:8:\"icon_url\";s:1826:\"data:image/svg+xml;base64,PHN2ZyBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAwIDExMzkiPjxkZWZzLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTM0MS42NTIgNjIyLjRjLTIzLjQxMiAwLTQzLjIyMi0xOS44LTQzLjIyMi00My4ydi05OWMwLTIzLjQgMTkuODEtNDMuMiA0My4yMjItNDMuMiAyMy40MTIgMCA0My4yMjIgMTkuOCA0My4yMjIgNDMuMnY5OWMwIDIzLjQtMTguMDA5IDQzLjItNDMuMjIyIDQzLjIgMS44MDEgMCAxLjgwMSAwIDAgMHpNNjU1LjAxIDYyMi40Yy0yMy40MTIgMC00My4yMjItMTgtNDMuMjIyLTQzLjJ2LTk5YzAtMjMuNCAxOS44MS00My4yIDQzLjIyMi00My4yIDIzLjQxMiAwIDQzLjIyMiAxOS44IDQzLjIyMiA0My4ydjk5YzAgMjUuMi0xOS44MSA0My4yLTQzLjIyMiA0My4yeiIgZmlsbD0iIzlEQTJBOCIvPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMjU1LjIwNCA0MDYuNGMxOC4wMDktMzcuOCA1NC4wMjgtNjMgOTUuNDQ5LTYzIDYxLjIzMSAxLjggMTA4LjA1NSA1Mi4yIDEwNi4yNTQgMTEzLjR2MjAzLjRjMy42MDIgMjEuNiAyMy40MTIgMzcuOCA0NS4wMjMgMzQuMiAxOC4wMDktMS44IDMyLjQxNi0xNi4yIDM0LjIxNy0zNC4yVjQ1NWMtMS44MDEtNjEuMiA0Ni44MjQtMTExLjYgMTA2LjI1NC0xMTMuNCAzOS42MjEgMCA3NS42MzkgMjEuNiA5My42NDggNTkuNCA2OC40MzUgMTMzLjIgMTQuNDA3IDI5NS4yLTExNy4wNiAzNjMuNkM0ODcuNTIzIDgzMyAzMjUuNDQgNzc5IDI1OC44MDYgNjQ3LjZjLTM5LjYyLTc1LjYtMzkuNjItMTY1LjYtMy42MDItMjQxLjJ6TTQyNi4yOTEgMTQwaDE1MS4yNzd2NTkuNGMtMjUuMjEyLTUuNC01Mi4yMjYtOS03Ny40MzktOS0yNS4yMTMgMC01MC40MjYgMy42LTc1LjYzOSA3LjJsMS44MDEtNTcuNnptNDE0LjIxMSAzODguOGMwLTEyMi40LTY2LjYzNC0yMzUuOC0xNzIuODg4LTI5NS4yVjE0MGg2NC44MzNjMjUuMjEzIDAgNDUuMDIzLTE5LjggNDUuMDIzLTQ1cy0yMS42MTEtNDUtNDUuMDIzLTQ1SDI3MS40MTNDMjQ2LjIgNTEuOCAyMjYuMzkgNzEuNiAyMjYuMzkgOTYuOGMwIDI1LjIgMTkuODEgNDUgNDUuMDIzIDQ1aDY2LjYzM3Y5MS44Yy0xNjMuODgzIDkwLTIzMC41MTcgMjk4LjgtMTM1LjA2OCA0NTkgMy42MDIgNS40LTMuNjAyLTUuNCAwIDBDMzM4LjA0NiA5MzAuMiA2ODcuNDI0IDk0OC4yIDgwMi42ODMgOTUwYzEwLjgwNSAwIDE5LjgxLTMuNiAyNy4wMTQtMTAuOCA3LjIwMy03LjIgMTAuODA1LTE4IDEwLjgwNS0yN1Y1MjguOHoiIGZpbGw9IiM5REEyQTgiLz48L3N2Zz4=\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:20:\"admin.php?page=tutor\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}s:29:\"required_capability_read_only\";N;}s:11:\"separator_8\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:1;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:12:\">separator_8\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:0:\"\";s:12:\"access_level\";s:4:\"read\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"separator_8\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:17:\"wp-menu-separator\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:1;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:0:\"\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:8:\"edit.php\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:9:\">edit.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:6:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:17:\"edit.php>edit.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:9:\"All Posts\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:8:\"edit.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:8:\"edit.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:8:\"edit.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"edit.php>post-new.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Add New\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:12:\"post-new.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:8:\"edit.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:12:\"post-new.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:40:\"edit.php>edit-Tags.php?taxonomy=category\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:10:\"Categories\";s:12:\"access_level\";s:17:\"manage_categories\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:31:\"edit-Tags.php?taxonomy=category\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:8:\"edit.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:31:\"edit-Tags.php?taxonomy=category\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:3;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:40:\"edit.php>edit-Tags.php?taxonomy=post_tag\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:4:\"Tags\";s:12:\"access_level\";s:16:\"manage_post_Tags\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:31:\"edit-Tags.php?taxonomy=post_tag\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:8:\"edit.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:31:\"edit-Tags.php?taxonomy=post_tag\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:4;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:4;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:30:\"edit.php>order-post-types-post\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:8:\"Re-Order\";s:10:\"menu_title\";s:8:\"Re-Order\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:21:\"order-post-types-post\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:8:\"edit.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:35:\"edit.php?page=order-post-types-post\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:5;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:5;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:26:\"edit.php>to-interface-post\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:14:\"Taxonomy Order\";s:10:\"menu_title\";s:14:\"Taxonomy Order\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:17:\"to-interface-post\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:8:\"edit.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:31:\"edit.php?page=to-interface-post\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:5:\"Posts\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:8:\"edit.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:37:\"menu-top menu-icon-post open-if-no-js\";s:8:\"hookname\";s:10:\"menu-posts\";s:8:\"icon_url\";s:20:\"dashicons-admin-post\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:8:\"edit.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:10:\"upload.php\";a:33:{s:10:\"page_title\";N;s:10:\"menu_title\";s:11:\"Media Files\";s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:4;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:11:\">upload.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:3:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"upload.php>upload.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Library\";s:12:\"access_level\";s:12:\"upload_files\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:10:\"upload.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:10:\"upload.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:10:\"upload.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:24:\"upload.php>media-new.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Add New\";s:12:\"access_level\";s:12:\"upload_files\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:13:\"media-new.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:10:\"upload.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:13:\"media-new.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:38:\"upload.php>order-post-types-attachment\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:8:\"Re-Order\";s:10:\"menu_title\";s:8:\"Re-Order\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:27:\"order-post-types-attachment\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:10:\"upload.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:43:\"upload.php?page=order-post-types-attachment\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:5:\"Media\";s:12:\"access_level\";s:12:\"upload_files\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:10:\"upload.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:24:\"menu-top menu-icon-media\";s:8:\"hookname\";s:10:\"menu-media\";s:8:\"icon_url\";s:21:\"dashicons-admin-media\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:10:\"upload.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}s:29:\"required_capability_read_only\";s:12:\"upload_files\";}s:36:\"edit-Tags.php?taxonomy=link_category\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:5;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:37:\">edit-Tags.php?taxonomy=link_category\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:1:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:73:\"edit-Tags.php?taxonomy=link_category>edit-Tags.php?taxonomy=link_category\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:15:\"Link Categories\";s:12:\"access_level\";s:17:\"manage_categories\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:36:\"edit-Tags.php?taxonomy=link_category\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:36:\"edit-Tags.php?taxonomy=link_category\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:36:\"edit-Tags.php?taxonomy=link_category\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:5:\"Links\";s:12:\"access_level\";s:12:\"manage_links\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:36:\"edit-Tags.php?taxonomy=link_category\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:24:\"menu-top menu-icon-links\";s:8:\"hookname\";s:10:\"menu-links\";s:8:\"icon_url\";s:21:\"dashicons-admin-links\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:36:\"edit-Tags.php?taxonomy=link_category\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:23:\"edit.php?post_type=page\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:6;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:24:\">edit.php?post_type=page\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:2:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:47:\"edit.php?post_type=page>edit.php?post_type=page\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:9:\"All Pages\";s:12:\"access_level\";s:10:\"edit_pages\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:23:\"edit.php?post_type=page\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:23:\"edit.php?post_type=page\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:23:\"edit.php?post_type=page\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:51:\"edit.php?post_type=page>post-new.php?post_type=page\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Add New\";s:12:\"access_level\";s:10:\"edit_pages\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:27:\"post-new.php?post_type=page\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:23:\"edit.php?post_type=page\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:27:\"post-new.php?post_type=page\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:5:\"Pages\";s:12:\"access_level\";s:10:\"edit_pages\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:23:\"edit.php?post_type=page\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:23:\"menu-top menu-icon-page\";s:8:\"hookname\";s:10:\"menu-pages\";s:8:\"icon_url\";s:20:\"dashicons-admin-page\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:23:\"edit.php?post_type=page\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:17:\"edit-comments.php\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:7;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:18:\">edit-comments.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:1:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:35:\"edit-comments.php>edit-comments.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:12:\"All Comments\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:17:\"edit-comments.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:17:\"edit-comments.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:17:\"edit-comments.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:198:\"Comments <span class=\"awaiting-mod count-0\"><span class=\"pending-count\" aria-hidden=\"true\">0</span><span class=\"comments-in-moderation-text screen-reader-text\">0 Comments in moderation</span></span>\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:17:\"edit-comments.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:27:\"menu-top menu-icon-comments\";s:8:\"hookname\";s:13:\"menu-comments\";s:8:\"icon_url\";s:24:\"dashicons-admin-comments\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:17:\"edit-comments.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:26:\"edit.php?post_type=product\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:8;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:27:\">edit.php?post_type=product\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:10:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:53:\"edit.php?post_type=product>edit.php?post_type=product\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:12:\"All Products\";s:12:\"access_level\";s:13:\"edit_products\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:26:\"edit.php?post_type=product\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:26:\"edit.php?post_type=product\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:57:\"edit.php?post_type=product>post-new.php?post_type=product\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Add New\";s:12:\"access_level\";s:13:\"edit_products\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:30:\"post-new.php?post_type=product\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:30:\"post-new.php?post_type=product\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:83:\"edit.php?post_type=product>edit-Tags.php?taxonomy=product_cat&amp;post_type=product\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:10:\"Categories\";s:12:\"access_level\";s:20:\"manage_product_terms\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:56:\"edit-Tags.php?taxonomy=product_cat&amp;post_type=product\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:52:\"edit-Tags.php?taxonomy=product_cat&post_type=product\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:3;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:83:\"edit.php?post_type=product>edit-Tags.php?taxonomy=product_tag&amp;post_type=product\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:4:\"Tags\";s:12:\"access_level\";s:20:\"manage_product_terms\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:56:\"edit-Tags.php?taxonomy=product_tag&amp;post_type=product\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:52:\"edit-Tags.php?taxonomy=product_tag&post_type=product\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:4;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:4;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:86:\"edit.php?post_type=product>edit-Tags.php?taxonomy=fb_product_set&amp;post_type=product\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:15:\"FB Product Sets\";s:12:\"access_level\";s:17:\"manage_categories\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:59:\"edit-Tags.php?taxonomy=fb_product_set&amp;post_type=product\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:55:\"edit-Tags.php?taxonomy=fb_product_set&post_type=product\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:5;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:5;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:45:\"edit.php?post_type=product>product_attributes\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:10:\"Attributes\";s:10:\"menu_title\";s:10:\"Attributes\";s:12:\"access_level\";s:20:\"manage_product_terms\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:18:\"product_attributes\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:50:\"edit.php?post_type=product&page=product_attributes\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:6;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:6;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:43:\"edit.php?post_type=product>product_importer\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:14:\"Product Import\";s:10:\"menu_title\";s:14:\"Product Import\";s:12:\"access_level\";s:6:\"import\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:16:\"product_importer\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:48:\"edit.php?post_type=product&page=product_importer\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:7;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:7;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:43:\"edit.php?post_type=product>product_exporter\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:14:\"Product Export\";s:10:\"menu_title\";s:14:\"Product Export\";s:12:\"access_level\";s:6:\"export\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:16:\"product_exporter\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:48:\"edit.php?post_type=product&page=product_exporter\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:8;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:8;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:51:\"edit.php?post_type=product>order-post-types-product\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:8:\"Re-Order\";s:10:\"menu_title\";s:8:\"Re-Order\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:24:\"order-post-types-product\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:56:\"edit.php?post_type=product&page=order-post-types-product\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:9;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:9;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:47:\"edit.php?post_type=product>to-interface-product\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:14:\"Taxonomy Order\";s:10:\"menu_title\";s:14:\"Taxonomy Order\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:20:\"to-interface-product\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:26:\"edit.php?post_type=product\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:52:\"edit.php?post_type=product&page=to-interface-product\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:8:\"Products\";s:12:\"access_level\";s:13:\"edit_products\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:26:\"edit.php?post_type=product\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:26:\"menu-top menu-icon-product\";s:8:\"hookname\";s:18:\"menu-posts-product\";s:8:\"icon_url\";s:20:\"dashicons-admin-post\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:26:\"edit.php?post_type=product\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:11:\"woocommerce\";a:33:{s:10:\"page_title\";N;s:10:\"menu_title\";s:6:\"Orders\";s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:9;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:12:\">woocommerce\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:7:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:41:\"woocommerce>edit.php?post_type=shop_order\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:6:\"Orders\";s:10:\"menu_title\";s:6:\"Orders\";s:12:\"access_level\";s:16:\"edit_shop_orders\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:29:\"edit.php?post_type=shop_order\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"woocommerce\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:29:\"edit.php?post_type=shop_order\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:42:\"woocommerce>edit.php?post_type=shop_coupon\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:7:\"Coupons\";s:10:\"menu_title\";s:7:\"Coupons\";s:12:\"access_level\";s:17:\"edit_shop_coupons\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:30:\"edit.php?post_type=shop_coupon\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"woocommerce\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:30:\"edit.php?post_type=shop_coupon\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:23:\"woocommerce>wc-facebook\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:24:\"Facebook for WooCommerce\";s:10:\"menu_title\";s:8:\"Facebook\";s:12:\"access_level\";s:18:\"manage_woocommerce\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"wc-facebook\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"woocommerce\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:26:\"admin.php?page=wc-facebook\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:3;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:22:\"woocommerce>wc-reports\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:7:\"Reports\";s:10:\"menu_title\";s:7:\"Reports\";s:12:\"access_level\";s:24:\"view_woocommerce_reports\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:10:\"wc-reports\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"woocommerce\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:25:\"admin.php?page=wc-reports\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:4;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:4;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:23:\"woocommerce>wc-settings\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:20:\"WooCommerce settings\";s:10:\"menu_title\";s:8:\"Settings\";s:12:\"access_level\";s:18:\"manage_woocommerce\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"wc-settings\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"woocommerce\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:26:\"admin.php?page=wc-settings\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:5;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:5;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"woocommerce>wc-status\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:18:\"WooCommerce status\";s:10:\"menu_title\";s:6:\"Status\";s:12:\"access_level\";s:18:\"manage_woocommerce\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:9:\"wc-status\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"woocommerce\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:24:\"admin.php?page=wc-status\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:6;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:6;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"woocommerce>wc-addons\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:22:\"WooCommerce extensions\";s:10:\"menu_title\";s:11:\"Extensions \";s:12:\"access_level\";s:18:\"manage_woocommerce\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:9:\"wc-addons\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"woocommerce\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:24:\"admin.php?page=wc-addons\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:11:\"WooCommerce\";s:10:\"menu_title\";s:11:\"WooCommerce\";s:12:\"access_level\";s:18:\"manage_woocommerce\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"woocommerce\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:52:\"menu-top menu-icon-generic toplevel_page_woocommerce\";s:8:\"hookname\";s:25:\"toplevel_page_woocommerce\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:11:\"woocommerce\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}s:29:\"required_capability_read_only\";N;}s:36:\"edit.php?post_type=sp_wps_shortcodes\";a:33:{s:10:\"page_title\";N;s:10:\"menu_title\";s:7:\"Sliders\";s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:10;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:37:\">edit.php?post_type=sp_wps_shortcodes\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:4:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:73:\"edit.php?post_type=sp_wps_shortcodes>edit.php?post_type=sp_wps_shortcodes\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:11:\"All Sliders\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:36:\"edit.php?post_type=sp_wps_shortcodes\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:36:\"edit.php?post_type=sp_wps_shortcodes\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:36:\"edit.php?post_type=sp_wps_shortcodes\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:77:\"edit.php?post_type=sp_wps_shortcodes>post-new.php?post_type=sp_wps_shortcodes\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Add New\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:40:\"post-new.php?post_type=sp_wps_shortcodes\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:36:\"edit.php?post_type=sp_wps_shortcodes\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:40:\"post-new.php?post_type=sp_wps_shortcodes\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:45:\"edit.php?post_type=sp_wps_shortcodes>wps_help\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:35:\"Product Slider for WooCommerce Help\";s:10:\"menu_title\";s:4:\"Help\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:8:\"wps_help\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:36:\"edit.php?post_type=sp_wps_shortcodes\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:50:\"edit.php?post_type=sp_wps_shortcodes&page=wps_help\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:3;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:71:\"edit.php?post_type=sp_wps_shortcodes>order-post-types-sp_wps_shortcodes\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:8:\"Re-Order\";s:10:\"menu_title\";s:8:\"Re-Order\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:34:\"order-post-types-sp_wps_shortcodes\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:36:\"edit.php?post_type=sp_wps_shortcodes\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:76:\"edit.php?post_type=sp_wps_shortcodes&page=order-post-types-sp_wps_shortcodes\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:14:\"Product Slider\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:36:\"edit.php?post_type=sp_wps_shortcodes\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:36:\"menu-top menu-icon-sp_wps_shortcodes\";s:8:\"hookname\";s:28:\"menu-posts-sp_wps_shortcodes\";s:8:\"icon_url\";s:2982:\"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxNy4wLjAsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+DQo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkNhcGFfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiDQoJIHdpZHRoPSI2MTJweCIgaGVpZ2h0PSI3OTJweCIgdmlld0JveD0iMCAwIDYxMiA3OTIiIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDYxMiA3OTIiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGc+DQoJCTxwYXRoIGZpbGw9IiM5RkE0QTkiIGQ9Ik01NzcuODAxLDMwMi40MDhsLTQyMy44OTktMzkuNTMxYy0yLjMyNS0wLjI3NC00LjUxNC0wLjI3NC02LjcwMi0wLjEzN2wtMTYuOTYxLTgyLjA3MQ0KCQkJYy0wLjQxLTEuNjQxLTAuODIxLTMuMjgzLTEuNTA1LTQuNjUxYy0yLjU5OS02LjU2Ni04LjA3LTExLjktMTUuMzItMTQuMDg5bC04MC44NC0yMy44MDENCgkJCWMtMTIuNDQ4LTMuNjkzLTI1LjU3OSwzLjQyLTI5LjI3MiwxNi4wMDRjLTMuNjkzLDEyLjQ0OCwzLjQyLDI1LjU3OSwxNi4wMDQsMjkuMjcybDY3LjQzNSwxOS44MzRsODEuMTE0LDM5MC45MzQNCgkJCWMxLjUwNSwxMS40OSwxMS4zNTMsMjAuMzgxLDIzLjM5LDIwLjM4MWwzNDguODA0LTAuMTM3YzEyLjk5NSwwLDIzLjUyNy0xMC41MzMsMjMuNTI3LTIzLjUyN3MtMTAuNTMyLTIzLjUyNy0yMy41MjctMjMuNTI3DQoJCQlsLTMyOS41MTcsMC4xMzdsLTExLjIxNi01NC4wM2gzNDYuODg5YzE4LjE5MiwwLDMzLjkyMy0xMi4wMzcsMzcuMjA2LTI4LjU4OGwyOC4wNDEtMTQxLjMNCgkJCUM2MTUuMTQzLDMyMy4zMzYsNTk5LjgyMywzMDQuNDYsNTc3LjgwMSwzMDIuNDA4eiIvPg0KCQk8Y2lyY2xlIGZpbGw9IiM5RkE0QTkiIGN4PSIyNTguMjY5IiBjeT0iNjgyLjk0NiIgcj0iNDcuMDU0Ii8+DQoJCTxjaXJjbGUgZmlsbD0iIzlGQTRBOSIgY3g9IjQ4My4xNDUiIGN5PSI2ODIuOTQ2IiByPSI0Ny4wNTQiLz4NCgkJPHBhdGggZmlsbD0iIzlGQTRBOSIgZD0iTTIxNy45MTgsMjQ0LjY4NGw1LjMzNSwwLjU0N2wxNi42ODgsMS41MDVsNjguNjY2LDYuNDI5bDIuNDYyLTI2LjQNCgkJCWMzLjQyLTM1LjcwMSwzNS4wMTctNjEuODI3LDcwLjcxOC01OC41NDRjMzUuNzAxLDMuNDIsNjEuODI3LDM1LjAxNyw1OC41NDQsNzAuNzE4bC0yLjQ2MiwyNi40bDY4LjY2Niw2LjQyOWwyMS44ODYsMi4wNTINCgkJCWM4LjA3LDAuODIxLDE1LjMyLTUuMTk4LDE2LjAwNC0xMy4yNjhsMi4xODktMjMuNTI3YzAuODIxLTguMDctNS4xOTgtMTUuMzItMTMuMjY4LTE2LjAwNGwtMjEuODg2LTIuMDUyDQoJCQljLTEuNzc4LTE4LjE5My03LjI1LTM1LjQyOC0xNS43My01MC44ODRsMTYuOTYxLTE0LjA4OWM2LjI5Mi01LjE5OCw3LjExMy0xNC40OTksMS45MTUtMjAuNzkxbC0xNS4wNDYtMTguMTkzDQoJCQljLTUuMTk4LTYuMjkyLTE0LjQ5OS03LjExMy0yMC43OTEtMS45MTVsLTE3LjA5OCwxMy45NTJjLTEzLjY3OS0xMS4wOC0yOS41NDYtMTkuNjk3LTQ3LjA1NC0yNC44OTVsMi4wNTItMjEuODg2DQoJCQljMC44MjEtOC4wNy01LjE5OC0xNS4zMi0xMy4yNjgtMTYuMDA0bC0yMy41MjctMi4xODljLTguMDctMC44MjEtMTUuMzIsNS4xOTgtMTYuMDA0LDEzLjI2OGwtMi4wNTIsMjEuODg2DQoJCQljLTE4LjE5MiwxLjc3OC0zNS40MjcsNy4yNS01MC44ODQsMTUuNzNsLTE0LjA4OS0xNi45NjFjLTUuMTk4LTYuMjkyLTE0LjQ5OS03LjExMy0yMC43OTEtMS45MTVsLTE4LjE5MywxNS4wNDYNCgkJCWMtNi4yOTIsNS4xOTgtNy4xMTMsMTQuNDk5LTEuOTE1LDIwLjc5MWwxNC4wODksMTYuOTYxYy0xMS4wOCwxMy42NzktMTkuNjk3LDI5LjU0Ni0yNC44OTUsNDcuMDU0bC0yMS44ODYtMi4wNTINCgkJCWMtOC4wNy0wLjgyMS0xNS4zMiw1LjE5OC0xNi4wMDQsMTMuMjY4bC0yLjE4OSwyMy41MjdDMjAzLjgyOSwyMzYuNzUxLDIwOS44NDcsMjQzLjg2MywyMTcuOTE4LDI0NC42ODR6Ii8+DQoJPC9nPg0KPC9nPg0KPC9zdmc+DQo=\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:36:\"edit.php?post_type=sp_wps_shortcodes\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}s:29:\"required_capability_read_only\";N;}s:11:\"separator_9\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:11;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:1;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:12:\">separator_9\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:0:\"\";s:12:\"access_level\";s:4:\"read\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"separator_9\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:17:\"wp-menu-separator\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:1;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:0:\"\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:10:\"themes.php\";a:33:{s:10:\"page_title\";N;s:10:\"menu_title\";s:5:\"Skins\";s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:12;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:11:\">themes.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:4:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"themes.php>themes.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:6:\"Themes\";s:12:\"access_level\";s:13:\"switch_themes\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:10:\"themes.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:10:\"themes.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:10:\"themes.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:24:\"themes.php>customize.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:9:\"Customize\";s:12:\"access_level\";s:9:\"customize\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:149:\"customize.php?return=%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor%26sub_section%3Deditor%26selected_menu_url%3Dthemes.php%26expand_menu%3D1\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:10:\"themes.php\";s:9:\"css_class\";s:20:\"hide-if-no-customize\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:149:\"customize.php?return=%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor%26sub_section%3Deditor%26selected_menu_url%3Dthemes.php%26expand_menu%3D1\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:24:\"themes.php>nav-menus.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:5:\"Menus\";s:12:\"access_level\";s:18:\"edit_theme_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:13:\"nav-menus.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:10:\"themes.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:13:\"nav-menus.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:3;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:27:\"themes.php>theme-editor.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:12:\"Theme Editor\";s:10:\"menu_title\";s:12:\"Theme Editor\";s:12:\"access_level\";s:11:\"edit_themes\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:16:\"theme-editor.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:10:\"themes.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:16:\"theme-editor.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:10:\"Appearance\";s:12:\"access_level\";s:13:\"switch_themes\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:10:\"themes.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:29:\"menu-top menu-icon-appearance\";s:8:\"hookname\";s:15:\"menu-appearance\";s:8:\"icon_url\";s:26:\"dashicons-admin-appearance\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:10:\"themes.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}s:29:\"required_capability_read_only\";N;}s:11:\"plugins.php\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:13;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:12:\">plugins.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:3:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:23:\"plugins.php>plugins.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:17:\"Installed Plugins\";s:12:\"access_level\";s:16:\"activate_plugins\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"plugins.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"plugins.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:11:\"plugins.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:30:\"plugins.php>plugin-install.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Add New\";s:12:\"access_level\";s:15:\"install_plugins\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:18:\"plugin-install.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"plugins.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:18:\"plugin-install.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:29:\"plugins.php>plugin-editor.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:13:\"Plugin Editor\";s:12:\"access_level\";s:12:\"edit_plugins\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:17:\"plugin-editor.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:11:\"plugins.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:17:\"plugin-editor.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:89:\"Plugins <span class=\"update-plugins count-17\"><span class=\"plugin-count\">17</span></span>\";s:12:\"access_level\";s:16:\"activate_plugins\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"plugins.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:26:\"menu-top menu-icon-plugins\";s:8:\"hookname\";s:12:\"menu-plugins\";s:8:\"icon_url\";s:23:\"dashicons-admin-plugins\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:11:\"plugins.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:9:\"users.php\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:14;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:10:\">users.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:3:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:19:\"users.php>users.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:9:\"All Users\";s:12:\"access_level\";s:10:\"list_users\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:9:\"users.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"users.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:9:\"users.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:22:\"users.php>user-new.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Add New\";s:12:\"access_level\";s:12:\"create_users\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:12:\"user-new.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"users.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:12:\"user-new.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:21:\"users.php>profile.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:12:\"Your Profile\";s:12:\"access_level\";s:4:\"read\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"profile.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"users.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:11:\"profile.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:5:\"Users\";s:12:\"access_level\";s:10:\"list_users\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:9:\"users.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:24:\"menu-top menu-icon-users\";s:8:\"hookname\";s:10:\"menu-users\";s:8:\"icon_url\";s:21:\"dashicons-admin-users\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:9:\"users.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:9:\"tools.php\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:15;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:10:\">tools.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:7:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:19:\"tools.php>tools.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:15:\"Available Tools\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:9:\"tools.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"tools.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:9:\"tools.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:20:\"tools.php>import.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:6:\"Import\";s:12:\"access_level\";s:6:\"import\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:10:\"import.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"tools.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:10:\"import.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:20:\"tools.php>export.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:6:\"Export\";s:12:\"access_level\";s:6:\"export\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:10:\"export.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"tools.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:10:\"export.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:3;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:25:\"tools.php>site-health.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:11:\"Site Health\";s:12:\"access_level\";s:23:\"view_site_health_checks\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:15:\"site-health.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"tools.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:15:\"site-health.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:4;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:4;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:34:\"tools.php>export-personal-data.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:20:\"Export Personal Data\";s:12:\"access_level\";s:27:\"export_others_personal_data\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:24:\"export-personal-data.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"tools.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:24:\"export-personal-data.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:5;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:5;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:33:\"tools.php>erase-personal-data.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:19:\"Erase Personal Data\";s:12:\"access_level\";s:26:\"erase_others_personal_data\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:23:\"erase-personal-data.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"tools.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:23:\"erase-personal-data.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:6;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:6;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:26:\"tools.php>action-scheduler\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:17:\"Scheduled Actions\";s:10:\"menu_title\";s:17:\"Scheduled Actions\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:16:\"action-scheduler\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:9:\"tools.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:31:\"tools.php?page=action-scheduler\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:5:\"Tools\";s:12:\"access_level\";s:10:\"edit_posts\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:9:\"tools.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:24:\"menu-top menu-icon-tools\";s:8:\"hookname\";s:10:\"menu-tools\";s:8:\"icon_url\";s:21:\"dashicons-admin-tools\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:9:\"tools.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:19:\"options-general.php\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:16;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:20:\">options-general.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:10:{i:0;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:0;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:39:\"options-general.php>options-general.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"General\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:19:\"options-general.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:19:\"options-general.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:1;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:1;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:39:\"options-general.php>options-writing.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Writing\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:19:\"options-writing.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:19:\"options-writing.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:2;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:2;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:39:\"options-general.php>options-reading.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Reading\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:19:\"options-reading.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:19:\"options-reading.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:3;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:3;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:42:\"options-general.php>options-discussion.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:10:\"Discussion\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:22:\"options-discussion.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:22:\"options-discussion.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:4;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:4;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:37:\"options-general.php>options-media.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:5:\"Media\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:17:\"options-media.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:17:\"options-media.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:5;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:5;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:41:\"options-general.php>options-permalink.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:10:\"Permalinks\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:21:\"options-permalink.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:21:\"options-permalink.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:6;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:6;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:39:\"options-general.php>options-privacy.php\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:7:\"Privacy\";s:12:\"access_level\";s:22:\"manage_privacy_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:19:\"options-privacy.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:19:\"options-privacy.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:7;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:7;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:32:\"options-general.php>cpto-options\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:16:\"Post Types Order\";s:10:\"menu_title\";s:145:\"<img class=\"menu_pto\" src=\"https://traininghub-uat.vus.edu.vn/wp-content/plugins/post-types-order/images/menu-icon.png\" alt=\"\" />Post Types Order\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:12:\"cpto-options\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:37:\"options-general.php?page=cpto-options\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:8;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:8;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:30:\"options-general.php>to-options\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:20:\"Taxonomy Terms Order\";s:10:\"menu_title\";s:153:\"<img class=\"menu_tto\" src=\"https://traininghub-uat.vus.edu.vn/wp-content/plugins/taxonomy-terms-order/images/menu-icon.png\" alt=\"\" />Taxonomy Terms Order\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:10:\"to-options\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:35:\"options-general.php?page=to-options\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}i:9;a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:9;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:0;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:31:\"options-general.php>menu_editor\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:11:\"Menu Editor\";s:10:\"menu_title\";s:11:\"Menu Editor\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:11:\"menu_editor\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";s:19:\"options-general.php\";s:9:\"css_class\";s:0:\"\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:1;s:6:\"custom\";b:0;s:3:\"url\";s:36:\"options-general.php?page=menu_editor\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:8:\"Settings\";s:12:\"access_level\";s:14:\"manage_options\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:19:\"options-general.php\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:27:\"menu-top menu-icon-settings\";s:8:\"hookname\";s:13:\"menu-settings\";s:8:\"icon_url\";s:24:\"dashicons-admin-settings\";s:9:\"separator\";b:0;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:19:\"options-general.php\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:12:\"separator_10\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:17;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:1;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:13:\">separator_10\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:0:\"\";s:12:\"access_level\";s:4:\"read\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:12:\"separator_10\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:17:\"wp-menu-separator\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:1;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:0:\"\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}s:12:\"separator_11\";a:32:{s:10:\"page_title\";N;s:10:\"menu_title\";N;s:12:\"access_level\";N;s:16:\"extra_capability\";N;s:4:\"file\";N;s:12:\"page_heading\";N;s:8:\"position\";i:18;s:6:\"parent\";N;s:9:\"css_class\";N;s:8:\"hookname\";N;s:8:\"icon_url\";N;s:9:\"separator\";b:1;s:6:\"colors\";N;s:14:\"is_always_open\";N;s:7:\"open_in\";N;s:13:\"iframe_height\";N;s:25:\"is_iframe_scroll_disabled\";N;s:11:\"template_id\";s:13:\">separator_11\";s:14:\"is_plugin_page\";N;s:6:\"custom\";b:0;s:3:\"url\";N;s:16:\"embedded_page_id\";N;s:21:\"embedded_page_blog_id\";N;s:5:\"items\";a:0:{}s:12:\"grant_access\";a:0:{}s:7:\"missing\";b:0;s:6:\"unused\";b:0;s:6:\"hidden\";b:0;s:17:\"hidden_from_actor\";a:0:{}s:24:\"restrict_access_to_items\";b:0;s:24:\"had_access_before_hiding\";N;s:8:\"defaults\";a:21:{s:10:\"page_title\";s:0:\"\";s:10:\"menu_title\";s:0:\"\";s:12:\"access_level\";s:4:\"read\";s:16:\"extra_capability\";s:0:\"\";s:4:\"file\";s:12:\"separator_11\";s:12:\"page_heading\";s:0:\"\";s:6:\"parent\";N;s:9:\"css_class\";s:29:\"wp-menu-separator woocommerce\";s:8:\"hookname\";s:0:\"\";s:8:\"icon_url\";s:23:\"dashicons-admin-generic\";s:9:\"separator\";b:1;s:6:\"colors\";b:0;s:14:\"is_always_open\";b:0;s:7:\"open_in\";s:11:\"same_window\";s:13:\"iframe_height\";i:0;s:25:\"is_iframe_scroll_disabled\";b:0;s:14:\"is_plugin_page\";b:0;s:6:\"custom\";b:0;s:3:\"url\";s:0:\"\";s:16:\"embedded_page_id\";i:0;s:21:\"embedded_page_blog_id\";i:1;}}}s:6:\"format\";a:3:{s:4:\"name\";s:22:\"Admin Menu Editor menu\";s:7:\"version\";s:3:\"7.0\";s:13:\"is_normalized\";b:1;}s:13:\"color_presets\";a:0:{}s:20:\"component_visibility\";a:0:{}s:22:\"has_modified_dashicons\";b:0;s:16:\"last_modified_on\";s:25:\"2022-07-05T09:31:39+00:00\";s:21:\"prebuilt_virtual_caps\";a:2:{i:2;a:0:{}i:3;a:0:{}}}s:19:\"custom_network_menu\";N;s:18:\"first_install_time\";i:1657013305;s:21:\"display_survey_notice\";b:1;s:17:\"plugin_db_version\";i:140;s:24:\"security_logging_enabled\";b:0;s:17:\"menu_config_scope\";s:6:\"global\";s:13:\"plugin_access\";s:14:\"manage_options\";s:15:\"allowed_user_id\";N;s:28:\"plugins_page_allowed_user_id\";N;s:27:\"show_deprecated_hide_button\";b:1;s:37:\"dashboard_hiding_confirmation_enabled\";b:1;s:21:\"submenu_icons_enabled\";s:9:\"if_custom\";s:22:\"force_custom_dashicons\";b:1;s:16:\"ui_colour_scheme\";s:7:\"classic\";s:13:\"visible_users\";a:0:{}s:23:\"show_plugin_menu_notice\";b:0;s:20:\"unused_item_position\";s:8:\"relative\";s:23:\"unused_item_permissions\";s:9:\"unchanged\";s:15:\"error_verbosity\";i:2;s:20:\"compress_custom_menu\";b:0;s:20:\"wpml_support_enabled\";b:1;s:24:\"bbpress_override_enabled\";b:0;s:20:\"deep_nesting_enabled\";N;s:24:\"was_nesting_ever_changed\";b:0;s:16:\"is_active_module\";a:1:{s:19:\"highlight-new-menus\";b:0;}}', 'yes'),
(1101, '_transient_as_comment_count', 'O:8:\"stdClass\":7:{s:8:\"approved\";s:1:\"1\";s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(1107, 'user_role_editor', 'a:8:{s:11:\"ure_version\";s:6:\"4.51.1\";s:15:\"show_admin_role\";s:1:\"1\";s:17:\"ure_caps_readable\";s:1:\"1\";s:24:\"ure_show_deprecated_caps\";s:1:\"1\";s:23:\"ure_confirm_role_update\";s:1:\"1\";s:14:\"edit_user_caps\";s:1:\"1\";s:18:\"caps_columns_quant\";i:1;s:24:\"count_users_without_role\";s:1:\"1\";}', 'yes'),
(1108, 'wp_backup_user_roles', 'a:8:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:148:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:12:\"manage_tutor\";b:1;s:23:\"manage_tutor_instructor\";b:1;s:17:\"edit_tutor_course\";b:1;s:17:\"read_tutor_course\";b:1;s:19:\"delete_tutor_course\";b:1;s:20:\"delete_tutor_courses\";b:1;s:18:\"edit_tutor_courses\";b:1;s:25:\"edit_others_tutor_courses\";b:1;s:26:\"read_private_tutor_courses\";b:1;s:17:\"edit_tutor_lesson\";b:1;s:17:\"read_tutor_lesson\";b:1;s:19:\"delete_tutor_lesson\";b:1;s:20:\"delete_tutor_lessons\";b:1;s:18:\"edit_tutor_lessons\";b:1;s:25:\"edit_others_tutor_lessons\";b:1;s:26:\"read_private_tutor_lessons\";b:1;s:21:\"publish_tutor_lessons\";b:1;s:15:\"edit_tutor_quiz\";b:1;s:15:\"read_tutor_quiz\";b:1;s:17:\"delete_tutor_quiz\";b:1;s:20:\"delete_tutor_quizzes\";b:1;s:18:\"edit_tutor_quizzes\";b:1;s:25:\"edit_others_tutor_quizzes\";b:1;s:26:\"read_private_tutor_quizzes\";b:1;s:21:\"publish_tutor_quizzes\";b:1;s:19:\"edit_tutor_question\";b:1;s:19:\"read_tutor_question\";b:1;s:21:\"delete_tutor_question\";b:1;s:22:\"delete_tutor_questions\";b:1;s:20:\"edit_tutor_questions\";b:1;s:27:\"edit_others_tutor_questions\";b:1;s:23:\"publish_tutor_questions\";b:1;s:28:\"read_private_tutor_questions\";b:1;s:21:\"publish_tutor_courses\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:16:\"tutor_instructor\";a:2:{s:4:\"name\";s:16:\"Tutor Instructor\";s:12:\"capabilities\";a:36:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:12:\"upload_files\";b:1;s:23:\"manage_tutor_instructor\";b:1;s:17:\"edit_tutor_course\";b:1;s:17:\"read_tutor_course\";b:1;s:19:\"delete_tutor_course\";b:1;s:20:\"delete_tutor_courses\";b:1;s:18:\"edit_tutor_courses\";b:1;s:25:\"edit_others_tutor_courses\";b:1;s:26:\"read_private_tutor_courses\";b:1;s:17:\"edit_tutor_lesson\";b:1;s:17:\"read_tutor_lesson\";b:1;s:19:\"delete_tutor_lesson\";b:1;s:20:\"delete_tutor_lessons\";b:1;s:18:\"edit_tutor_lessons\";b:1;s:25:\"edit_others_tutor_lessons\";b:1;s:26:\"read_private_tutor_lessons\";b:1;s:21:\"publish_tutor_lessons\";b:1;s:15:\"edit_tutor_quiz\";b:1;s:15:\"read_tutor_quiz\";b:1;s:17:\"delete_tutor_quiz\";b:1;s:20:\"delete_tutor_quizzes\";b:1;s:18:\"edit_tutor_quizzes\";b:1;s:25:\"edit_others_tutor_quizzes\";b:1;s:26:\"read_private_tutor_quizzes\";b:1;s:21:\"publish_tutor_quizzes\";b:1;s:19:\"edit_tutor_question\";b:1;s:19:\"read_tutor_question\";b:1;s:21:\"delete_tutor_question\";b:1;s:22:\"delete_tutor_questions\";b:1;s:20:\"edit_tutor_questions\";b:1;s:27:\"edit_others_tutor_questions\";b:1;s:23:\"publish_tutor_questions\";b:1;s:28:\"read_private_tutor_questions\";b:1;s:21:\"publish_tutor_courses\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}', 'no'),
(1109, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(1110, 'wp_mail_smtp_initial_version', '3.0.3', 'no'),
(1111, 'wp_mail_smtp_version', '3.0.3', 'no'),
(1112, 'wp_mail_smtp', 'a:3:{s:4:\"mail\";a:6:{s:10:\"from_email\";s:19:\"heckmanle@gmail.com\";s:9:\"from_name\";s:12:\"Training HUB\";s:6:\"mailer\";s:4:\"mail\";s:11:\"return_path\";b:0;s:16:\"from_email_force\";b:1;s:15:\"from_name_force\";b:0;}s:4:\"smtp\";a:2:{s:7:\"autotls\";b:1;s:4:\"auth\";b:1;}s:7:\"general\";a:1:{s:29:\"summary_report_email_disabled\";b:0;}}', 'no'),
(1113, 'wp_mail_smtp_activated_time', '1657014433', 'no'),
(1114, 'wp_mail_smtp_activated', 'a:1:{s:4:\"lite\";i:1657014433;}', 'yes'),
(1117, 'action_scheduler_hybrid_store_demarkation', '79', 'yes'),
(1118, 'schema-ActionScheduler_StoreSchema', '4.0.1657014434', 'yes'),
(1119, 'schema-ActionScheduler_LoggerSchema', '2.0.1657014434', 'yes'),
(1120, 'wac_notices', 'a:1:{s:19:\"premium_advertising\";a:3:{s:7:\"message\";s:247:\"You\'re using the free version of WooCommerce Ajax Cart. If you want more features and better support, please <a href=\'https://traininghub-uat.vus.edu.vn/wp-admin/admin.php?page=woocommerce-ajax-cart&amp;tab=tab-buy.php\'>check the premium page</a>.\";s:4:\"type\";s:7:\"success\";s:11:\"dismissDays\";i:90;}}', 'yes'),
(1123, 'wp_mail_smtp_migration_version', '4', 'yes'),
(1124, 'wp_mail_smtp_debug_events_db_version', '1', 'yes'),
(1125, 'wp_mail_smtp_review_notice', 'a:2:{s:4:\"time\";i:1657014436;s:9:\"dismissed\";b:0;}', 'yes'),
(1126, 'action_scheduler_lock_async-request-runner', '1661297518', 'yes'),
(1128, '_transient_wc_count_comments', 'O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(1136, 'wp_mail_smtp_notifications', 'a:4:{s:6:\"update\";i:1657528112;s:4:\"feed\";a:0:{}s:6:\"events\";a:0:{}s:9:\"dismissed\";a:0:{}}', 'yes'),
(1139, 'ure_role_additional_options_values', 'a:3:{s:6:\"admins\";a:0:{}s:12:\"shop_manager\";a:0:{}s:13:\"administrator\";a:0:{}}', 'yes'),
(1259, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(1433, 'category_children', 'a:0:{}', 'yes'),
(1442, 'course-category_children', 'a:0:{}', 'yes'),
(1565, 'acf_version', '5.7.10', 'yes'),
(1593, 'wp_mail_smtp_debug', 'a:13:{i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:4;i:5;i:5;i:6;i:6;i:7;i:7;i:8;i:8;i:9;i:9;i:10;i:10;i:11;i:11;i:12;i:12;i:13;}', 'no'),
(1594, 'wp_mail_smtp_lite_sent_email_counter', '13', 'yes'),
(1595, 'wp_mail_smtp_lite_weekly_sent_email_counter', 'a:7:{i:28;i:4;i:29;i:1;i:30;i:3;i:31;i:2;i:32;i:1;i:33;i:1;i:34;i:1;}', 'yes'),
(1891, '_transient_product-transient-version', '1659691159', 'yes'),
(2299, 'tto_options', 'a:3:{s:10:\"capability\";s:14:\"manage_options\";s:8:\"autosort\";i:0;s:9:\"adminsort\";i:0;}', 'yes'),
(2300, 'action_scheduler_migration_status', 'complete', 'yes'),
(2304, 'product_cat_children', 'a:0:{}', 'yes'),
(3248, 'woocommerce_gateway_order', 'a:4:{s:3:\"cod\";i:0;s:4:\"bacs\";i:1;s:6:\"cheque\";i:2;s:6:\"paypal\";i:3;}', 'yes'),
(4949, '_transient_timeout_wc_term_counts', '1662276005', 'no'),
(4950, '_transient_wc_term_counts', 'a:1:{i:15;s:1:\"8\";}', 'no'),
(5746, '_transient_timeout_external_ip_address_115.79.196.110', '1661315401', 'no'),
(5747, '_transient_external_ip_address_115.79.196.110', '20.205.171.42', 'no'),
(5773, '_transient_timeout_external_ip_address_1.54.154.89', '1661334865', 'no'),
(5774, '_transient_external_ip_address_1.54.154.89', '20.205.171.42', 'no'),
(5799, '_transient_timeout_external_ip_address_3.80.93.160', '1661382300', 'no'),
(5800, '_transient_external_ip_address_3.80.93.160', '20.205.171.42', 'no'),
(5802, '_transient_timeout_external_ip_address_54.198.91.245', '1661382304', 'no'),
(5803, '_transient_external_ip_address_54.198.91.245', '20.205.171.42', 'no'),
(5804, '_transient_timeout_external_ip_address_34.201.105.178', '1661382306', 'no'),
(5805, '_transient_external_ip_address_34.201.105.178', '20.205.171.42', 'no'),
(5808, '_transient_timeout_external_ip_address_113.161.33.36', '1661396984', 'no'),
(5809, '_transient_external_ip_address_113.161.33.36', '20.205.171.42', 'no'),
(5823, '_transient_timeout_external_ip_address_14.161.20.54', '1661397091', 'no'),
(5824, '_transient_external_ip_address_14.161.20.54', '20.205.171.42', 'no'),
(5828, '_transient_timeout_external_ip_address_171.252.153.27', '1661397199', 'no'),
(5829, '_transient_external_ip_address_171.252.153.27', '20.205.171.42', 'no'),
(5865, '_transient_timeout_external_ip_address_115.78.12.122', '1661487095', 'no'),
(5866, '_transient_external_ip_address_115.78.12.122', '20.205.171.42', 'no'),
(5879, '_transient_timeout_external_ip_address_113.170.57.27', '1661487256', 'no'),
(5880, '_transient_external_ip_address_113.170.57.27', '20.205.171.42', 'no'),
(5884, '_transient_timeout_external_ip_address_40.77.188.4', '1661495268', 'no'),
(5885, '_transient_external_ip_address_40.77.188.4', '20.205.171.42', 'no'),
(5891, '_transient_timeout_external_ip_address_20.205.171.42', '1661506829', 'no'),
(5892, '_transient_external_ip_address_20.205.171.42', '20.205.171.42', 'no'),
(5916, '_transient_timeout_external_ip_address_171.252.153.99', '1661557427', 'no'),
(5917, '_transient_external_ip_address_171.252.153.99', '20.205.171.42', 'no'),
(5943, '_transient_timeout_external_ip_address_40.77.190.140', '1661586473', 'no'),
(5944, '_transient_external_ip_address_40.77.190.140', '20.205.171.42', 'no'),
(5973, '_transient_timeout_external_ip_address_40.77.139.105', '1661625969', 'no'),
(5974, '_transient_external_ip_address_40.77.139.105', '20.205.171.42', 'no'),
(5981, '_transient_timeout_external_ip_address_54.164.178.21', '1661654229', 'no'),
(5982, '_transient_external_ip_address_54.164.178.21', '20.205.171.42', 'no'),
(5990, '_transient_timeout_external_ip_address_3.92.182.40', '1661654233', 'no'),
(5991, '_transient_external_ip_address_3.92.182.40', '20.205.171.42', 'no'),
(5995, '_transient_timeout_external_ip_address_34.235.152.210', '1661654662', 'no'),
(5996, '_transient_external_ip_address_34.235.152.210', '20.205.171.42', 'no'),
(5998, '_transient_timeout_external_ip_address_54.227.32.154', '1661654680', 'no'),
(5999, '_transient_external_ip_address_54.227.32.154', '20.205.171.42', 'no'),
(6000, '_transient_timeout_external_ip_address_3.94.165.119', '1661654713', 'no'),
(6001, '_transient_external_ip_address_3.94.165.119', '20.205.171.42', 'no'),
(6007, '_transient_timeout_external_ip_address_123.20.42.112', '1661670603', 'no'),
(6008, '_transient_external_ip_address_123.20.42.112', '20.205.171.42', 'no'),
(6015, '_transient_timeout_external_ip_address_54.221.131.203', '1661675536', 'no'),
(6016, '_transient_external_ip_address_54.221.131.203', '20.205.171.42', 'no'),
(6017, '_transient_timeout_external_ip_address_3.93.169.244', '1661675540', 'no'),
(6018, '_transient_external_ip_address_3.93.169.244', '20.205.171.42', 'no'),
(6019, '_transient_timeout_external_ip_address_54.167.223.169', '1661677213', 'no'),
(6020, '_transient_external_ip_address_54.167.223.169', '20.205.171.42', 'no'),
(6023, '_transient_timeout_external_ip_address_3.85.56.22', '1661677260', 'no'),
(6024, '_transient_external_ip_address_3.85.56.22', '20.205.171.42', 'no'),
(6029, '_transient_timeout_external_ip_address_171.246.236.232', '1661686735', 'no'),
(6030, '_transient_external_ip_address_171.246.236.232', '20.205.171.42', 'no'),
(6033, '_transient_timeout_external_ip_address_171.247.43.201', '1661688867', 'no'),
(6034, '_transient_external_ip_address_171.247.43.201', '20.205.171.42', 'no'),
(6063, '_transient_timeout_external_ip_address_40.77.191.253', '1661701328', 'no'),
(6064, '_transient_external_ip_address_40.77.191.253', '20.205.171.42', 'no'),
(6066, '_transient_timeout_external_ip_address_203.114.232.116', '1661703607', 'no'),
(6067, '_transient_external_ip_address_203.114.232.116', '20.205.171.42', 'no'),
(6102, '_transient_timeout_external_ip_address_40.77.189.24', '1661759769', 'no'),
(6103, '_transient_external_ip_address_40.77.189.24', '20.205.171.42', 'no'),
(6105, '_transient_timeout_external_ip_address_3.83.149.198', '1661761446', 'no'),
(6106, '_transient_external_ip_address_3.83.149.198', '20.205.171.42', 'no'),
(6108, '_transient_timeout_external_ip_address_34.205.37.11', '1661761463', 'no'),
(6109, '_transient_external_ip_address_34.205.37.11', '20.205.171.42', 'no'),
(6118, '_transient_timeout_acf_plugin_updates', '1661354959', 'no'),
(6119, '_transient_acf_plugin_updates', 'a:4:{s:7:\"plugins\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";a:8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.12.3\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:5:\"6.0.1\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}}}s:10:\"expiration\";i:172800;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.7.10\";}}', 'no'),
(6133, '_transient_timeout_external_ip_address_40.77.189.154', '1661799000', 'no'),
(6134, '_transient_external_ip_address_40.77.189.154', '20.205.171.42', 'no'),
(6152, '_transient_timeout_external_ip_address_113.173.231.170', '1661832784', 'no'),
(6153, '_transient_external_ip_address_113.173.231.170', '20.205.171.42', 'no'),
(6178, '_transient_timeout__woocommerce_helper_updates', '1661310663', 'no'),
(6179, '_transient__woocommerce_helper_updates', 'a:4:{s:4:\"hash\";s:32:\"5ad608ff5a7becbcecc77476d6413ddd\";s:7:\"updated\";i:1661267463;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}', 'no'),
(6201, '_transient_timeout__woocommerce_helper_subscriptions', '1661310113', 'no'),
(6202, '_transient__woocommerce_helper_subscriptions', 'a:0:{}', 'no'),
(6203, '_site_transient_timeout_theme_roots', '1661311013', 'no'),
(6204, '_site_transient_theme_roots', 'a:1:{s:7:\"site_el\";s:7:\"/themes\";}', 'no'),
(6206, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:11:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.0.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.0.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-6.0.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-6.0.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"6.0.1\";s:7:\"version\";s:5:\"6.0.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.0.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.0.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-6.0.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-6.0.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"6.0.1\";s:7:\"version\";s:5:\"6.0.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.0.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.0.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-6.0-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-6.0-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:3:\"6.0\";s:7:\"version\";s:3:\"6.0\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.9.3.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.9.3.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.9.3-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.9.3-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.9.3\";s:7:\"version\";s:5:\"5.9.3\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:4;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.9.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.9.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.9.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.9.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.9.2\";s:7:\"version\";s:5:\"5.9.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:5;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.8.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.8.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.8.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.8.4-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.8.4\";s:7:\"version\";s:5:\"5.8.4\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:6;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.6.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.6.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.7.6-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.7.6-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.7.6\";s:7:\"version\";s:5:\"5.7.6\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:7;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.6.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.6.8.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.6.8-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.6.8-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.6.8\";s:7:\"version\";s:5:\"5.6.8\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:8;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.5.9.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.5.9.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.5.9-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.5.9-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.5.9\";s:7:\"version\";s:5:\"5.5.9\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:9;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:60:\"https://downloads.wordpress.org/release/wordpress-5.4.10.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:60:\"https://downloads.wordpress.org/release/wordpress-5.4.10.zip\";s:10:\"no_content\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.4.10-no-content.zip\";s:11:\"new_bundled\";s:72:\"https://downloads.wordpress.org/release/wordpress-5.4.10-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:6:\"5.4.10\";s:7:\"version\";s:6:\"5.4.10\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:10;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:60:\"https://downloads.wordpress.org/release/wordpress-5.3.12.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:60:\"https://downloads.wordpress.org/release/wordpress-5.3.12.zip\";s:10:\"no_content\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.3.12-no-content.zip\";s:11:\"new_bundled\";s:72:\"https://downloads.wordpress.org/release/wordpress-5.3.12-new-bundled.zip\";s:7:\"partial\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.3.12-partial-0.zip\";s:8:\"rollback\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.3.12-rollback-0.zip\";}s:7:\"current\";s:6:\"5.3.12\";s:7:\"version\";s:6:\"5.3.12\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:3:\"5.3\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1661309217;s:15:\"version_checked\";s:3:\"5.3\";s:12:\"translations\";a:0:{}}', 'no'),
(6207, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1661309218;s:7:\"checked\";a:1:{s:7:\"site_el\";s:5:\"1.0.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(6208, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1661309219;s:7:\"checked\";a:42:{s:33:\"admin-menu-editor/menu-editor.php\";s:6:\"1.10.2\";s:32:\"dc-custom-admin/custom-admin.php\";s:3:\"1.0\";s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.7.10\";s:19:\"akismet/akismet.php\";s:6:\"4.1.10\";s:17:\"bessfu/bessfu.php\";s:5:\"1.0.0\";s:45:\"taxonomy-terms-order/taxonomy-terms-order.php\";s:5:\"1.6.1\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.1.3\";s:43:\"content-syndication/content-syndication.php\";s:5:\"1.0.0\";s:27:\"core-system/core-system.php\";s:5:\"1.0.0\";s:24:\"elementors/elementor.php\";s:5:\"2.9.7\";s:33:\"elementors-refactor/elementor.php\";s:5:\"2.9.7\";s:33:\"duplicate-post/duplicate-post.php\";s:5:\"3.2.3\";s:53:\"facebook-for-woocommerce/facebook-for-woocommerce.php\";s:6:\"2.6.16\";s:9:\"hello.php\";s:5:\"1.7.2\";s:15:\"tutor/tutor.php\";s:5:\"2.0.0\";s:20:\"lmspro/tutor-pro.php\";s:5:\"2.0.3\";s:21:\"_lmspro/tutor-pro.php\";s:5:\"2.0.3\";s:37:\"post-types-order/post-types-order.php\";s:7:\"1.9.5.6\";s:27:\"woo-product-slider/main.php\";s:6:\"2.1.16\";s:51:\"rewrite-rules-inspector/rewrite-rules-inspector.php\";s:5:\"1.3.1\";s:21:\"safe-svg/safe-svg.php\";s:5:\"2.0.1\";s:27:\"svg-support/svg-support.php\";s:6:\"2.3.18\";s:37:\"tinymce-advanced/tinymce-advanced.php\";s:8:\"4.3.10.1\";s:41:\"_lmspro/tutor-lms-certificate-builder.php\";s:5:\"1.0.1\";s:37:\"user-role-editor/user-role-editor.php\";s:6:\"4.51.1\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.7.0\";s:39:\"woocommerce-admin/woocommerce-admin.php\";s:5:\"3.3.2\";s:37:\"woocommerce-ajax-cart/wooajaxcart.php\";s:5:\"1.3.5\";s:45:\"woocommerce-multilingual/wpml-woocommerce.php\";s:5:\"4.6.7\";s:69:\"woocommerce-per-product-shipping/woocommerce-shipping-per-product.php\";s:5:\"2.3.6\";s:23:\"wordfence/wordfence.php\";s:5:\"7.5.4\";s:51:\"wordpress-popular-posts/wordpress-popular-posts.php\";s:5:\"5.5.0\";s:42:\"woo-product-bundle/wpc-product-bundles.php\";s:5:\"5.2.6\";s:50:\"woo-product-bundle-premium/wpc-product-bundles.php\";s:5:\"5.3.1\";s:29:\"wp-mail-smtp/wp_mail_smtp.php\";s:5:\"3.0.3\";s:31:\"wp-migrate-db/wp-migrate-db.php\";s:3:\"2.1\";s:33:\"wpml-media-translation/plugin.php\";s:5:\"2.5.2\";s:40:\"sitepress-multilingual-cms/sitepress.php\";s:5:\"4.2.6\";s:34:\"wpml-string-translation/plugin.php\";s:6:\"2.10.4\";s:38:\"wpml-translation-management/plugin.php\";s:5:\"2.8.5\";s:27:\"wp-super-cache/wp-cache.php\";s:5:\"1.7.4\";s:24:\"wordpress-seo/wp-seo.php\";s:4:\"11.5\";}s:8:\"response\";a:18:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"5.0\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.5.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:45:\"taxonomy-terms-order/taxonomy-terms-order.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:34:\"w.org/plugins/taxonomy-terms-order\";s:4:\"slug\";s:20:\"taxonomy-terms-order\";s:6:\"plugin\";s:45:\"taxonomy-terms-order/taxonomy-terms-order.php\";s:11:\"new_version\";s:5:\"1.7.1\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/taxonomy-terms-order/\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/plugin/taxonomy-terms-order.1.7.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/taxonomy-terms-order/assets/icon-256x256.png?rev=1564412\";s:2:\"1x\";s:73:\"https://ps.w.org/taxonomy-terms-order/assets/icon-128x128.png?rev=1564412\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/taxonomy-terms-order/assets/banner-1544x500.png?rev=1564412\";s:2:\"1x\";s:75:\"https://ps.w.org/taxonomy-terms-order/assets/banner-772x250.png?rev=1564412\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"2.8\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:53:\"facebook-for-woocommerce/facebook-for-woocommerce.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:38:\"w.org/plugins/facebook-for-woocommerce\";s:4:\"slug\";s:24:\"facebook-for-woocommerce\";s:6:\"plugin\";s:53:\"facebook-for-woocommerce/facebook-for-woocommerce.php\";s:11:\"new_version\";s:6:\"2.6.21\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/facebook-for-woocommerce/\";s:7:\"package\";s:74:\"https://downloads.wordpress.org/plugin/facebook-for-woocommerce.2.6.21.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:77:\"https://ps.w.org/facebook-for-woocommerce/assets/icon-256x256.png?rev=2040223\";s:2:\"1x\";s:69:\"https://ps.w.org/facebook-for-woocommerce/assets/icon.svg?rev=2040223\";s:3:\"svg\";s:69:\"https://ps.w.org/facebook-for-woocommerce/assets/icon.svg?rev=2040223\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.4\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"7.0\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:15:\"tutor/tutor.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:19:\"w.org/plugins/tutor\";s:4:\"slug\";s:5:\"tutor\";s:6:\"plugin\";s:15:\"tutor/tutor.php\";s:11:\"new_version\";s:5:\"2.0.9\";s:3:\"url\";s:36:\"https://wordpress.org/plugins/tutor/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/tutor.2.0.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:58:\"https://ps.w.org/tutor/assets/icon-256X256.gif?rev=2694448\";s:2:\"1x\";s:58:\"https://ps.w.org/tutor/assets/icon-256X256.gif?rev=2694448\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/tutor/assets/banner-1544x500.jpg?rev=2694448\";s:2:\"1x\";s:60:\"https://ps.w.org/tutor/assets/banner-772x250.jpg?rev=2694448\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.3\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"7.0\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:37:\"post-types-order/post-types-order.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:30:\"w.org/plugins/post-types-order\";s:4:\"slug\";s:16:\"post-types-order\";s:6:\"plugin\";s:37:\"post-types-order/post-types-order.php\";s:11:\"new_version\";s:7:\"1.9.9.1\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/post-types-order/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/post-types-order.1.9.9.1.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/post-types-order/assets/icon-128x128.png?rev=1226428\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/post-types-order/assets/banner-1544x500.png?rev=1675574\";s:2:\"1x\";s:71:\"https://ps.w.org/post-types-order/assets/banner-772x250.png?rev=1429949\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"2.8\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"woo-product-slider/main.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:32:\"w.org/plugins/woo-product-slider\";s:4:\"slug\";s:18:\"woo-product-slider\";s:6:\"plugin\";s:27:\"woo-product-slider/main.php\";s:11:\"new_version\";s:5:\"2.6.0\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/woo-product-slider/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/woo-product-slider.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/woo-product-slider/assets/icon-256x256.png?rev=2727777\";s:2:\"1x\";s:71:\"https://ps.w.org/woo-product-slider/assets/icon-128x128.png?rev=2727777\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:73:\"https://ps.w.org/woo-product-slider/assets/banner-772x250.png?rev=2646089\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:21:\"safe-svg/safe-svg.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:22:\"w.org/plugins/safe-svg\";s:4:\"slug\";s:8:\"safe-svg\";s:6:\"plugin\";s:21:\"safe-svg/safe-svg.php\";s:11:\"new_version\";s:5:\"2.0.2\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/safe-svg/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/safe-svg.2.0.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:61:\"https://ps.w.org/safe-svg/assets/icon-256x256.png?rev=2683939\";s:2:\"1x\";s:53:\"https://ps.w.org/safe-svg/assets/icon.svg?rev=2683939\";s:3:\"svg\";s:53:\"https://ps.w.org/safe-svg/assets/icon.svg?rev=2683939\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/safe-svg/assets/banner-1544x500.png?rev=2683939\";s:2:\"1x\";s:63:\"https://ps.w.org/safe-svg/assets/banner-772x250.png?rev=2683939\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"7.0\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"svg-support/svg-support.php\";O:8:\"stdClass\":14:{s:2:\"id\";s:25:\"w.org/plugins/svg-support\";s:4:\"slug\";s:11:\"svg-support\";s:6:\"plugin\";s:27:\"svg-support/svg-support.php\";s:11:\"new_version\";s:5:\"2.4.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/svg-support/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/svg-support.2.4.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:64:\"https://ps.w.org/svg-support/assets/icon-256x256.png?rev=1417738\";s:2:\"1x\";s:56:\"https://ps.w.org/svg-support/assets/icon.svg?rev=1417738\";s:3:\"svg\";s:56:\"https://ps.w.org/svg-support/assets/icon.svg?rev=1417738\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/svg-support/assets/banner-1544x500.jpg?rev=1215377\";s:2:\"1x\";s:66:\"https://ps.w.org/svg-support/assets/banner-772x250.jpg?rev=1215377\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.8\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"5.3\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}s:14:\"upgrade_notice\";s:128:\"<p>2.4.2 fixes srcset issue firing PHP warnings for some themes and original image IDs missing on replacement to inline SVG.</p>\";}s:37:\"user-role-editor/user-role-editor.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:30:\"w.org/plugins/user-role-editor\";s:4:\"slug\";s:16:\"user-role-editor\";s:6:\"plugin\";s:37:\"user-role-editor/user-role-editor.php\";s:11:\"new_version\";s:4:\"4.63\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/user-role-editor/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/user-role-editor.4.63.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-256x256.jpg?rev=1020390\";s:2:\"1x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-128x128.jpg?rev=1020390\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/user-role-editor/assets/banner-772x250.png?rev=1263116\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.4\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"7.3\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:37:\"woocommerce-ajax-cart/wooajaxcart.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:35:\"w.org/plugins/woocommerce-ajax-cart\";s:4:\"slug\";s:21:\"woocommerce-ajax-cart\";s:6:\"plugin\";s:37:\"woocommerce-ajax-cart/wooajaxcart.php\";s:11:\"new_version\";s:6:\"1.3.24\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/woocommerce-ajax-cart/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/woocommerce-ajax-cart.1.3.24.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:74:\"https://ps.w.org/woocommerce-ajax-cart/assets/icon-128x128.png?rev=1186993\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:45:\"woocommerce-multilingual/wpml-woocommerce.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:38:\"w.org/plugins/woocommerce-multilingual\";s:4:\"slug\";s:24:\"woocommerce-multilingual\";s:6:\"plugin\";s:45:\"woocommerce-multilingual/wpml-woocommerce.php\";s:11:\"new_version\";s:5:\"5.0.2\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/woocommerce-multilingual/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/woocommerce-multilingual.5.0.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/woocommerce-multilingual/assets/icon-256x256.png?rev=2026021\";s:2:\"1x\";s:77:\"https://ps.w.org/woocommerce-multilingual/assets/icon-128x128.png?rev=2026021\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/woocommerce-multilingual/assets/banner-772x250.png?rev=2026021\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:23:\"wordfence/wordfence.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:23:\"w.org/plugins/wordfence\";s:4:\"slug\";s:9:\"wordfence\";s:6:\"plugin\";s:23:\"wordfence/wordfence.php\";s:11:\"new_version\";s:5:\"7.6.0\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/wordfence/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/wordfence.7.6.0.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:62:\"https://ps.w.org/wordfence/assets/icon-256x256.png?rev=2070855\";s:2:\"1x\";s:54:\"https://ps.w.org/wordfence/assets/icon.svg?rev=2070865\";s:3:\"svg\";s:54:\"https://ps.w.org/wordfence/assets/icon.svg?rev=2070865\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/wordfence/assets/banner-1544x500.jpg?rev=2124102\";s:2:\"1x\";s:64:\"https://ps.w.org/wordfence/assets/banner-772x250.jpg?rev=2124102\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"3.9\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"5.3\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:51:\"wordpress-popular-posts/wordpress-popular-posts.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:37:\"w.org/plugins/wordpress-popular-posts\";s:4:\"slug\";s:23:\"wordpress-popular-posts\";s:6:\"plugin\";s:51:\"wordpress-popular-posts/wordpress-popular-posts.php\";s:11:\"new_version\";s:5:\"6.0.3\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/wordpress-popular-posts/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/wordpress-popular-posts.6.0.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/wordpress-popular-posts/assets/icon-256x256.png?rev=1232659\";s:2:\"1x\";s:76:\"https://ps.w.org/wordpress-popular-posts/assets/icon-128x128.png?rev=1232659\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/wordpress-popular-posts/assets/banner-772x250.png?rev=2179381\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.3\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"7.2\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:42:\"woo-product-bundle/wpc-product-bundles.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:32:\"w.org/plugins/woo-product-bundle\";s:4:\"slug\";s:18:\"woo-product-bundle\";s:6:\"plugin\";s:42:\"woo-product-bundle/wpc-product-bundles.php\";s:11:\"new_version\";s:5:\"6.3.7\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/woo-product-bundle/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/woo-product-bundle.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/woo-product-bundle/assets/icon-128x128.png?rev=1857793\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:73:\"https://ps.w.org/woo-product-bundle/assets/banner-772x250.png?rev=2425210\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.0\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:29:\"wp-mail-smtp/wp_mail_smtp.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:26:\"w.org/plugins/wp-mail-smtp\";s:4:\"slug\";s:12:\"wp-mail-smtp\";s:6:\"plugin\";s:29:\"wp-mail-smtp/wp_mail_smtp.php\";s:11:\"new_version\";s:5:\"3.5.2\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/wp-mail-smtp/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wp-mail-smtp.3.5.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/wp-mail-smtp/assets/icon-256x256.png?rev=1755440\";s:2:\"1x\";s:65:\"https://ps.w.org/wp-mail-smtp/assets/icon-128x128.png?rev=1755440\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/wp-mail-smtp/assets/banner-1544x500.png?rev=2468655\";s:2:\"1x\";s:67:\"https://ps.w.org/wp-mail-smtp/assets/banner-772x250.png?rev=2468655\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.2\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:6:\"5.6.20\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:31:\"wp-migrate-db/wp-migrate-db.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:27:\"w.org/plugins/wp-migrate-db\";s:4:\"slug\";s:13:\"wp-migrate-db\";s:6:\"plugin\";s:31:\"wp-migrate-db/wp-migrate-db.php\";s:11:\"new_version\";s:5:\"2.3.3\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wp-migrate-db/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/wp-migrate-db.2.3.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/wp-migrate-db/assets/icon-256x256.jpg?rev=1809889\";s:2:\"1x\";s:66:\"https://ps.w.org/wp-migrate-db/assets/icon-128x128.jpg?rev=1809889\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wp-migrate-db/assets/banner-1544x500.jpg?rev=1809889\";s:2:\"1x\";s:68:\"https://ps.w.org/wp-migrate-db/assets/banner-772x250.jpg?rev=1809889\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.2\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:20:\"lmspro/tutor-pro.php\";O:8:\"stdClass\":5:{s:11:\"new_version\";s:5:\"2.0.9\";s:7:\"package\";s:13:\"&product-key=\";s:6:\"tested\";s:5:\"6.0.1\";s:4:\"slug\";s:20:\"lmspro/tutor-pro.php\";s:3:\"url\";s:42:\"https://www.themeum.com/product/tutor-lms/\";}s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.12.3\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:5:\"6.0.1\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}}}s:12:\"translations\";a:7:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:7:\"akismet\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:6:\"4.1.10\";s:7:\"updated\";s:19:\"2019-11-12 11:13:56\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/translation/plugin/akismet/4.1.10/vi.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.1.3\";s:7:\"updated\";s:19:\"2019-08-01 04:56:38\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/5.1.3/vi.zip\";s:10:\"autoupdate\";b:1;}i:2;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"duplicate-post\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"3.2.3\";s:7:\"updated\";s:19:\"2019-07-13 13:53:21\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/plugin/duplicate-post/3.2.3/vi.zip\";s:10:\"autoupdate\";b:1;}i:3;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:11:\"hello-dolly\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"1.7.2\";s:7:\"updated\";s:19:\"2019-11-12 11:26:07\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/translation/plugin/hello-dolly/1.7.2/vi.zip\";s:10:\"autoupdate\";b:1;}i:4;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:11:\"woocommerce\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"3.6.5\";s:7:\"updated\";s:19:\"2019-06-10 02:29:26\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/translation/plugin/woocommerce/3.6.5/vi.zip\";s:10:\"autoupdate\";b:1;}i:5;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:12:\"wp-mail-smtp\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"3.0.3\";s:7:\"updated\";s:19:\"2019-11-12 11:21:12\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/translation/plugin/wp-mail-smtp/3.0.3/vi.zip\";s:10:\"autoupdate\";b:1;}i:6;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:13:\"wordpress-seo\";s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:4:\"11.5\";s:7:\"updated\";s:19:\"2019-05-15 13:21:34\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/translation/plugin/wordpress-seo/11.5/vi.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:10:{s:33:\"admin-menu-editor/menu-editor.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:31:\"w.org/plugins/admin-menu-editor\";s:4:\"slug\";s:17:\"admin-menu-editor\";s:6:\"plugin\";s:33:\"admin-menu-editor/menu-editor.php\";s:11:\"new_version\";s:6:\"1.10.2\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/admin-menu-editor/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/admin-menu-editor.1.10.2.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/admin-menu-editor/assets/icon-128x128.png?rev=1418604\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/admin-menu-editor/assets/banner-772x250.png?rev=1419590\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.6.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.6.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.9\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";a:0:{}}s:33:\"duplicate-post/duplicate-post.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:28:\"w.org/plugins/duplicate-post\";s:4:\"slug\";s:14:\"duplicate-post\";s:6:\"plugin\";s:33:\"duplicate-post/duplicate-post.php\";s:11:\"new_version\";s:3:\"4.5\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/duplicate-post/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/duplicate-post.4.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-256x256.png?rev=2336666\";s:2:\"1x\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-128x128.png?rev=2336666\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/duplicate-post/assets/banner-1544x500.png?rev=2336666\";s:2:\"1x\";s:69:\"https://ps.w.org/duplicate-post/assets/banner-772x250.png?rev=2336666\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.9\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:6:\"5.6.20\";s:13:\"compatibility\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/hello-dolly/assets/banner-1544x500.jpg?rev=2645582\";s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}s:51:\"rewrite-rules-inspector/rewrite-rules-inspector.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:37:\"w.org/plugins/rewrite-rules-inspector\";s:4:\"slug\";s:23:\"rewrite-rules-inspector\";s:6:\"plugin\";s:51:\"rewrite-rules-inspector/rewrite-rules-inspector.php\";s:11:\"new_version\";s:5:\"1.3.1\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/rewrite-rules-inspector/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/rewrite-rules-inspector.1.3.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:74:\"https://s.w.org/plugins/geopattern-icon/rewrite-rules-inspector_e2e3e4.svg\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/rewrite-rules-inspector/assets/banner-1544x500.png?rev=2533834\";s:2:\"1x\";s:78:\"https://ps.w.org/rewrite-rules-inspector/assets/banner-772x250.png?rev=2533843\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"3.1\";}s:37:\"tinymce-advanced/tinymce-advanced.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:30:\"w.org/plugins/tinymce-advanced\";s:4:\"slug\";s:16:\"tinymce-advanced\";s:6:\"plugin\";s:37:\"tinymce-advanced/tinymce-advanced.php\";s:11:\"new_version\";s:5:\"5.6.0\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/tinymce-advanced/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/tinymce-advanced.5.6.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-256x256.png?rev=971511\";s:2:\"1x\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-128x128.png?rev=971511\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/tinymce-advanced/assets/banner-1544x500.png?rev=2390186\";s:2:\"1x\";s:71:\"https://ps.w.org/tinymce-advanced/assets/banner-772x250.png?rev=2390186\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.6\";s:6:\"tested\";s:5:\"5.7.6\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"6.8.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.6.8.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2366418\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2366418\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2366418\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2366418\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.8\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"7.2\";s:13:\"compatibility\";a:0:{}}s:39:\"woocommerce-admin/woocommerce-admin.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:31:\"w.org/plugins/woocommerce-admin\";s:4:\"slug\";s:17:\"woocommerce-admin\";s:6:\"plugin\";s:39:\"woocommerce-admin/woocommerce-admin.php\";s:11:\"new_version\";s:5:\"3.3.2\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/woocommerce-admin/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/woocommerce-admin.3.3.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/woocommerce-admin/assets/icon-256x256.png?rev=2413881\";s:2:\"1x\";s:70:\"https://ps.w.org/woocommerce-admin/assets/icon-128x128.png?rev=2413881\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/woocommerce-admin/assets/banner-1544x500.png?rev=2413881\";s:2:\"1x\";s:72:\"https://ps.w.org/woocommerce-admin/assets/banner-772x250.png?rev=2413881\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.6\";}s:27:\"wp-super-cache/wp-cache.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:28:\"w.org/plugins/wp-super-cache\";s:4:\"slug\";s:14:\"wp-super-cache\";s:6:\"plugin\";s:27:\"wp-super-cache/wp-cache.php\";s:11:\"new_version\";s:3:\"1.8\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/wp-super-cache/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wp-super-cache.1.8.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/wp-super-cache/assets/icon-256x256.png?rev=1095422\";s:2:\"1x\";s:67:\"https://ps.w.org/wp-super-cache/assets/icon-128x128.png?rev=1095422\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/wp-super-cache/assets/banner-1544x500.png?rev=1082414\";s:2:\"1x\";s:69:\"https://ps.w.org/wp-super-cache/assets/banner-772x250.png?rev=1082414\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.9\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:4:\"19.6\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wordpress-seo.19.6.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=2643727\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=2643727\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=2643727\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=2643727\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=2643727\";}s:8:\"requires\";s:3:\"5.9\";s:6:\"tested\";s:5:\"6.0.1\";s:12:\"requires_php\";s:6:\"5.6.20\";s:13:\"compatibility\";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `post_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(4, 11, '_wp_attached_file', 'woocommerce-placeholder.png'),
(5, 11, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:5:\"sizes\";a:7:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(21, 31, '_edit_lock', '1657938682:1'),
(22, 31, '_edit_last', '1'),
(23, 31, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(24, 31, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(25, 31, '_tutor_course_level', 'intermediate'),
(26, 31, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(27, 31, '_tutor_enable_qa', 'yes'),
(28, 31, '_tutor_is_public_course', 'no'),
(47, 12, '_edit_lock', '1656954343:1'),
(48, 1, '_edit_lock', '1656991103:1'),
(59, 62, '_edit_lock', '1657937307:1'),
(60, 62, '_edit_last', '1'),
(61, 62, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(62, 62, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(63, 62, '_tutor_course_level', 'intermediate'),
(64, 62, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(65, 62, '_tutor_enable_qa', 'yes'),
(66, 62, '_tutor_is_public_course', 'no'),
(81, 79, '_edit_lock', '1657937340:1'),
(83, 79, '_edit_last', '1'),
(84, 79, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(85, 79, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(86, 79, '_tutor_course_level', 'intermediate'),
(87, 79, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(88, 79, '_tutor_enable_qa', 'yes'),
(89, 79, '_tutor_is_public_course', 'no'),
(90, 81, '_menu_item_type', 'custom'),
(91, 81, '_menu_item_menu_item_parent', '0'),
(92, 81, '_menu_item_object_id', '81'),
(93, 81, '_menu_item_object', 'custom'),
(94, 81, '_menu_item_target', ''),
(95, 81, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(96, 81, '_menu_item_xfn', ''),
(97, 81, '_menu_item_url', '#'),
(99, 82, '_menu_item_type', 'custom'),
(100, 82, '_menu_item_menu_item_parent', '0'),
(101, 82, '_menu_item_object_id', '82'),
(102, 82, '_menu_item_object', 'custom'),
(103, 82, '_menu_item_target', ''),
(104, 82, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(105, 82, '_menu_item_xfn', ''),
(106, 82, '_menu_item_url', '#'),
(108, 83, '_menu_item_type', 'custom'),
(109, 83, '_menu_item_menu_item_parent', '0'),
(110, 83, '_menu_item_object_id', '83'),
(111, 83, '_menu_item_object', 'custom'),
(112, 83, '_menu_item_target', ''),
(113, 83, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(114, 83, '_menu_item_xfn', ''),
(115, 83, '_menu_item_url', '#'),
(117, 84, '_menu_item_type', 'custom'),
(118, 84, '_menu_item_menu_item_parent', '0'),
(119, 84, '_menu_item_object_id', '84'),
(120, 84, '_menu_item_object', 'custom'),
(121, 84, '_menu_item_target', ''),
(122, 84, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(123, 84, '_menu_item_xfn', ''),
(124, 84, '_menu_item_url', '#'),
(126, 85, '_menu_item_type', 'custom'),
(127, 85, '_menu_item_menu_item_parent', '0'),
(128, 85, '_menu_item_object_id', '85'),
(129, 85, '_menu_item_object', 'custom'),
(130, 85, '_menu_item_target', ''),
(131, 85, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(132, 85, '_menu_item_xfn', ''),
(133, 85, '_menu_item_url', '#'),
(135, 86, '_menu_item_type', 'custom'),
(136, 86, '_menu_item_menu_item_parent', '0'),
(137, 86, '_menu_item_object_id', '86'),
(138, 86, '_menu_item_object', 'custom'),
(139, 86, '_menu_item_target', ''),
(140, 86, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(141, 86, '_menu_item_xfn', ''),
(142, 86, '_menu_item_url', '#'),
(144, 90, '_edit_lock', '1657528109:1'),
(149, 90, '_wp_old_slug', 'trang-chu'),
(150, 93, '_edit_lock', '1658931428:1'),
(151, 95, '_edit_lock', '1657530182:1'),
(152, 95, '_edit_last', '1'),
(153, 98, '_wp_attached_file', '2022/07/hero-banner-1-scaled.jpg'),
(154, 98, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:887;s:4:\"file\";s:32:\"2022/07/hero-banner-1-scaled.jpg\";s:5:\"sizes\";a:14:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-300x104.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:104;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"hero-banner-1-1024x355.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:355;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-768x266.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:266;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:26:\"hero-banner-1-1536x532.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:532;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:26:\"hero-banner-1-2048x709.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:709;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"site-featured-image\";a:4:{s:4:\"file\";s:27:\"hero-banner-1-2000x1200.jpg\";s:5:\"width\";i:2000;s:6:\"height\";i:1200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:25:\"hero-banner-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-600x208.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:208;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-600x208.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:208;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"hero-banner-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:17:\"hero-banner-1.jpg\";}'),
(155, 93, '_edit_last', '1'),
(156, 93, 'hero_banner_0_image', '109'),
(157, 93, '_hero_banner_0_image', 'field_62cbe2c6d2d40'),
(158, 93, 'hero_banner_1_image', '98'),
(159, 93, '_hero_banner_1_image', 'field_62cbe2c6d2d40'),
(160, 93, 'hero_banner', '2'),
(161, 93, '_hero_banner', 'field_62cbe268d2d3f'),
(162, 99, 'hero_banner_0_image', '98'),
(163, 99, '_hero_banner_0_image', 'field_62cbe2c6d2d40'),
(164, 99, 'hero_banner_1_image', '98'),
(165, 99, '_hero_banner_1_image', 'field_62cbe2c6d2d40'),
(166, 99, 'hero_banner', '2'),
(167, 99, '_hero_banner', 'field_62cbe268d2d3f'),
(168, 100, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:3:\"100\";s:17:\"enrollment_expiry\";s:3:\"100\";}'),
(169, 100, '_course_duration', 'a:3:{s:5:\"hours\";s:3:\"300\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(170, 100, '_tutor_course_level', 'all_levels'),
(171, 100, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(172, 100, '_tutor_enable_qa', 'no'),
(173, 100, '_tutor_is_public_course', 'no'),
(174, 101, '_wp_attached_file', '2022/07/Rectangle-19.jpg'),
(175, 101, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1440;s:6:\"height\";i:350;s:4:\"file\";s:24:\"2022/07/Rectangle-19.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"Rectangle-19-300x73.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:73;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"Rectangle-19-1024x249.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:249;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"Rectangle-19-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"Rectangle-19-768x187.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:187;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:24:\"Rectangle-19-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"Rectangle-19-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:24:\"Rectangle-19-600x146.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"Rectangle-19-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:24:\"Rectangle-19-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:24:\"Rectangle-19-600x146.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"Rectangle-19-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(176, 100, '_thumbnail_id', '114'),
(177, 102, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(178, 102, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(179, 102, '_tutor_course_level', 'intermediate'),
(180, 102, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(181, 102, '_tutor_enable_qa', 'yes'),
(182, 102, '_tutor_is_public_course', 'no'),
(186, 103, '_edit_lock', '1657696497:1'),
(187, 103, '_edit_last', '1'),
(188, 103, '_regular_price', '2.300.000'),
(189, 103, '_sale_price', '2.100.000'),
(190, 103, 'total_sales', '0'),
(191, 103, '_tax_status', 'taxable'),
(192, 103, '_tax_class', ''),
(193, 103, '_manage_stock', 'no'),
(194, 103, '_backorders', 'no'),
(195, 103, '_sold_individually', 'no'),
(196, 103, '_virtual', 'no'),
(197, 103, '_downloadable', 'no'),
(198, 103, '_download_limit', '-1'),
(199, 103, '_download_expiry', '-1'),
(200, 103, '_stock', NULL),
(201, 103, '_stock_status', 'instock'),
(202, 103, '_wc_average_rating', '0'),
(203, 103, '_wc_review_count', '0'),
(204, 103, '_product_version', '3.7.0'),
(205, 103, '_price', '2.100.000'),
(206, 104, '_edit_lock', '1657696529:1'),
(207, 104, '_edit_last', '1'),
(208, 104, '_regular_price', '3000000'),
(209, 104, '_sale_price', '2800000'),
(210, 104, 'total_sales', '0'),
(211, 104, '_tax_status', 'taxable'),
(212, 104, '_tax_class', ''),
(213, 104, '_manage_stock', 'no'),
(214, 104, '_backorders', 'no'),
(215, 104, '_sold_individually', 'no'),
(216, 104, '_virtual', 'no'),
(217, 104, '_downloadable', 'no'),
(218, 104, '_download_limit', '-1'),
(219, 104, '_download_expiry', '-1'),
(220, 104, '_stock', NULL),
(221, 104, '_stock_status', 'instock'),
(222, 104, '_wc_average_rating', '0'),
(223, 104, '_wc_review_count', '0'),
(224, 104, '_product_version', '3.7.0'),
(225, 104, '_price', '2800000'),
(226, 105, '_edit_lock', '1657696686:1'),
(227, 105, '_edit_last', '1'),
(228, 105, '_regular_price', '3600000'),
(229, 105, '_sale_price', '3400000'),
(230, 105, 'total_sales', '0'),
(231, 105, '_tax_status', 'taxable'),
(232, 105, '_tax_class', ''),
(233, 105, '_manage_stock', 'no'),
(234, 105, '_backorders', 'no'),
(235, 105, '_sold_individually', 'no'),
(236, 105, '_virtual', 'no'),
(237, 105, '_downloadable', 'no'),
(238, 105, '_download_limit', '-1'),
(239, 105, '_download_expiry', '-1'),
(240, 105, '_stock', NULL),
(241, 105, '_stock_status', 'instock'),
(242, 105, '_wc_average_rating', '0'),
(243, 105, '_wc_review_count', '0'),
(244, 105, '_product_version', '3.7.0'),
(245, 105, '_price', '3400000'),
(246, 100, '_edit_lock', '1657936563:1'),
(247, 106, '_edit_lock', '1657944406:1'),
(248, 106, '_edit_last', '1'),
(249, 106, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(250, 106, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(251, 106, '_tutor_course_level', 'all_levels'),
(252, 106, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(253, 106, '_tutor_enable_qa', 'no'),
(254, 106, '_tutor_is_public_course', 'no'),
(255, 100, '_tutor_course_price_type', 'paid'),
(256, 107, '_regular_price', '3600000'),
(257, 107, 'total_sales', '0'),
(258, 107, '_tax_status', 'taxable'),
(259, 107, '_tax_class', ''),
(260, 107, '_manage_stock', 'no'),
(261, 107, '_backorders', 'no'),
(262, 107, '_sold_individually', 'yes'),
(263, 107, '_virtual', 'yes'),
(264, 107, '_downloadable', 'no'),
(265, 107, '_download_limit', '-1'),
(266, 107, '_download_expiry', '-1'),
(267, 107, '_stock', NULL),
(268, 107, '_stock_status', 'instock'),
(269, 107, '_wc_average_rating', '0'),
(270, 107, '_wc_review_count', '0'),
(271, 107, '_product_version', '3.7.0'),
(272, 107, '_price', '3600000'),
(273, 100, '_tutor_course_product_id', '107'),
(274, 107, '_tutor_product', 'yes'),
(275, 107, '_thumbnail_id', '101'),
(276, 109, '_wp_attached_file', '2022/07/training-hub-vus.jpeg'),
(277, 109, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1960;s:6:\"height\";i:796;s:4:\"file\";s:29:\"2022/07/training-hub-vus.jpeg\";s:5:\"sizes\";a:12:{s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-300x122.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:122;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:30:\"training-hub-vus-1024x416.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:416;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-768x312.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:312;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:30:\"training-hub-vus-1536x624.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:624;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-100x100.jpeg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:29:\"training-hub-vus-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-600x244.jpeg\";s:5:\"width\";i:600;s:6:\"height\";i:244;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-100x100.jpeg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-600x244.jpeg\";s:5:\"width\";i:600;s:6:\"height\";i:244;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"training-hub-vus-100x100.jpeg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(278, 110, 'hero_banner_0_image', '109'),
(279, 110, '_hero_banner_0_image', 'field_62cbe2c6d2d40'),
(280, 110, 'hero_banner_1_image', '98'),
(281, 110, '_hero_banner_1_image', 'field_62cbe2c6d2d40'),
(282, 110, 'hero_banner', '2'),
(283, 110, '_hero_banner', 'field_62cbe268d2d3f'),
(284, 111, 'hero_banner_0_image', '109'),
(285, 111, '_hero_banner_0_image', 'field_62cbe2c6d2d40'),
(286, 111, 'hero_banner_1_image', '98'),
(287, 111, '_hero_banner_1_image', 'field_62cbe2c6d2d40'),
(288, 111, 'hero_banner', '2'),
(289, 111, '_hero_banner', 'field_62cbe268d2d3f'),
(290, 106, '_tutor_course_price_type', 'free'),
(291, 112, '_edit_lock', '1657891366:1'),
(292, 112, '_edit_last', '1'),
(293, 114, '_wp_attached_file', '2022/07/Web-1920-–-1.jpg'),
(294, 114, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:888;s:6:\"height\";i:498;s:4:\"file\";s:26:\"2022/07/Web-1920-–-1.jpg\";s:5:\"sizes\";a:10:{s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-768x431.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:431;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"Web-1920-–-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-600x336.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:336;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-600x336.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:336;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"Web-1920-–-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(295, 106, 'course_poster_image', '114'),
(296, 106, '_course_poster_image', 'field_62d12341e59b1'),
(297, 115, '_wp_attached_file', '2022/07/Web-1920-–-1-1.jpg'),
(298, 115, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:888;s:6:\"height\";i:498;s:4:\"file\";s:28:\"2022/07/Web-1920-–-1-1.jpg\";s:5:\"sizes\";a:10:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-768x431.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:431;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:28:\"Web-1920-–-1-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-600x336.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:336;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-600x336.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:336;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"Web-1920-–-1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(299, 106, '_thumbnail_id', '118'),
(300, 106, 'course_banner_image', '101'),
(301, 106, '_course_banner_image', 'field_62d12341e59b1'),
(302, 31, '_tutor_course_price_type', 'free'),
(303, 31, 'course_banner_image', ''),
(304, 31, '_course_banner_image', 'field_62d12341e59b1'),
(305, 31, '_thumbnail_id', '119'),
(306, 62, '_thumbnail_id', '120'),
(307, 62, '_tutor_course_price_type', 'free'),
(308, 62, 'course_banner_image', ''),
(309, 62, '_course_banner_image', 'field_62d12341e59b1'),
(310, 100, '_edit_last', '1'),
(311, 100, 'course_banner_image', ''),
(312, 100, '_course_banner_image', 'field_62d12341e59b1'),
(313, 79, '_thumbnail_id', '117'),
(314, 79, '_tutor_course_price_type', 'free'),
(315, 79, 'course_banner_image', ''),
(316, 79, '_course_banner_image', 'field_62d12341e59b1'),
(317, 117, '_wp_attached_file', '2022/07/c-1.jpg'),
(318, 117, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:580;s:4:\"file\";s:15:\"2022/07/c-1.jpg\";s:5:\"sizes\";a:10:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"c-1-300x170.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:170;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"c-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"c-1-768x435.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:435;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:15:\"c-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"c-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"c-1-600x340.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:340;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"c-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"c-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"c-1-600x340.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:340;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"c-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(319, 118, '_wp_attached_file', '2022/07/c-2.jpg'),
(320, 118, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1231;s:6:\"height\";i:691;s:4:\"file\";s:15:\"2022/07/c-2.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"c-2-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"c-2-1024x575.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"c-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"c-2-768x431.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:431;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:15:\"c-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"c-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"c-2-600x337.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:337;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"c-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"c-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"c-2-600x337.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:337;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"c-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(321, 119, '_wp_attached_file', '2022/07/c-3.jpg'),
(322, 119, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1087;s:6:\"height\";i:610;s:4:\"file\";s:15:\"2022/07/c-3.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"c-3-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"c-3-1024x575.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:575;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"c-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"c-3-768x431.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:431;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:15:\"c-3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"c-3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"c-3-600x337.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:337;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"c-3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"c-3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"c-3-600x337.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:337;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"c-3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(323, 120, '_wp_attached_file', '2022/07/c-4.jpg'),
(324, 120, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1123;s:6:\"height\";i:633;s:4:\"file\";s:15:\"2022/07/c-4.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"c-4-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"c-4-1024x577.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:577;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"c-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"c-4-768x433.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:433;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:15:\"c-4-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"c-4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"c-4-600x338.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:338;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"c-4-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"c-4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"c-4-600x338.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:338;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"c-4-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(325, 121, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(326, 121, '_tutor_course_price_type', 'paid'),
(327, 121, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(328, 121, '_tutor_course_level', 'intermediate'),
(329, 121, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(330, 121, '_tutor_enable_qa', 'yes'),
(331, 121, '_tutor_is_public_course', 'no'),
(332, 123, '_regular_price', '1200000'),
(333, 123, 'total_sales', '0'),
(334, 123, '_tax_status', 'taxable'),
(335, 123, '_tax_class', ''),
(336, 123, '_manage_stock', 'no'),
(337, 123, '_backorders', 'no'),
(338, 123, '_sold_individually', 'yes'),
(339, 123, '_virtual', 'yes'),
(340, 123, '_downloadable', 'no'),
(341, 123, '_download_limit', '-1'),
(342, 123, '_download_expiry', '-1'),
(343, 123, '_stock', NULL),
(344, 123, '_stock_status', 'instock'),
(345, 123, '_wc_average_rating', '0'),
(346, 123, '_wc_review_count', '0'),
(347, 123, '_product_version', '3.7.0'),
(348, 123, '_price', '1200000'),
(349, 121, '_tutor_course_product_id', '123'),
(350, 123, '_tutor_product', 'yes'),
(351, 124, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(352, 124, '_tutor_course_price_type', 'free'),
(353, 124, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(354, 124, '_tutor_course_level', 'intermediate'),
(355, 124, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(356, 124, '_tutor_enable_qa', 'yes'),
(357, 124, '_tutor_is_public_course', 'no'),
(358, 125, '_edit_lock', '1658334427:1'),
(359, 128, '_edit_lock', '1658905895:1'),
(360, 7, '_edit_lock', '1658909668:1'),
(361, 130, '_edit_lock', '1658932845:1'),
(362, 130, '_edit_last', '1'),
(363, 132, '_wp_attached_file', '2022/07/home_sub_banner.png'),
(364, 132, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2000;s:6:\"height\";i:581;s:4:\"file\";s:27:\"2022/07/home_sub_banner.png\";s:5:\"sizes\";a:12:{s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"home_sub_banner-300x87.png\";s:5:\"width\";i:300;s:6:\"height\";i:87;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"home_sub_banner-1024x297.png\";s:5:\"width\";i:1024;s:6:\"height\";i:297;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"home_sub_banner-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"home_sub_banner-768x223.png\";s:5:\"width\";i:768;s:6:\"height\";i:223;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:28:\"home_sub_banner-1536x446.png\";s:5:\"width\";i:1536;s:6:\"height\";i:446;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:27:\"home_sub_banner-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:27:\"home_sub_banner-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:27:\"home_sub_banner-600x174.png\";s:5:\"width\";i:600;s:6:\"height\";i:174;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:27:\"home_sub_banner-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:27:\"home_sub_banner-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:27:\"home_sub_banner-600x174.png\";s:5:\"width\";i:600;s:6:\"height\";i:174;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:27:\"home_sub_banner-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(365, 93, 'image', '132'),
(366, 93, '_image', 'field_62e0ff4d87289'),
(367, 133, 'hero_banner_0_image', '109'),
(368, 133, '_hero_banner_0_image', 'field_62cbe2c6d2d40'),
(369, 133, 'hero_banner_1_image', '98'),
(370, 133, '_hero_banner_1_image', 'field_62cbe2c6d2d40'),
(371, 133, 'hero_banner', '2'),
(372, 133, '_hero_banner', 'field_62cbe268d2d3f'),
(373, 133, 'image', '132'),
(374, 133, '_image', 'field_62e0ff4d87289'),
(375, 93, 'home_sub_banner', '132'),
(376, 93, '_home_sub_banner', 'field_62e0ff4d87289'),
(377, 134, 'hero_banner_0_image', '109'),
(378, 134, '_hero_banner_0_image', 'field_62cbe2c6d2d40'),
(379, 134, 'hero_banner_1_image', '98'),
(380, 134, '_hero_banner_1_image', 'field_62cbe2c6d2d40'),
(381, 134, 'hero_banner', '2'),
(382, 134, '_hero_banner', 'field_62cbe268d2d3f'),
(383, 134, 'image', '132'),
(384, 134, '_image', 'field_62e0ff4d87289'),
(385, 134, 'home_sub_banner', '132'),
(386, 134, '_home_sub_banner', 'field_62e0ff4d87289'),
(388, 136, '_edit_lock', '1658931849:1'),
(389, 136, '_thumbnail_id', '114'),
(390, 136, '_edit_last', '1'),
(391, 136, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(392, 136, '_tutor_course_price_type', 'free'),
(393, 136, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(394, 136, '_tutor_course_level', 'intermediate'),
(395, 136, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(396, 136, '_tutor_enable_qa', 'yes'),
(397, 136, '_tutor_is_public_course', 'no'),
(398, 136, 'course_banner_image', ''),
(399, 136, '_course_banner_image', 'field_62d12341e59b1'),
(412, 138, '_edit_lock', '1658935089:1'),
(413, 138, '_thumbnail_id', '120'),
(414, 138, '_edit_last', '1'),
(415, 138, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(416, 138, '_tutor_course_price_type', 'free'),
(417, 138, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(418, 138, '_tutor_course_level', 'intermediate'),
(419, 138, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(420, 138, '_tutor_enable_qa', 'yes'),
(421, 138, '_tutor_is_public_course', 'no'),
(422, 138, 'course_banner_image', ''),
(423, 138, '_course_banner_image', 'field_62d12341e59b1'),
(424, 141, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(425, 141, '_tutor_course_price_type', 'free'),
(426, 141, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(427, 141, '_tutor_course_level', 'intermediate'),
(428, 141, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(429, 141, '_tutor_enable_qa', 'yes'),
(430, 141, '_tutor_is_public_course', 'no'),
(431, 141, '_thumbnail_id', '119'),
(432, 142, '_regular_price', '2300000'),
(433, 142, 'total_sales', '0'),
(434, 142, '_tax_status', 'taxable'),
(435, 142, '_tax_class', ''),
(436, 142, '_manage_stock', 'no'),
(437, 142, '_backorders', 'no'),
(438, 142, '_sold_individually', 'yes'),
(439, 142, '_virtual', 'yes'),
(440, 142, '_downloadable', 'no'),
(441, 142, '_download_limit', '-1'),
(442, 142, '_download_expiry', '-1'),
(443, 142, '_stock', NULL),
(444, 142, '_stock_status', 'instock'),
(445, 142, '_wc_average_rating', '0'),
(446, 142, '_wc_review_count', '0'),
(447, 142, '_product_version', '3.7.0'),
(448, 142, '_price', '2300000'),
(449, 141, '_tutor_course_product_id', '142'),
(450, 142, '_tutor_product', 'yes'),
(451, 142, '_thumbnail_id', '119'),
(452, 141, '_wp_old_slug', 'auto-draft'),
(453, 141, '_wp_old_slug', 'auto-draft-2'),
(454, 145, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(455, 145, '_tutor_course_price_type', 'free'),
(456, 145, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(457, 145, '_tutor_course_level', 'intermediate'),
(458, 145, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(459, 145, '_tutor_enable_qa', 'yes'),
(460, 145, '_tutor_is_public_course', 'no'),
(461, 145, '_edit_lock', '1659063112:1'),
(463, 147, '_regular_price', '3600000'),
(464, 147, 'total_sales', '0'),
(465, 147, '_tax_status', 'taxable'),
(466, 147, '_tax_class', ''),
(467, 147, '_manage_stock', 'no'),
(468, 147, '_backorders', 'no'),
(469, 147, '_sold_individually', 'yes'),
(470, 147, '_virtual', 'yes'),
(471, 147, '_downloadable', 'no'),
(472, 147, '_download_limit', '-1'),
(473, 147, '_download_expiry', '-1'),
(474, 147, '_stock', NULL),
(475, 147, '_stock_status', 'instock'),
(476, 147, '_wc_average_rating', '0'),
(477, 147, '_wc_review_count', '0'),
(478, 147, '_product_version', '3.7.0'),
(479, 147, '_price', '3600000'),
(481, 147, '_tutor_product', 'yes'),
(482, 147, '_thumbnail_id', '117'),
(483, 148, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(484, 148, '_tutor_course_price_type', 'free'),
(485, 148, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(486, 148, '_tutor_course_level', 'intermediate'),
(487, 148, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(488, 148, '_tutor_enable_qa', 'yes'),
(489, 148, '_tutor_is_public_course', 'no'),
(490, 148, '_tutor_course_type', 'forexternal'),
(491, 150, '_wp_trash_meta_status', 'publish'),
(492, 150, '_wp_trash_meta_time', '1659457753'),
(493, 79, '_tutor_course_type', 'forexternal'),
(494, 158, '_wp_trash_meta_status', 'publish'),
(495, 158, '_wp_trash_meta_time', '1659490534'),
(496, 62, '_tutor_course_type', 'forexternal'),
(497, 161, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(498, 161, '_tutor_course_price_type', 'free'),
(499, 161, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(500, 161, '_tutor_course_level', 'intermediate'),
(501, 161, '_tutor_course_type', 'forinternal'),
(502, 161, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(503, 161, '_tutor_enable_qa', 'yes'),
(504, 161, '_tutor_is_public_course', 'no'),
(505, 162, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(506, 162, '_tutor_course_price_type', 'free'),
(507, 162, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(508, 162, '_tutor_course_level', 'all_levels'),
(509, 162, '_tutor_course_type', 'forinternal'),
(510, 162, '_video', 'a:8:{s:6:\"source\";s:8:\"embedded\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:43:\"https://www.youtube.com/watch?v=astISOttCQ0\";}'),
(511, 162, '_tutor_enable_qa', 'no'),
(512, 162, '_tutor_is_public_course', 'no'),
(513, 106, '_tutor_course_type', 'forinternal'),
(514, 138, '_tutor_course_type', 'forexternal'),
(515, 163, '_wp_attached_file', '2022/08/beach-blurred-wallpaper-preview.jpg'),
(516, 163, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:728;s:6:\"height\";i:410;s:4:\"file\";s:43:\"2022/08/beach-blurred-wallpaper-preview.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-600x338.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:338;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-600x338.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:338;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:43:\"beach-blurred-wallpaper-preview-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(517, 162, '_thumbnail_id', '163'),
(518, 162, '_tutor_course_material_includes', '- Material 1\r\n- Course book 1\r\n- A cup of tea'),
(520, 162, '_tutor_course_requirements', 'Library pass'),
(522, 167, '_wp_attached_file', '2022/08/ACTIVITY-OF-THE-WEEK-11_2.7.2021.pdf'),
(523, 168, '_tutor_attachments', 'a:1:{i:0;s:3:\"167\";}'),
(524, 162, '_wp_old_slug', 'internal-test-1'),
(525, 169, '_regular_price', '5000000'),
(526, 169, 'total_sales', '0'),
(527, 169, '_tax_status', 'taxable'),
(528, 169, '_tax_class', ''),
(529, 169, '_manage_stock', 'no'),
(530, 169, '_backorders', 'no'),
(531, 169, '_sold_individually', 'yes'),
(532, 169, '_virtual', 'yes'),
(533, 169, '_downloadable', 'no'),
(534, 169, '_download_limit', '-1'),
(535, 169, '_download_expiry', '-1'),
(536, 169, '_stock', NULL),
(537, 169, '_stock_status', 'instock'),
(538, 169, '_wc_average_rating', '0'),
(539, 169, '_wc_review_count', '0'),
(540, 169, '_product_version', '3.7.0'),
(541, 169, '_price', '5000000'),
(542, 162, '_tutor_course_product_id', '169'),
(543, 169, '_tutor_product', 'yes'),
(544, 169, '_thumbnail_id', '163'),
(545, 170, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(546, 170, '_tutor_course_price_type', 'free'),
(547, 170, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(548, 170, '_tutor_course_level', 'all_levels'),
(549, 170, '_tutor_course_type', 'forinternal'),
(550, 170, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(551, 170, '_tutor_enable_qa', 'yes'),
(552, 170, '_tutor_is_public_course', 'no'),
(553, 171, '_wp_attached_file', '2022/08/Arte_Surfside-LXCollection-Background.jpg'),
(554, 171, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1080;s:4:\"file\";s:49:\"2022/08/Arte_Surfside-LXCollection-Background.jpg\";s:5:\"sizes\";a:12:{s:6:\"medium\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:50:\"Arte_Surfside-LXCollection-Background-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:50:\"Arte_Surfside-LXCollection-Background-1536x864.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:864;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"site-thumbnail-avatar\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-600x338.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:338;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-600x338.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:338;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:49:\"Arte_Surfside-LXCollection-Background-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(555, 170, '_thumbnail_id', '171'),
(556, 173, '_tutor_course_id_for_assignments', '170'),
(557, 173, 'assignment_option', 'a:5:{s:13:\"time_duration\";a:2:{s:5:\"value\";s:1:\"0\";s:4:\"time\";s:5:\"weeks\";}s:10:\"total_mark\";s:2:\"10\";s:9:\"pass_mark\";s:1:\"5\";s:18:\"upload_files_limit\";s:1:\"1\";s:22:\"upload_file_size_limit\";s:1:\"2\";}'),
(558, 173, '_tutor_assignment_total_mark', '10'),
(559, 173, '_tutor_assignment_pass_mark', '5'),
(560, 173, '_tutor_assignment_attachments', 'a:1:{i:0;s:2:\"98\";}'),
(561, 174, 'tutor_quiz_option', 'a:9:{s:10:\"time_limit\";a:2:{s:10:\"time_value\";s:1:\"0\";s:9:\"time_type\";s:7:\"minutes\";}s:13:\"feedback_mode\";s:5:\"retry\";s:16:\"attempts_allowed\";s:1:\"0\";s:13:\"passing_grade\";s:2:\"80\";s:24:\"max_questions_for_answer\";s:2:\"10\";s:20:\"question_layout_view\";s:0:\"\";s:15:\"questions_order\";s:4:\"rand\";s:29:\"short_answer_characters_limit\";s:3:\"200\";s:34:\"open_ended_answer_characters_limit\";s:3:\"500\";}'),
(562, 175, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(563, 175, '_tutor_course_price_type', 'free'),
(564, 175, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(565, 175, '_tutor_course_level', 'all_levels'),
(566, 175, '_video', 'a:8:{s:6:\"source\";s:8:\"embedded\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:43:\"https://www.youtube.com/watch?v=astISOttCQ0\";}'),
(567, 175, '_tutor_enable_qa', 'no'),
(568, 175, '_tutor_is_public_course', 'no'),
(569, 175, '_tutor_course_type', 'forinternal'),
(570, 175, '_tutor_course_requirements', 'Library pass'),
(571, 175, '_tutor_course_material_includes', '- Material 1\r\n- Course book 1\r\n- A cup of tea'),
(572, 179, '_tutor_course_code', '00179'),
(573, 179, '_tutor_course_settings', 'a:2:{s:16:\"maximum_students\";s:1:\"0\";s:17:\"enrollment_expiry\";s:1:\"0\";}'),
(574, 179, '_tutor_course_price_type', 'free'),
(575, 179, '_course_duration', 'a:3:{s:5:\"hours\";s:2:\"00\";s:7:\"minutes\";s:2:\"00\";s:7:\"seconds\";s:2:\"00\";}'),
(576, 179, '_tutor_course_level', 'intermediate'),
(577, 179, '_video', 'a:8:{s:6:\"source\";s:2:\"-1\";s:15:\"source_video_id\";s:0:\"\";s:6:\"poster\";s:0:\"\";s:19:\"source_external_url\";s:0:\"\";s:16:\"source_shortcode\";s:0:\"\";s:14:\"source_youtube\";s:0:\"\";s:12:\"source_vimeo\";s:0:\"\";s:15:\"source_embedded\";s:0:\"\";}'),
(578, 179, '_tutor_enable_qa', 'yes'),
(579, 179, '_tutor_is_public_course', 'no'),
(580, 179, '_tutor_course_children', '138 141'),
(581, 138, '_tutor_course_code', '00179'),
(582, 141, '_wp_old_slug', 'course-100'),
(583, 141, '_tutor_course_code', '00179');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint UNSIGNED NOT NULL,
  `post_author` bigint UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-07-01 02:30:09', '2022-07-01 02:30:09', '<!-- wp:paragraph -->\n<p>Cảm ơn vì đã sử dụng WordPress. Đây là bài viết đầu tiên của bạn. Sửa hoặc xóa nó, và bắt đầu bài viết của bạn nhé!</p>\n<!-- /wp:paragraph -->', 'Chào tất cả mọi người!', '', 'publish', 'open', 'open', '', 'chao-moi-nguoi', '', '', '2022-07-01 02:30:09', '2022-07-01 02:30:09', '', 0, 'https://traininghub-uat.vus.edu.vn/?p=1', 0, 'post', '', 1),
(2, 1, '2022-07-01 02:30:09', '2022-07-01 02:30:09', '<!-- wp:paragraph -->\n<p>Đây là trang mẫu. Nó khác với bài viết bởi vì nó thường cố định và hiển thị trong menu của bạn. Nhiều người bắt đầu với trang Giới thiệu nơi bạn chia sẻ thông tin cho những ai ghé thăm. Nó có thể bắt đầu như thế này:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Chào bạn! Tôi là một người bán hàng, và đây là website của tôi. Tôi sống ở Hà Nội, có một gia đình nhỏ, và tôi thấy cách sử dụng WordPress rất thú vị.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... hoặc cái gì đó như thế này:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Công ty chúng tôi được thành lập năm 2010, và cung cấp dịch vụ chất lượng cho rất nhiều sự kiện tại khắp Việt Nam. Với văn phòng đặt tại Hà Nội, TP. Hồ Chí Minh cùng hơn 40 nhân sự, chúng tôi là nơi nhiều đối tác tin tưởng giao cho tổ chức các sự kiện lớn.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Là một người dùng WordPress mới, bạn nên ghé thăm <a href=\"https://traininghub-uat.vus.edu.vn/wp-admin/\">bảng tin</a> để xóa trang này và tạo trang mới cho nội dung của chính bạn. Chúc bạn vui vẻ!</p>\n<!-- /wp:paragraph -->', 'Trang Mẫu', '', 'publish', 'closed', 'open', '', 'Trang mẫu', '', '', '2022-07-01 02:30:09', '2022-07-01 02:30:09', '', 0, 'https://traininghub-uat.vus.edu.vn/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-07-01 02:30:09', '2022-07-01 02:30:09', '<!-- wp:heading --><h2>Chúng tôi là ai</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Địa chỉ website là: https://traininghub-uat.vus.edu.vn.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Thông tin cá nhân nào bị thu thập và tại sao thu thập</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Bình luận</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Khi khách truy cập để lại bình luận trên trang web, chúng tôi thu thập dữ liệu được hiển thị trong biểu mẫu bình luận và cũng là địa chỉ IP của người truy cập và chuỗi user agent của người dùng trình duyệt để giúp phát hiện spam</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Một chuỗi ẩn danh được tạo từ địa chỉ email của bạn (còn được gọi là hash) có thể được cung cấp cho dịch vụ Gravatar để xem bạn có đang sử dụng nó hay không. Chính sách bảo mật của dịch vụ Gravatar có tại đây: https://automattic.com/privacy/. Sau khi chấp nhận bình luận của bạn, ảnh tiểu sử của bạn được hiển thị công khai trong ngữ cảnh bình luận của bạn.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Thư viện</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Nếu bạn tải hình ảnh lên trang web, bạn nên tránh tải lên hình ảnh có dữ liệu vị trí được nhúng (EXIF GPS) đi kèm. Khách truy cập vào trang web có thể tải xuống và giải nén bất kỳ dữ liệu vị trí nào từ hình ảnh trên trang web.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Thông tin liên hệ</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Nếu bạn viết bình luận trong website, bạn có thể cung cấp cần nhập tên, email địa chỉ website trong cookie. Các thông tin này nhằm giúp bạn không cần nhập thông tin nhiều lần khi viết bình luận khác. Cookie này sẽ được lưu giữ trong một năm.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Nếu bạn vào trang đăng nhập, chúng tôi sẽ thiết lập một cookie tạm thời để xác định nếu trình duyệt cho phép sử dụng cookie. Cookie này không bao gồm thông tin cá nhân và sẽ được gỡ bỏ khi bạn đóng trình duyệt.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Khi bạn đăng nhập, chúng tôi sẽ thiết lập một vài cookie để lưu thông tin đăng nhập và lựa chọn hiển thị. Thông tin đăng nhập gần nhất lưu trong hai ngày, và lựa chọn hiển thị gần nhất lưu trong một năm. Nếu bạn chọn &quot;Nhớ tôi&quot;, thông tin đăng nhập sẽ được lưu trong hai tuần. Nếu bạn thoát tài khoản, thông tin cookie đăng nhập sẽ bị xoá.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Nếu bạn sửa hoặc công bố bài viết, một bản cookie bổ sung sẽ được lưu trong trình duyệt. Cookie này không chứa thông tin cá nhân và chỉ đơn giản bao gồm ID của bài viết bạn đã sửa. Nó tự động hết hạn sau 1 ngày.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Nội dung nhúng từ website khác</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Các bài viết trên trang web này có thể bao gồm nội dung được nhúng (ví dụ: video, hình ảnh, bài viết, v.v.). Nội dung được nhúng từ các trang web khác hoạt động theo cùng một cách chính xác như khi khách truy cập đã truy cập trang web khác.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Những website này có thể thu thập dữ liệu về bạn, sử dụng cookie, nhúng các trình theo dõi của bên thứ ba và giám sát tương tác của bạn với nội dung được nhúng đó, bao gồm theo dõi tương tác của bạn với nội dung được nhúng nếu bạn có tài khoản và đã đăng nhập vào trang web đó.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Phân tích</h3><!-- /wp:heading --><!-- wp:heading --><h2>Chúng tôi chia sẻ dữ liệu của bạn với ai</h2><!-- /wp:heading --><!-- wp:heading --><h2>Dữ liệu của bạn tồn tại bao lâu</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Nếu bạn để lại bình luận, bình luận và siêu dữ liệu của nó sẽ được giữ lại vô thời hạn. Điều này là để chúng tôi có thể tự động nhận ra và chấp nhận bất kỳ bình luận nào thay vì giữ chúng trong khu vực đợi kiểm duyệt.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Đối với người dùng đăng ký trên trang web của chúng tôi (nếu có), chúng tôi cũng lưu trữ thông tin cá nhân mà họ cung cấp trong hồ sơ người dùng của họ. Tất cả người dùng có thể xem, chỉnh sửa hoặc xóa thông tin cá nhân của họ bất kỳ lúc nào (ngoại trừ họ không thể thay đổi tên người dùng của họ). Quản trị viên trang web cũng có thể xem và chỉnh sửa thông tin đó.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Các quyền nào của bạn với dữ liệu của mình</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Nếu bạn có tài khoản trên trang web này hoặc đã để lại nhận xét, bạn có thể yêu cầu nhận tệp xuất dữ liệu cá nhân mà chúng tôi lưu giữ về bạn, bao gồm mọi dữ liệu bạn đã cung cấp cho chúng tôi. Bạn cũng có thể yêu cầu chúng tôi xóa mọi dữ liệu cá nhân mà chúng tôi lưu giữ về bạn. Điều này không bao gồm bất kỳ dữ liệu nào chúng tôi có nghĩa vụ giữ cho các mục đích hành chính, pháp lý hoặc bảo mật.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Các dữ liệu của bạn được gửi tới đâu</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Các bình luận của khách (không phải là thành viên) có thể được kiểm tra thông qua dịch vụ tự động phát hiện spam.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Thông tin liên hệ của bạn</h2><!-- /wp:heading --><!-- wp:heading --><h2>Thông tin bổ sung</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cách chúng tôi bảo vệ dữ liệu của bạn</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Các quá trình tiết lộ dữ liệu mà chúng tôi thực hiện</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Những bên thứ ba chúng tôi nhận dữ liệu từ đó</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Việc quyết định và/hoặc thu thập thông tin tự động mà chúng tôi áp dụng với dữ liệu người dùng</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Các yêu cầu công bố thông tin được quản lý</h3><!-- /wp:heading -->', 'Chính sách bảo mật', '', 'draft', 'closed', 'open', '', 'chinh-sach-bao-mat', '', '', '2022-07-01 02:30:09', '2022-07-01 02:30:09', '', 0, 'https://traininghub-uat.vus.edu.vn/?page_id=3', 0, 'page', '', 0),
(6, 1, '2022-07-01 02:57:29', '2022-07-01 02:57:29', '', 'Dashboard', '', 'publish', 'closed', 'closed', '', 'dashboard', '', '', '2022-07-01 02:57:29', '2022-07-01 02:57:29', '', 0, 'https://traininghub-uat.vus.edu.vn/?page_id=6', 0, 'page', '', 0),
(7, 1, '2022-07-01 02:57:29', '2022-07-01 02:57:29', '[tutor_student_registration_form]', 'Student Registration', '', 'publish', 'closed', 'closed', '', 'student-registration', '', '', '2022-07-01 02:57:29', '2022-07-01 02:57:29', '', 0, 'https://traininghub-uat.vus.edu.vn/?page_id=7', 0, 'page', '', 0),
(8, 1, '2022-07-01 02:57:29', '2022-07-01 02:57:29', '[tutor_instructor_registration_form]', 'Instructor Registration', '', 'publish', 'closed', 'closed', '', 'instructor-registration', '', '', '2022-07-01 02:57:29', '2022-07-01 02:57:29', '', 0, 'https://traininghub-uat.vus.edu.vn/?page_id=8', 0, 'page', '', 0),
(11, 1, '2022-07-01 07:32:32', '2022-07-01 07:32:32', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2022-07-01 07:32:32', '2022-07-01 07:32:32', '', 0, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(12, 1, '2022-07-01 07:33:28', '2022-07-01 07:33:28', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2022-07-01 07:33:28', '2022-07-01 07:33:28', '', 0, 'https://traininghub-uat.vus.edu.vn/shop/', 0, 'page', '', 0),
(13, 1, '2022-07-01 07:33:28', '2022-07-01 07:33:28', '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2022-07-01 07:33:28', '2022-07-01 07:33:28', '', 0, 'https://traininghub-uat.vus.edu.vn/cart/', 0, 'page', '', 0),
(14, 1, '2022-07-01 07:33:28', '2022-07-01 07:33:28', '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2022-07-01 07:33:28', '2022-07-01 07:33:28', '', 0, 'https://traininghub-uat.vus.edu.vn/checkout/', 0, 'page', '', 0),
(15, 1, '2022-07-01 07:33:28', '2022-07-01 07:33:28', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2022-07-01 07:33:28', '2022-07-01 07:33:28', '', 0, 'https://traininghub-uat.vus.edu.vn/my-account/', 0, 'page', '', 0),
(31, 1, '2022-07-01 08:55:59', '2022-07-01 08:55:59', '', 'Course 1', '', 'publish', 'closed', 'closed', '', 'course-1', '', '', '2022-08-03 13:37:20', '2022-08-03 13:37:20', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=31', 0, 'courses', '', 0),
(32, 1, '2022-07-01 09:38:00', '2022-07-01 09:38:00', '', 'Course Enrolled &ndash; 1 July, 2022 @ 9:38 am', '', 'completed', 'closed', 'closed', '', 'course-enrolled-1-july-2022-938-am', '', '', '2022-07-01 09:38:00', '2022-07-01 09:38:00', '', 31, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-1-july-2022-938-am/', 0, 'tutor_enrolled', '', 0),
(62, 1, '2022-07-05 07:37:07', '2022-07-05 07:37:07', '', 'Course 2', '', 'publish', 'closed', 'closed', '', 'course-2', '', '', '2022-08-05 09:16:48', '2022-08-05 09:16:48', '', 31, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=62', 0, 'courses', '', 0),
(79, 2, '2022-07-05 09:55:31', '2022-07-05 09:55:31', '', 'Course 3', '', 'publish', 'closed', 'closed', '', 'course-3', '', '', '2022-08-02 16:32:05', '2022-08-02 16:32:05', '', 148, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=79', 0, 'courses', '', 0),
(81, 1, '2022-07-06 02:51:29', '2022-07-06 02:51:29', '', 'Your learning', '', 'publish', 'closed', 'closed', '', 'your-learning', '', '', '2022-07-06 03:00:48', '2022-07-06 03:00:48', '', 0, 'https://traininghub-uat.vus.edu.vn/?p=81', 1, 'nav_menu_item', '', 0),
(82, 1, '2022-07-06 03:00:48', '2022-07-06 03:00:48', '', 'Explore courses', '', 'publish', 'closed', 'closed', '', 'explore-courses', '', '', '2022-07-06 03:00:48', '2022-07-06 03:00:48', '', 0, 'https://traininghub-uat.vus.edu.vn/?p=82', 2, 'nav_menu_item', '', 0),
(83, 1, '2022-07-06 03:02:23', '2022-07-06 03:02:23', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2022-07-06 03:02:23', '2022-07-06 03:02:23', '', 0, 'https://traininghub-uat.vus.edu.vn/?p=83', 1, 'nav_menu_item', '', 0),
(84, 1, '2022-07-06 03:02:23', '2022-07-06 03:02:23', '', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2022-07-06 03:02:23', '2022-07-06 03:02:23', '', 0, 'https://traininghub-uat.vus.edu.vn/?p=84', 2, 'nav_menu_item', '', 0),
(85, 1, '2022-07-06 03:02:23', '2022-07-06 03:02:23', '', 'Terms of Service', '', 'publish', 'closed', 'closed', '', 'terms-of-service', '', '', '2022-07-06 03:02:23', '2022-07-06 03:02:23', '', 0, 'https://traininghub-uat.vus.edu.vn/?p=85', 3, 'nav_menu_item', '', 0),
(86, 1, '2022-07-06 03:02:23', '2022-07-06 03:02:23', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2022-07-06 03:02:23', '2022-07-06 03:02:23', '', 0, 'https://traininghub-uat.vus.edu.vn/?p=86', 4, 'nav_menu_item', '', 0),
(87, 1, '2022-07-06 14:49:41', '2022-07-06 14:49:41', '', 'Course Enrolled &ndash; 6 July, 2022 @ 2:49 pm', '', 'completed', 'closed', 'closed', '', 'course-enrolled-6-july-2022-249-pm', '', '', '2022-07-06 14:49:41', '2022-07-06 14:49:41', '', 62, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-6-july-2022-249-pm/', 0, 'tutor_enrolled', '', 0),
(88, 3, '2022-07-06 15:23:41', '2022-07-06 15:23:41', '', 'Course Enrolled &ndash; 6 July, 2022 @ 3:23 pm', '', 'completed', 'closed', 'closed', '', 'course-enrolled-6-july-2022-323-pm', '', '', '2022-07-06 15:23:41', '2022-07-06 15:23:41', '', 62, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-6-july-2022-323-pm/', 0, 'tutor_enrolled', '', 0),
(90, 1, '2022-07-11 08:29:54', '2022-07-11 08:29:54', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2022-07-11 08:30:28', '2022-07-11 08:30:28', '', 0, 'https://traininghub-uat.vus.edu.vn/?p=90', 0, 'post', '', 0),
(91, 1, '2022-07-11 08:29:54', '2022-07-11 08:29:54', '', 'Trang chủ', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2022-07-11 08:29:54', '2022-07-11 08:29:54', '', 90, 'https://traininghub-uat.vus.edu.vn/90-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2022-07-11 08:30:16', '2022-07-11 08:30:16', '', 'Home', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2022-07-11 08:30:16', '2022-07-11 08:30:16', '', 90, 'https://traininghub-uat.vus.edu.vn/90-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2022-07-11 08:34:34', '2022-07-11 08:34:34', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-07-27 09:08:45', '2022-07-27 09:08:45', '', 0, 'https://traininghub-uat.vus.edu.vn/?page_id=93', 0, 'page', '', 0),
(94, 1, '2022-07-11 08:34:34', '2022-07-11 08:34:34', '', 'Home', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2022-07-11 08:34:34', '2022-07-11 08:34:34', '', 93, 'https://traininghub-uat.vus.edu.vn/93-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2022-07-11 08:44:17', '2022-07-11 08:44:17', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"93\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Home sliders', 'home-sliders', 'publish', 'closed', 'closed', '', 'group_62cbe25c03d77', '', '', '2022-07-11 08:44:17', '2022-07-11 08:44:17', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=acf-field-group&#038;p=95', 1, 'acf-field-group', '', 0),
(96, 1, '2022-07-11 08:44:17', '2022-07-11 08:44:17', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Hero banner', 'hero_banner', 'publish', 'closed', 'closed', '', 'field_62cbe268d2d3f', '', '', '2022-07-11 08:44:17', '2022-07-11 08:44:17', '', 95, 'https://traininghub-uat.vus.edu.vn/?post_type=acf-field&p=96', 0, 'acf-field', '', 0),
(97, 1, '2022-07-11 08:44:17', '2022-07-11 08:44:17', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"1536x1536\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_62cbe2c6d2d40', '', '', '2022-07-11 08:44:17', '2022-07-11 08:44:17', '', 96, 'https://traininghub-uat.vus.edu.vn/?post_type=acf-field&p=97', 0, 'acf-field', '', 0),
(98, 1, '2022-07-11 08:50:10', '2022-07-11 08:50:10', '', 'hero-banner-1', '', 'inherit', 'open', 'closed', '', 'hero-banner-1', '', '', '2022-07-11 08:50:10', '2022-07-11 08:50:10', '', 93, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/hero-banner-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2022-07-11 08:50:47', '2022-07-11 08:50:47', '', 'Home', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2022-07-11 08:50:47', '2022-07-11 08:50:47', '', 93, 'https://traininghub-uat.vus.edu.vn/93-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2022-07-13 03:36:18', '2022-07-13 03:36:18', '...', 'Course title 10', '', 'publish', 'closed', 'closed', '', 'course-title-10', '', '', '2022-08-05 09:17:31', '2022-08-05 09:17:31', '', 62, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=100', 0, 'courses', '', 0),
(101, 1, '2022-07-13 03:35:47', '2022-07-13 03:35:47', '', 'Rectangle 19', '', 'inherit', 'open', 'closed', '', 'rectangle-19', '', '', '2022-07-15 09:03:40', '2022-07-15 09:03:40', '', 106, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/Rectangle-19.jpg', 0, 'attachment', 'image/jpeg', 0),
(102, 1, '2022-07-13 06:58:52', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'draft', 'closed', 'closed', '', 'auto-draft', '', '', '2022-07-13 06:58:52', '2022-07-13 06:58:52', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=102', 0, 'courses', '', 0),
(103, 1, '2022-07-13 07:14:48', '2022-07-13 07:14:48', '', 'Course 1', '', 'publish', 'open', 'closed', '', 'course-1', '', '', '2022-07-13 07:17:10', '2022-07-13 07:17:10', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=product&#038;p=103', 0, 'product', '', 0),
(104, 1, '2022-07-13 07:17:42', '2022-07-13 07:17:42', '', 'Course 2', '', 'publish', 'open', 'closed', '', 'course-2', '', '', '2022-07-13 07:17:43', '2022-07-13 07:17:43', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=product&#038;p=104', 0, 'product', '', 0),
(105, 1, '2022-07-13 07:18:17', '2022-07-13 07:18:17', '', 'Course 3', '', 'publish', 'open', 'closed', '', 'course-3', '', '', '2022-07-13 07:18:17', '2022-07-13 07:18:17', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=product&#038;p=105', 0, 'product', '', 0),
(106, 1, '2022-07-13 07:22:31', '2022-07-13 07:22:31', '', 'Course 11', '', 'publish', 'closed', 'closed', '', 'course-11', '', '', '2022-08-05 09:18:31', '2022-08-05 09:18:31', '', 62, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=106', 0, 'courses', '', 0),
(107, 1, '2022-07-13 07:45:08', '2022-07-13 07:45:08', '', 'Course title 10', '', 'publish', 'open', 'closed', '', 'course-title-10', '', '', '2022-08-05 09:17:31', '2022-08-05 09:17:31', '', 0, 'https://traininghub-uat.vus.edu.vn/product/course-title-10/', 0, 'product', '', 0),
(109, 1, '2022-07-14 01:49:50', '2022-07-14 01:49:50', '', 'training-hub-vus', '', 'inherit', 'open', 'closed', '', 'training-hub-vus', '', '', '2022-07-14 01:49:50', '2022-07-14 01:49:50', '', 93, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/training-hub-vus.jpeg', 0, 'attachment', 'image/jpeg', 0),
(110, 1, '2022-07-14 01:50:05', '2022-07-14 01:50:05', '', 'Home', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2022-07-14 01:50:05', '2022-07-14 01:50:05', '', 93, 'https://traininghub-uat.vus.edu.vn/93-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2022-07-14 01:50:44', '2022-07-14 01:50:44', '', 'Home', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2022-07-14 01:50:44', '2022-07-14 01:50:44', '', 93, 'https://traininghub-uat.vus.edu.vn/93-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2022-07-15 08:21:28', '2022-07-15 08:21:28', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"courses\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:8:\"seamless\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Course Banner Detail Page', 'course-banner-detail-page', 'publish', 'closed', 'closed', '', 'group_62d1232ebf50a', '', '', '2022-07-15 09:01:29', '2022-07-15 09:01:29', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=acf-field-group&#038;p=112', 0, 'acf-field-group', '', 0),
(113, 1, '2022-07-15 08:21:28', '2022-07-15 08:21:28', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:5:\"large\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";i:320;s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";i:1920;s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Course banner image', 'course_banner_image', 'publish', 'closed', 'closed', '', 'field_62d12341e59b1', '', '', '2022-07-15 08:38:23', '2022-07-15 08:38:23', '', 112, 'https://traininghub-uat.vus.edu.vn/?post_type=acf-field&#038;p=113', 0, 'acf-field', '', 0),
(114, 1, '2022-07-15 08:27:13', '2022-07-15 08:27:13', '', 'Web 1920 – 1', '', 'inherit', 'open', 'closed', '', 'web-1920-1', '', '', '2022-07-15 08:27:13', '2022-07-15 08:27:13', '', 106, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/Web-1920-–-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(115, 1, '2022-07-15 08:34:26', '2022-07-15 08:34:26', '', 'Web 1920 – 1', '', 'inherit', 'open', 'closed', '', 'web-1920-1-2', '', '', '2022-07-15 08:34:26', '2022-07-15 08:34:26', '', 106, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/Web-1920-–-1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(116, 1, '2022-07-16 01:51:09', '2022-07-16 01:51:09', '...', 'Course title 10', '', 'inherit', 'closed', 'closed', '', '100-autosave-v1', '', '', '2022-07-16 01:51:09', '2022-07-16 01:51:09', '', 100, 'https://traininghub-uat.vus.edu.vn/100-autosave-v1/', 0, 'revision', '', 0),
(117, 1, '2022-07-16 01:56:34', '2022-07-16 01:56:34', '', 'c-1', '', 'inherit', 'open', 'closed', '', 'c-1', '', '', '2022-07-16 01:56:34', '2022-07-16 01:56:34', '', 0, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/c-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(118, 1, '2022-07-16 01:56:37', '2022-07-16 01:56:37', '', 'c-2', '', 'inherit', 'open', 'closed', '', 'c-2', '', '', '2022-07-16 01:56:37', '2022-07-16 01:56:37', '', 0, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/c-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(119, 1, '2022-07-16 01:56:40', '2022-07-16 01:56:40', '', 'c-3', '', 'inherit', 'open', 'closed', '', 'c-3', '', '', '2022-07-16 01:56:40', '2022-07-16 01:56:40', '', 0, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/c-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(120, 1, '2022-07-16 01:56:43', '2022-07-16 01:56:43', '', 'c-4', '', 'inherit', 'open', 'closed', '', 'c-4', '', '', '2022-07-16 01:56:43', '2022-07-16 01:56:43', '', 0, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/c-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(121, 1, '2022-07-19 09:06:21', '0000-00-00 00:00:00', '<p><br></p>', 'Auto Draft', '', 'draft', 'closed', 'closed', '', 'auto-draft', '', '', '2022-07-19 09:06:21', '2022-07-19 09:06:21', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=121', 0, 'courses', '', 0),
(123, 1, '2022-07-19 09:06:21', '2022-07-19 09:06:21', '', 'Auto Draft', '', 'publish', 'open', 'closed', '', 'auto-draft', '', '', '2022-07-19 09:06:21', '2022-07-19 09:06:21', '', 0, 'https://traininghub-uat.vus.edu.vn/product/auto-draft/', 0, 'product', '', 0),
(124, 1, '2022-07-19 09:50:55', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'draft', 'closed', 'closed', '', 'auto-draft', '', '', '2022-07-19 09:50:55', '2022-07-19 09:50:55', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=124', 0, 'courses', '', 0),
(125, 1, '2022-07-20 09:26:13', '2022-07-20 09:26:13', '', 'Courses', '', 'publish', 'closed', 'closed', '', 'courses', '', '', '2022-07-20 09:26:13', '2022-07-20 09:26:13', '', 0, 'https://traininghub-uat.vus.edu.vn/?page_id=125', 0, 'page', '', 0),
(126, 1, '2022-07-20 09:26:13', '2022-07-20 09:26:13', '', 'Courses', '', 'inherit', 'closed', 'closed', '', '125-revision-v1', '', '', '2022-07-20 09:26:13', '2022-07-20 09:26:13', '', 125, 'https://traininghub-uat.vus.edu.vn/125-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2022-07-27 02:34:54', '2022-07-27 02:34:54', '', 'Forgot password', '', 'publish', 'closed', 'closed', '', 'forgot-password', '', '', '2022-07-27 02:34:54', '2022-07-27 02:34:54', '', 0, 'https://traininghub-uat.vus.edu.vn/?page_id=128', 0, 'page', '', 0),
(129, 1, '2022-07-27 02:34:54', '2022-07-27 02:34:54', '', 'Forgot password', '', 'inherit', 'closed', 'closed', '', '128-revision-v1', '', '', '2022-07-27 02:34:54', '2022-07-27 02:34:54', '', 128, 'https://traininghub-uat.vus.edu.vn/128-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2022-07-27 09:04:11', '2022-07-27 09:04:11', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"93\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Home Sub Banner', 'home-sub-banner', 'publish', 'closed', 'closed', '', 'group_62e0ff450576f', '', '', '2022-07-27 09:08:04', '2022-07-27 09:08:04', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=acf-field-group&#038;p=130', 2, 'acf-field-group', '', 0),
(131, 1, '2022-07-27 09:04:11', '2022-07-27 09:04:11', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:5:\"large\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Home Sub Banner Image', 'home_sub_banner', 'publish', 'closed', 'closed', '', 'field_62e0ff4d87289', '', '', '2022-07-27 09:08:04', '2022-07-27 09:08:04', '', 130, 'https://traininghub-uat.vus.edu.vn/?post_type=acf-field&#038;p=131', 0, 'acf-field', '', 0),
(132, 1, '2022-07-27 09:05:38', '2022-07-27 09:05:38', '', 'home_sub_banner', '', 'inherit', 'open', 'closed', '', 'home_sub_banner', '', '', '2022-07-27 09:05:38', '2022-07-27 09:05:38', '', 93, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/07/home_sub_banner.png', 0, 'attachment', 'image/png', 0),
(133, 1, '2022-07-27 09:05:49', '2022-07-27 09:05:49', '', 'Home', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2022-07-27 09:05:49', '2022-07-27 09:05:49', '', 93, 'https://traininghub-uat.vus.edu.vn/93-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2022-07-27 09:08:45', '2022-07-27 09:08:45', '', 'Home', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2022-07-27 09:08:45', '2022-07-27 09:08:45', '', 93, 'https://traininghub-uat.vus.edu.vn/93-revision-v1/', 0, 'revision', '', 0),
(136, 1, '2022-07-27 14:24:04', '2022-07-27 14:24:04', '', 'Internal course 1', '', 'publish', 'closed', 'closed', '', 'internal-course-1', '', '', '2022-07-27 14:24:06', '2022-07-27 14:24:06', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=136', 0, 'courses', '', 0),
(138, 1, '2022-07-27 14:28:47', '2022-07-27 14:28:47', '', 'Special course 1', '', 'publish', 'closed', 'closed', '', 'special-course-1', '', '', '2022-08-18 03:12:35', '2022-08-18 03:12:35', '', 179, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=138', 0, 'courses', '', 0),
(141, 5, '2022-07-28 07:52:51', '2022-07-28 07:52:51', '', 'Course 100', '', 'publish', 'closed', 'closed', '', 'course-100-2', '', '', '2022-08-18 03:12:35', '2022-08-18 03:12:35', '', 179, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=141', 0, 'courses', '', 0),
(142, 5, '2022-07-28 07:51:43', '2022-07-28 07:51:43', '', 'Auto Draft', '', 'publish', 'open', 'closed', '', 'auto-draft-2', '', '', '2022-07-28 08:06:39', '2022-07-28 08:06:39', '', 0, 'https://traininghub-uat.vus.edu.vn/product/auto-draft-2/', 0, 'product', '', 0),
(143, 5, '2022-07-28 07:52:02', '2022-07-28 07:52:02', '..', 'Session 1', '', 'publish', 'closed', 'closed', '', 'session-1', '', '', '2022-07-28 07:52:02', '2022-07-28 07:52:02', '', 141, 'https://traininghub-uat.vus.edu.vn/topics/session-1/', 1, 'topics', '', 0),
(144, 5, '2022-07-28 07:52:34', '2022-07-28 07:52:34', '...', 'Session 2', '', 'publish', 'closed', 'closed', '', 'session-2', '', '', '2022-07-28 07:52:34', '2022-07-28 07:52:34', '', 141, 'https://traininghub-uat.vus.edu.vn/topics/session-2/', 2, 'topics', '', 0),
(145, 1, '2022-07-28 14:48:10', '0000-00-00 00:00:00', '', 'course 100', '', 'draft', 'closed', 'closed', '', 'course-100', '', '', '2022-07-28 14:48:10', '2022-07-28 14:48:10', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=145', 0, 'courses', '', 0),
(146, 1, '2022-08-01 02:47:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'draft', 'closed', 'closed', '', '', '', '', '2022-08-01 02:47:56', '0000-00-00 00:00:00', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&p=146', 0, 'courses', '', 0),
(147, 1, '2022-08-01 02:48:55', '2022-08-01 02:48:55', '', 'Internal course 2', '', 'publish', 'open', 'closed', '', 'internal-course-2', '', '', '2022-08-05 09:19:19', '2022-08-05 09:19:19', '', 0, 'https://traininghub-uat.vus.edu.vn/product/internal-course-2/', 0, 'product', '', 0),
(148, 2, '2022-08-01 08:07:01', '2022-08-01 08:07:01', 'blah blah', 'Course huy1', '', 'publish', 'closed', 'closed', '', 'course-huy1', '', '', '2022-08-02 16:32:05', '2022-08-02 16:32:05', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=148', 0, 'courses', '', 0),
(150, 2, '2022-08-02 16:29:13', '2022-08-02 16:29:13', '{\n    \"custom_css[site_el]\": {\n        \"value\": \".cls-active-courses .tutor-course-listing-grid-3 .tutor-course-listing-item:not(:first-child){background:black; opacity: 0.4;}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 2,\n        \"date_modified_gmt\": \"2022-08-02 16:29:13\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'e7e8854f-3a57-4d2d-b015-1f45a34d6390', '', '', '2022-08-02 16:29:13', '2022-08-02 16:29:13', '', 0, 'https://traininghub-uat.vus.edu.vn/e7e8854f-3a57-4d2d-b015-1f45a34d6390/', 0, 'customize_changeset', '', 0),
(151, 2, '2022-08-02 16:29:13', '2022-08-02 16:29:13', '.cls-active-courses .tutor-course-listing-grid-3 .tutor-course-listing-item:not(:first-child){background:black;pointer-events: none; opacity: 0.4;}', 'site_el', '', 'publish', 'closed', 'closed', '', 'site_el', '', '', '2022-08-03 01:35:34', '2022-08-03 01:35:34', '', 0, 'https://traininghub-uat.vus.edu.vn/site_el/', 0, 'custom_css', '', 0),
(152, 2, '2022-08-02 16:29:13', '2022-08-02 16:29:13', '.cls-active-courses .tutor-course-listing-grid-3 .tutor-course-listing-item:not(:first-child){background:black; opacity: 0.4;}', 'site_el', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2022-08-02 16:29:13', '2022-08-02 16:29:13', '', 151, 'https://traininghub-uat.vus.edu.vn/151-revision-v1/', 0, 'revision', '', 0),
(153, 2, '2022-08-02 16:29:50', '2022-08-02 16:29:50', '', 'Course Enrolled &ndash; 2 August, 2022 @ 4:29 pm', '', 'completed', 'closed', 'closed', '', 'course-enrolled-2-august-2022-429-pm', '', '', '2022-08-02 16:29:50', '2022-08-02 16:29:50', '', 148, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-2-august-2022-429-pm/', 0, 'tutor_enrolled', '', 0),
(154, 2, '2022-08-02 16:29:52', '2022-08-02 16:29:52', '', 'Course Enrolled &ndash; 2 August, 2022 @ 4:29 pm', '', 'completed', 'closed', 'closed', '', 'course-enrolled-2-august-2022-429-pm-2', '', '', '2022-08-02 16:29:52', '2022-08-02 16:29:52', '', 145, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-2-august-2022-429-pm-2/', 0, 'tutor_enrolled', '', 0),
(155, 2, '2022-08-02 16:29:59', '2022-08-02 16:29:59', '', 'Course Enrolled &ndash; 2 August, 2022 @ 4:29 pm', '', 'completed', 'closed', 'closed', '', 'course-enrolled-2-august-2022-429-pm-3', '', '', '2022-08-02 16:29:59', '2022-08-02 16:29:59', '', 136, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-2-august-2022-429-pm-3/', 0, 'tutor_enrolled', '', 0),
(156, 2, '2022-08-02 16:30:01', '2022-08-02 16:30:01', '', 'Course Enrolled &ndash; 2 August, 2022 @ 4:30 pm', '', 'completed', 'closed', 'closed', '', 'course-enrolled-2-august-2022-430-pm', '', '', '2022-08-02 16:30:01', '2022-08-02 16:30:01', '', 106, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-2-august-2022-430-pm/', 0, 'tutor_enrolled', '', 0),
(157, 2, '2022-08-02 16:32:39', '2022-08-02 16:32:39', '', 'Course Enrolled &ndash; 2 August, 2022 @ 4:32 pm', '', 'completed', 'closed', 'closed', '', 'course-enrolled-2-august-2022-432-pm', '', '', '2022-08-02 16:32:39', '2022-08-02 16:32:39', '', 79, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-2-august-2022-432-pm/', 0, 'tutor_enrolled', '', 0),
(158, 2, '2022-08-03 01:35:34', '2022-08-03 01:35:34', '{\n    \"custom_css[site_el]\": {\n        \"value\": \".cls-active-courses .tutor-course-listing-grid-3 .tutor-course-listing-item:not(:first-child){background:black;pointer-events: none; opacity: 0.4;}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 2,\n        \"date_modified_gmt\": \"2022-08-03 01:35:34\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '7e080b05-761d-4a0e-9b2e-98430fd471c6', '', '', '2022-08-03 01:35:34', '2022-08-03 01:35:34', '', 0, 'https://traininghub-uat.vus.edu.vn/7e080b05-761d-4a0e-9b2e-98430fd471c6/', 0, 'customize_changeset', '', 0),
(159, 2, '2022-08-03 01:35:34', '2022-08-03 01:35:34', '.cls-active-courses .tutor-course-listing-grid-3 .tutor-course-listing-item:not(:first-child){background:black;pointer-events: none; opacity: 0.4;}', 'site_el', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2022-08-03 01:35:34', '2022-08-03 01:35:34', '', 151, 'https://traininghub-uat.vus.edu.vn/151-revision-v1/', 0, 'revision', '', 0),
(161, 5, '2022-08-05 06:32:51', '0000-00-00 00:00:00', 'Test lan 1', 'Internal Test 1', '', 'draft', 'closed', 'closed', '', 'internal-test-1', '', '', '2022-08-05 06:32:51', '2022-08-05 06:32:51', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=161', 0, 'courses', '', 0),
(162, 5, '2022-08-05 07:03:00', '2022-08-05 07:03:00', 'Internal Test 1 about', 'Internal Test 1', '', 'publish', 'closed', 'closed', '', 'internal-test-1-2', '', '', '2022-08-05 07:58:12', '2022-08-05 07:58:12', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=162', 0, 'courses', '', 0),
(163, 5, '2022-08-05 06:52:32', '2022-08-05 06:52:32', '', 'beach-blurred-wallpaper-preview', '', 'inherit', 'open', 'closed', '', 'beach-blurred-wallpaper-preview', '', '', '2022-08-05 06:52:32', '2022-08-05 06:52:32', '', 0, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/08/beach-blurred-wallpaper-preview.jpg', 0, 'attachment', 'image/jpeg', 0),
(164, 5, '2022-08-05 06:55:12', '2022-08-05 06:55:12', 'Topic 1 summary', 'Topic 1', '', 'publish', 'closed', 'closed', '', 'topic-1', '', '', '2022-08-05 06:55:12', '2022-08-05 06:55:12', '', 162, 'https://traininghub-uat.vus.edu.vn/topics/topic-1/', 1, 'topics', '', 0),
(165, 5, '2022-08-05 06:55:34', '2022-08-05 06:55:34', 'Topic 2 summary', 'Topic 2', '', 'publish', 'closed', 'closed', '', 'topic-2', '', '', '2022-08-05 06:55:34', '2022-08-05 06:55:34', '', 162, 'https://traininghub-uat.vus.edu.vn/topics/topic-2/', 2, 'topics', '', 0),
(166, 5, '2022-08-05 06:56:27', '2022-08-05 06:56:27', '<iframe title=\"The Gummy Bear Song - Long English Version\" width=\"525\" height=\"394\" src=\"https://www.youtube.com/embed/astISOttCQ0?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '', '', 'publish', 'closed', 'closed', '', '2e6cdf0eec82fe7de76e5fdb9e1f562c', '', '', '2022-08-05 06:56:27', '2022-08-05 06:56:27', '', 0, 'https://traininghub-uat.vus.edu.vn/2e6cdf0eec82fe7de76e5fdb9e1f562c/', 0, 'oembed_cache', '', 0),
(167, 5, '2022-08-05 06:57:29', '2022-08-05 06:57:29', '', 'ACTIVITY OF THE WEEK 11_2.7.2021', '', 'inherit', 'open', 'closed', '', 'activity-of-the-week-11_2-7-2021', '', '', '2022-08-05 06:57:29', '2022-08-05 06:57:29', '', 0, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/08/ACTIVITY-OF-THE-WEEK-11_2.7.2021.pdf', 0, 'attachment', 'application/pdf', 0),
(168, 5, '2022-08-05 06:58:30', '2022-08-05 06:58:30', '<p>[embed]https://www.youtube.com/watch?v=astISOttCQ0[/embed]<br /><br />Watch this video</p>', 'Watch a video', '', 'publish', 'open', 'closed', '', 'watch-a-video', '', '', '2022-08-05 06:58:30', '2022-08-05 06:58:30', '', 164, 'https://traininghub-uat.vus.edu.vn/courses/internal-test-1/lesson/watch-a-video/', 0, 'lesson', '', 0),
(169, 5, '2022-08-05 07:20:03', '2022-08-05 07:20:03', '', 'Internal Test 1', '', 'publish', 'open', 'closed', '', 'internal-test-1', '', '', '2022-08-05 07:58:12', '2022-08-05 07:58:12', '', 0, 'https://traininghub-uat.vus.edu.vn/product/internal-test-1/', 0, 'product', '', 0),
(170, 5, '2022-08-05 07:55:26', '2022-08-05 07:55:26', 'Child course 1 about', 'Child course 1', '', 'publish', 'closed', 'closed', '', 'child-course-1', '', '', '2022-08-05 07:55:26', '2022-08-05 07:55:26', '', 162, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=170', 0, 'courses', '', 0),
(171, 5, '2022-08-05 07:46:15', '2022-08-05 07:46:15', '', 'Arte_Surfside-LXCollection-Background', '', 'inherit', 'open', 'closed', '', 'arte_surfside-lxcollection-background', '', '', '2022-08-05 07:46:15', '2022-08-05 07:46:15', '', 0, 'https://traininghub-uat.vus.edu.vn/wp-content/uploads/2022/08/Arte_Surfside-LXCollection-Background.jpg', 0, 'attachment', 'image/jpeg', 0),
(172, 5, '2022-08-05 07:46:30', '2022-08-05 07:46:30', '', 'Topic 1', '', 'publish', 'closed', 'closed', '', 'topic-1-2', '', '', '2022-08-05 07:46:30', '2022-08-05 07:46:30', '', 170, 'https://traininghub-uat.vus.edu.vn/topics/topic-1-2/', 1, 'topics', '', 0),
(173, 5, '2022-08-05 07:47:09', '2022-08-05 07:47:09', '<p>Assignment 1</p>', 'Assignments', '', 'publish', 'closed', 'closed', '', 'assignments', '', '', '2022-08-05 07:47:09', '2022-08-05 07:47:09', '', 172, 'https://traininghub-uat.vus.edu.vn/courses/child-course-1/assignments/assignments/', 1, 'tutor_assignments', '', 0),
(174, 5, '2022-08-05 07:55:21', '2022-08-05 07:55:21', '', 'Quiz 1', '', 'publish', 'closed', 'closed', '', 'quiz-1', '', '', '2022-08-05 07:55:21', '2022-08-05 07:55:21', '', 172, 'https://traininghub-uat.vus.edu.vn/courses/child-course-1/tutor_quiz/quiz-1/', 3, 'tutor_quiz', '', 0),
(175, 5, '2022-08-05 07:56:04', '2022-08-05 07:56:04', '', 'Baby 2', '', 'publish', 'closed', 'closed', '', 'baby-2', '', '', '2022-08-05 07:58:12', '2022-08-05 07:58:12', '', 162, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=175', 0, 'courses', '', 0),
(176, 5, '2022-08-05 07:56:02', '2022-08-05 07:56:02', '', '1', '', 'publish', 'closed', 'closed', '', '1', '', '', '2022-08-05 07:56:02', '2022-08-05 07:56:02', '', 175, 'https://traininghub-uat.vus.edu.vn/topics/1/', 1, 'topics', '', 0),
(178, 1, '2022-08-05 09:19:41', '2022-08-05 09:19:41', '', 'Course Enrolled &ndash; 5 August, 2022 @ 9:19 am', '', 'completed', 'closed', 'closed', '', 'course-enrolled-5-august-2022-919-am', '', '', '2022-08-05 09:19:41', '2022-08-05 09:19:41', '', 106, 'https://traininghub-uat.vus.edu.vn/tutor_enrolled/course-enrolled-5-august-2022-919-am/', 0, 'tutor_enrolled', '', 0),
(179, 1, '2022-08-18 03:12:35', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'draft', 'closed', 'closed', '', 'auto-draft', '', '', '2022-08-18 03:12:35', '2022-08-18 03:12:35', '', 0, 'https://traininghub-uat.vus.edu.vn/?post_type=courses&#038;p=179', 0, 'courses', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 19, 'thumbnail_id', '0'),
(2, 20, 'thumbnail_id', '0'),
(3, 21, 'thumbnail_id', '0'),
(4, 22, 'thumbnail_id', '0'),
(5, 23, 'thumbnail_id', '0'),
(6, 24, 'thumbnail_id', '0'),
(7, 15, 'product_count_product_cat', '8');

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint UNSIGNED NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  `term_order` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`, `term_order`) VALUES
(1, 'Chưa được phân loại', 'khong-phan-loai', 0, 0),
(2, 'simple', 'simple', 0, 0),
(3, 'grouped', 'grouped', 0, 0),
(4, 'variable', 'variable', 0, 0),
(5, 'external', 'external', 0, 0),
(6, 'exclude-from-search', 'exclude-from-search', 0, 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0, 0),
(8, 'featured', 'featured', 0, 0),
(9, 'outofstock', 'outofstock', 0, 0),
(10, 'rated-1', 'rated-1', 0, 0),
(11, 'rated-2', 'rated-2', 0, 0),
(12, 'rated-3', 'rated-3', 0, 0),
(13, 'rated-4', 'rated-4', 0, 0),
(14, 'rated-5', 'rated-5', 0, 0),
(15, 'Uncategorized', 'uncategorized', 0, 1),
(16, 'Header Menu', 'header-menu', 0, 0),
(17, 'Footer Menu', 'footer-menu', 0, 0),
(18, 'news', 'news', 0, 0),
(19, 'Trending courses', 'trending-courses', 0, 0),
(20, 'Temporariness', 'temporariness', 0, 0),
(21, 'Kids', 'kids', 0, 0),
(22, 'Teenagers', 'teenagers', 0, 0),
(23, 'Teaching skills', 'teaching-skills', 0, 0),
(24, 'Workshop', 'workshop', 0, 0),
(25, 'Soft Skills', 'soft-skills', 0, 0),
(26, 'Teaching skill', 'teaching-skill', 0, 0),
(28, 'Programe 1', 'programe-1', 0, 0),
(31, 'SPEACIAL COURSES', 'speacial-courses', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(31, 21, 0),
(62, 21, 0),
(79, 19, 0),
(79, 20, 0),
(79, 21, 0),
(79, 22, 0),
(79, 23, 0),
(79, 24, 0),
(81, 16, 0),
(82, 16, 0),
(83, 17, 0),
(84, 17, 0),
(85, 17, 0),
(86, 17, 0),
(90, 1, 0),
(100, 20, 0),
(100, 21, 0),
(100, 23, 0),
(103, 2, 0),
(103, 15, 0),
(104, 2, 0),
(104, 15, 0),
(105, 2, 0),
(105, 15, 0),
(106, 21, 0),
(107, 2, 0),
(107, 15, 0),
(121, 23, 0),
(121, 24, 0),
(123, 2, 0),
(123, 15, 0),
(138, 31, 0),
(141, 19, 0),
(141, 22, 0),
(142, 2, 0),
(142, 15, 0),
(147, 2, 0),
(147, 15, 0),
(148, 31, 0),
(162, 23, 0),
(169, 2, 0),
(169, 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'product_type', '', 0, 8),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 8),
(16, 16, 'nav_menu', '', 0, 2),
(17, 17, 'nav_menu', '', 0, 4),
(18, 18, 'category', '', 0, 0),
(19, 19, 'course-category', '', 0, 2),
(20, 20, 'course-category', '', 0, 2),
(21, 21, 'course-category', '', 0, 5),
(22, 22, 'course-category', '', 0, 2),
(23, 23, 'course-category', '', 0, 3),
(24, 24, 'course-category', '', 0, 1),
(25, 25, 'post_tag', '', 0, 0),
(26, 26, 'post_tag', '', 0, 0),
(28, 28, 'course-tag', '', 0, 0),
(31, 31, 'course-tag', '', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `wp_tutor_earnings`
--

DROP TABLE IF EXISTS `wp_tutor_earnings`;
CREATE TABLE `wp_tutor_earnings` (
  `earning_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `course_id` bigint DEFAULT NULL,
  `order_id` bigint DEFAULT NULL,
  `order_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_price_total` decimal(16,2) DEFAULT NULL,
  `course_price_grand_total` decimal(16,2) DEFAULT NULL,
  `instructor_amount` decimal(16,2) DEFAULT NULL,
  `instructor_rate` decimal(16,2) DEFAULT NULL,
  `admin_amount` decimal(16,2) DEFAULT NULL,
  `admin_rate` decimal(16,2) DEFAULT NULL,
  `commission_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deduct_fees_amount` decimal(16,2) DEFAULT NULL,
  `deduct_fees_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deduct_fees_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `process_by` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_tutor_notifications`
--

DROP TABLE IF EXISTS `wp_tutor_notifications`;
CREATE TABLE `wp_tutor_notifications` (
  `ID` bigint UNSIGNED NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('READ','UNREAD') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiver_id` bigint UNSIGNED DEFAULT NULL,
  `post_id` bigint UNSIGNED DEFAULT NULL,
  `topic_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_tutor_quiz_attempts`
--

DROP TABLE IF EXISTS `wp_tutor_quiz_attempts`;
CREATE TABLE `wp_tutor_quiz_attempts` (
  `attempt_id` bigint NOT NULL,
  `course_id` bigint DEFAULT NULL,
  `quiz_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `total_questions` int DEFAULT NULL,
  `total_answered_questions` int DEFAULT NULL,
  `total_marks` decimal(9,2) DEFAULT NULL,
  `earned_marks` decimal(9,2) DEFAULT NULL,
  `attempt_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attempt_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempt_ip` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempt_started_at` datetime DEFAULT NULL,
  `attempt_ended_at` datetime DEFAULT NULL,
  `is_manually_reviewed` int DEFAULT NULL,
  `manually_reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_tutor_quiz_attempt_answers`
--

DROP TABLE IF EXISTS `wp_tutor_quiz_attempt_answers`;
CREATE TABLE `wp_tutor_quiz_attempt_answers` (
  `attempt_answer_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `quiz_id` bigint DEFAULT NULL,
  `question_id` bigint DEFAULT NULL,
  `quiz_attempt_id` bigint DEFAULT NULL,
  `given_answer` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `question_mark` decimal(8,2) DEFAULT NULL,
  `achieved_mark` decimal(8,2) DEFAULT NULL,
  `minus_mark` decimal(8,2) DEFAULT NULL,
  `is_correct` tinyint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_tutor_quiz_questions`
--

DROP TABLE IF EXISTS `wp_tutor_quiz_questions`;
CREATE TABLE `wp_tutor_quiz_questions` (
  `question_id` bigint NOT NULL,
  `quiz_id` bigint DEFAULT NULL,
  `question_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `question_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `question_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question_mark` decimal(9,2) DEFAULT NULL,
  `question_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `question_order` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_tutor_quiz_questions`
--

INSERT INTO `wp_tutor_quiz_questions` (`question_id`, `quiz_id`, `question_title`, `question_description`, `question_type`, `question_mark`, `question_settings`, `question_order`) VALUES
(1, 174, 'Question 1', 'Example', 'image_answering', '1.00', 'a:4:{s:13:\"question_type\";s:15:\"image_answering\";s:15:\"answer_required\";s:1:\"1\";s:13:\"question_mark\";s:4:\"1.00\";s:18:\"show_question_mark\";s:1:\"1\";}', 1),
(2, 174, 'Question 2', '', 'fill_in_the_blank', '1.00', 'a:3:{s:13:\"question_type\";s:17:\"fill_in_the_blank\";s:15:\"answer_required\";s:1:\"1\";s:13:\"question_mark\";s:4:\"1.00\";}', 2);

-- --------------------------------------------------------

--
-- Table structure for table `wp_tutor_quiz_question_answers`
--

DROP TABLE IF EXISTS `wp_tutor_quiz_question_answers`;
CREATE TABLE `wp_tutor_quiz_question_answers` (
  `answer_id` bigint NOT NULL,
  `belongs_question_id` bigint DEFAULT NULL,
  `belongs_question_type` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answer_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_correct` tinyint DEFAULT NULL,
  `image_id` bigint DEFAULT NULL,
  `answer_two_gap_match` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `answer_view_format` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answer_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `answer_order` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_tutor_quiz_question_answers`
--

INSERT INTO `wp_tutor_quiz_question_answers` (`answer_id`, `belongs_question_id`, `belongs_question_type`, `answer_title`, `is_correct`, `image_id`, `answer_two_gap_match`, `answer_view_format`, `answer_settings`, `answer_order`) VALUES
(1, 1, 'true_false', 'True', 1, NULL, 'true', NULL, NULL, 0),
(2, 1, 'true_false', 'False', 0, NULL, 'false', NULL, NULL, 0),
(3, 1, 'image_answering', 'a', NULL, 118, NULL, '', NULL, 1),
(4, 1, 'image_answering', 'b', NULL, 117, NULL, '0', NULL, 2),
(5, 2, 'true_false', 'True', 1, NULL, 'true', NULL, NULL, 0),
(6, 2, 'true_false', 'False', 0, NULL, 'false', NULL, NULL, 0),
(7, 2, 'fill_in_the_blank', 'A horse has ___ legs and can ___ very fast.', NULL, NULL, 'four | run', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_tutor_withdraws`
--

DROP TABLE IF EXISTS `wp_tutor_withdraws`;
CREATE TABLE `wp_tutor_withdraws` (
  `withdraw_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `amount` decimal(16,2) DEFAULT NULL,
  `method_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'webmaster'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:2:{s:13:\"administrator\";b:1;s:16:\"tutor_instructor\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '177'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:13:\"171.252.153.0\";}'),
(19, 1, '_is_tutor_instructor', '1656644249'),
(20, 1, '_tutor_instructor_status', 'approved'),
(21, 1, '_tutor_instructor_approved', '1656644249'),
(22, 1, '_tutor_instructor_course_id', '9'),
(23, 1, '_tutor_instructor_course_id', '10'),
(24, 1, '_woocommerce_tracks_anon_id', 'woo:ICNkcWbSEt43LzR3gAP2gHKG'),
(25, 1, '_tutor_instructor_course_id', '18'),
(26, 1, '_tutor_instructor_course_id', '19'),
(27, 1, '_tutor_instructor_course_id', '20'),
(28, 1, '_tutor_instructor_course_id', '21'),
(29, 1, '_tutor_instructor_course_id', '22'),
(30, 1, '_tutor_instructor_course_id', '23'),
(31, 1, '_tutor_instructor_course_id', '25'),
(32, 1, '_tutor_instructor_course_id', '26'),
(33, 1, '_tutor_instructor_course_id', '27'),
(34, 1, '_tutor_instructor_course_id', '28'),
(35, 1, '_tutor_instructor_course_id', '29'),
(36, 1, '_tutor_instructor_course_id', '30'),
(37, 1, '_tutor_instructor_course_id', '31'),
(38, 1, 'wc_last_active', '1660780800'),
(39, 1, 'closedpostboxes_courses', 'a:2:{i:0;s:20:\"tutor-attach-product\";i:1;s:19:\"tutor-course-topics\";}'),
(40, 1, 'metaboxhidden_courses', 'a:0:{}'),
(41, 1, '_is_tutor_student', '1659691181'),
(42, 1, '_wc_plugin_framework_facebook_for_woocommerce_dismissed_messages', 'a:3:{s:56:\"facebook-for-woocommerce-deprecated-wc-version-as-of-6-4\";b:1;s:36:\"facebook_for_woocommerce_get_started\";b:1;s:56:\"facebook-for-woocommerce-deprecated-wc-version-as-of-6-5\";b:1;}'),
(43, 1, 'wp_user-settings', 'libraryContent=browse'),
(44, 1, 'wp_user-settings-time', '1657936571'),
(45, 1, 'dismissed_wc_admin_notice', '1'),
(48, 1, '_tutor_instructor_course_id', '59'),
(49, 1, '_tutor_instructor_course_id', '60'),
(50, 1, '_tutor_instructor_course_id', '61'),
(51, 1, '_tutor_instructor_course_id', '62'),
(53, 1, '_tutor_instructor_course_id', '70'),
(54, 1, '_tutor_instructor_course_id', '71'),
(55, 1, '_tutor_instructor_course_id', '72'),
(57, 1, '_tutor_instructor_course_id', '75'),
(58, 1, 'ame_show_hints', 'a:3:{s:17:\"ws_sidebar_pro_ad\";b:0;s:16:\"ws_whats_new_120\";b:0;s:24:\"ws_hint_menu_permissions\";b:0;}'),
(59, 2, 'nickname', 'admins'),
(60, 2, 'first_name', 'Admins'),
(61, 2, 'last_name', ''),
(62, 2, 'description', ''),
(63, 2, 'rich_editing', 'true'),
(64, 2, 'syntax_highlighting', 'true'),
(65, 2, 'comment_shortcuts', 'false'),
(66, 2, 'admin_color', 'fresh'),
(67, 2, 'use_ssl', '0'),
(68, 2, 'show_admin_bar_front', 'false'),
(69, 2, 'locale', ''),
(72, 2, 'dismissed_wp_pointers', ''),
(74, 2, 'wc_last_active', '1659484800'),
(76, 2, 'ame_rui_first_login_done', '1'),
(77, 2, 'wp_dashboard_quick_press_last_post_id', '149'),
(78, 2, 'community-events-location', 'a:1:{s:2:\"ip\";s:13:\"171.225.184.0\";}'),
(79, 2, 'billing_first_name', 'Admins'),
(80, 2, 'billing_last_name', ''),
(81, 2, 'billing_company', ''),
(82, 2, 'billing_address_1', ''),
(83, 2, 'billing_address_2', ''),
(84, 2, 'billing_city', ''),
(85, 2, 'billing_postcode', ''),
(86, 2, 'billing_country', ''),
(87, 2, 'billing_state', ''),
(88, 2, 'billing_phone', ''),
(89, 2, 'billing_email', 'admins@traininghub-uat.vus.edu.vn'),
(90, 2, 'shipping_first_name', ''),
(91, 2, 'shipping_last_name', ''),
(92, 2, 'shipping_company', ''),
(93, 2, 'shipping_address_1', ''),
(94, 2, 'shipping_address_2', ''),
(95, 2, 'shipping_city', ''),
(96, 2, 'shipping_postcode', ''),
(97, 2, 'shipping_country', ''),
(98, 2, 'shipping_state', ''),
(99, 2, '_tutor_profile_job_title', ''),
(100, 2, '_tutor_profile_bio', ''),
(101, 2, '_tutor_profile_photo', ''),
(102, 2, 'last_update', '1659340842'),
(104, 1, 'ame_rui_first_login_done', '1'),
(105, 2, 'wp_capabilities', 'a:3:{s:6:\"admins\";b:1;s:16:\"tutor_instructor\";b:1;s:13:\"administrator\";b:1;}'),
(106, 2, 'wp_user_level', '10'),
(107, 2, '_wc_plugin_framework_facebook_for_woocommerce_dismissed_messages', 'a:2:{s:56:\"facebook-for-woocommerce-deprecated-wc-version-as-of-6-4\";b:1;s:36:\"facebook_for_woocommerce_get_started\";b:1;}'),
(108, 2, '_tutor_instructor_course_id', '79'),
(109, 2, '_tutor_instructor_course_id', '80'),
(110, 2, 'wp_mail_smtp_dash_widget_lite_hide_graph', '1'),
(111, 2, 'closedpostboxes_dashboard', 'a:4:{i:0;s:32:\"wp_mail_smtp_reports_widget_lite\";i:1;s:18:\"dashboard_activity\";i:2;s:25:\"wpclever_dashboard_widget\";i:3;s:17:\"dashboard_primary\";}'),
(112, 2, 'metaboxhidden_dashboard', 'a:5:{i:0;s:32:\"wp_mail_smtp_reports_widget_lite\";i:1;s:19:\"dashboard_right_now\";i:2;s:18:\"dashboard_activity\";i:3;s:25:\"wpclever_dashboard_widget\";i:4;s:36:\"woocommerce_dashboard_recent_reviews\";}'),
(114, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(115, 1, 'metaboxhidden_nav-menus', 'a:11:{i:0;s:21:\"add-post-type-product\";i:1;s:21:\"add-post-type-courses\";i:2;s:20:\"add-post-type-lesson\";i:3;s:24:\"add-post-type-tutor_quiz\";i:4;s:31:\"add-post-type-tutor_assignments\";i:5;s:12:\"add-post_tag\";i:6;s:15:\"add-post_format\";i:7;s:15:\"add-product_cat\";i:8;s:15:\"add-product_tag\";i:9;s:19:\"add-course-category\";i:10;s:14:\"add-course-tag\";}'),
(116, 1, 'nav_menu_recently_edited', '17'),
(118, 3, 'nickname', 'hoaduong'),
(119, 3, 'first_name', 'Hoa'),
(120, 3, 'last_name', 'Duong'),
(121, 3, 'description', ''),
(122, 3, 'rich_editing', 'true'),
(123, 3, 'syntax_highlighting', 'true'),
(124, 3, 'comment_shortcuts', 'false'),
(125, 3, 'admin_color', 'fresh'),
(126, 3, 'use_ssl', '0'),
(127, 3, 'show_admin_bar_front', 'true'),
(128, 3, 'locale', ''),
(129, 3, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(130, 3, 'wp_user_level', '0'),
(132, 3, 'wc_last_active', '1659657600'),
(135, 3, 'ame_rui_first_login_done', '1'),
(139, 3, '_is_tutor_student', '1657121021'),
(150, 1, '_tutor_instructor_course_id', '100'),
(161, 1, '_tutor_instructor_course_id', '102'),
(170, 1, '_tutor_instructor_course_id', '106'),
(173, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:1:{s:32:\"a97da629b098b75c294dffdc3e463904\";a:6:{s:3:\"key\";s:32:\"a97da629b098b75c294dffdc3e463904\";s:10:\"product_id\";i:107;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";}}}'),
(177, 4, 'nickname', 'staff'),
(178, 4, 'first_name', 'Staff'),
(179, 4, 'last_name', ''),
(180, 4, 'description', ''),
(181, 4, 'rich_editing', 'true'),
(182, 4, 'syntax_highlighting', 'true'),
(183, 4, 'comment_shortcuts', 'false'),
(184, 4, 'admin_color', 'fresh'),
(185, 4, 'use_ssl', '0'),
(186, 4, 'show_admin_bar_front', 'true'),
(187, 4, 'locale', ''),
(188, 4, 'wp_capabilities', 'a:1:{s:12:\"shop_manager\";b:1;}'),
(189, 4, 'wp_user_level', '9'),
(190, 4, 'dismissed_wp_pointers', ''),
(192, 4, 'wc_last_active', '1657670400'),
(194, 4, 'ame_rui_first_login_done', '1'),
(195, 4, 'wp_dashboard_quick_press_last_post_id', '108'),
(196, 4, 'dismissed_no_shipping_methods_notice', '1'),
(209, 1, '_tutor_instructor_course_id', '121'),
(212, 1, '_tutor_instructor_course_id', '124'),
(236, 3, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:1:{s:32:\"3636638817772e42b59d74cff571fbb3\";a:11:{s:3:\"key\";s:32:\"3636638817772e42b59d74cff571fbb3\";s:10:\"product_id\";i:169;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:5000000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:5000000;s:8:\"line_tax\";i:0;}}}'),
(250, 1, 'session_tokens', 'a:1:{s:64:\"65bfc0c036b8a4cf5a41659168e2a1d3088b04656b082e2134ece8af79338551\";a:4:{s:10:\"expiration\";i:1660965119;s:2:\"ip\";s:12:\"14.161.20.54\";s:2:\"ua\";s:142:\"Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/104.0.5112.99 Mobile/15E148 Safari/604.1\";s:5:\"login\";i:1660792319;}}'),
(253, 1, '_tutor_instructor_course_id', '135'),
(254, 1, '_tutor_instructor_course_id', '136'),
(255, 1, '_tutor_instructor_course_id', '137'),
(256, 1, '_tutor_instructor_course_id', '138'),
(262, 5, 'nickname', 'hien.ltv@vus-etsc.edu.vn'),
(263, 5, 'first_name', 'Hien LE'),
(264, 5, 'last_name', ''),
(265, 5, 'description', ''),
(266, 5, 'rich_editing', 'true'),
(267, 5, 'syntax_highlighting', 'true'),
(268, 5, 'comment_shortcuts', 'false'),
(269, 5, 'admin_color', 'fresh'),
(270, 5, 'use_ssl', '0'),
(271, 5, 'show_admin_bar_front', 'true'),
(272, 5, 'locale', ''),
(275, 5, 'dismissed_wp_pointers', ''),
(276, 6, 'nickname', 'quocle@vus-etsc.edu.vn'),
(277, 6, 'first_name', 'Quoc LE'),
(278, 6, 'last_name', ''),
(279, 6, 'description', ''),
(280, 6, 'rich_editing', 'true'),
(281, 6, 'syntax_highlighting', 'true'),
(282, 6, 'comment_shortcuts', 'false'),
(283, 6, 'admin_color', 'fresh'),
(284, 6, 'use_ssl', '0'),
(285, 6, 'show_admin_bar_front', 'false'),
(286, 6, 'locale', ''),
(289, 6, 'dismissed_wp_pointers', ''),
(291, 6, 'wc_last_active', '1658966400'),
(293, 6, 'ame_rui_first_login_done', '1'),
(297, 6, 'billing_first_name', 'Quoc LE'),
(298, 6, 'billing_last_name', ''),
(299, 6, 'billing_company', ''),
(300, 6, 'billing_address_1', ''),
(301, 6, 'billing_address_2', ''),
(302, 6, 'billing_city', ''),
(303, 6, 'billing_postcode', ''),
(304, 6, 'billing_country', ''),
(305, 6, 'billing_state', ''),
(306, 6, 'billing_phone', ''),
(307, 6, 'billing_email', 'quocle@vus-etsc.edu.vn'),
(308, 6, 'shipping_first_name', ''),
(309, 6, 'shipping_last_name', ''),
(310, 6, 'shipping_company', ''),
(311, 6, 'shipping_address_1', ''),
(312, 6, 'shipping_address_2', ''),
(313, 6, 'shipping_city', ''),
(314, 6, 'shipping_postcode', ''),
(315, 6, 'shipping_country', ''),
(316, 6, 'shipping_state', ''),
(317, 6, '_tutor_profile_job_title', ''),
(318, 6, '_tutor_profile_bio', ''),
(319, 6, '_tutor_profile_photo', ''),
(320, 6, 'last_update', '1658994393'),
(321, 6, 'wp_dashboard_quick_press_last_post_id', '139'),
(324, 6, 'wp_capabilities', 'a:2:{s:13:\"administrator\";b:1;s:16:\"tutor_instructor\";b:1;}'),
(325, 6, 'wp_user_level', '10'),
(326, 5, 'wp_capabilities', 'a:2:{s:6:\"admins\";b:1;s:16:\"tutor_instructor\";b:1;}'),
(327, 5, 'wp_user_level', '10'),
(329, 5, 'wc_last_active', '1659657600'),
(331, 5, 'ame_rui_first_login_done', '1'),
(332, 5, 'wp_dashboard_quick_press_last_post_id', '140'),
(333, 5, '_tutor_instructor_course_id', '141'),
(338, 5, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:2:{s:32:\"a97da629b098b75c294dffdc3e463904\";a:11:{s:3:\"key\";s:32:\"a97da629b098b75c294dffdc3e463904\";s:10:\"product_id\";i:107;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:3600000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:3600000;s:8:\"line_tax\";i:0;}s:32:\"a8baa56554f96369ab93e4f3bb068c22\";a:6:{s:3:\"key\";s:32:\"a8baa56554f96369ab93e4f3bb068c22\";s:10:\"product_id\";i:142;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";}}}'),
(340, 1, '_tutor_instructor_course_id', '145'),
(342, 1, '_tutor_instructor_course_id', '146'),
(352, 2, '_is_tutor_instructor', '1659340842'),
(353, 2, '_tutor_instructor_status', 'approved'),
(354, 2, '_tutor_instructor_approved', '1659340842'),
(356, 2, '_tutor_instructor_course_id', '148'),
(359, 2, '_is_tutor_student', '1659457959'),
(377, 5, '_woocommerce_tracks_anon_id', 'woo:r0J3Ll8j4ZgpmMUdPo983Hnw'),
(378, 5, '_tutor_instructor_course_id', '161'),
(379, 5, '_tutor_instructor_course_id', '162'),
(386, 5, 'session_tokens', 'a:1:{s:64:\"08d8123b6ce3d021cc5aa1f1ee38ef6055c1ed8ae3eab7c26ac46efa12d9dc7c\";a:4:{s:10:\"expiration\";i:1659857878;s:2:\"ip\";s:13:\"116.108.11.32\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36\";s:5:\"login\";i:1659685078;}}'),
(390, 5, '_tutor_instructor_course_id', '170'),
(393, 5, '_tutor_instructor_course_id', '175'),
(410, 1, '_tutor_instructor_course_id', '179');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint UNSIGNED NOT NULL,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'webmaster', '$P$BYdYzF20OhTCYVTHTiqa8rP4yZcFje1', 'webmaster', 'heckmanle@gmail.com', '', '2022-07-01 02:30:09', '', 0, 'webmaster'),
(2, 'admins', '$P$Bl9FUSk1GW7zcNC4PUT9SBOSZXGLg60', 'admins', 'admins@traininghub-uat.vus.edu.vn', 'http://traininghub-uat.vus.edu.vn', '2022-07-05 09:41:21', '', 0, 'Admins'),
(3, 'hoaduong', '$P$BT/KXYvrQMx1MtkIX30nyVUhlclIm9.', 'hoaduong', 'hoaduong.pm@bessfu.com', '', '2022-07-06 06:55:50', '', 0, 'Hoa Duong'),
(4, 'staff', '$P$BAiuGrzQWUkO9mlZFw8Ty9GnhI0plt1', 'staff', 'staff@traininghub-uat.vus.edu.vn', '', '2022-07-13 15:31:09', '', 0, 'Staff'),
(5, 'hien.ltv@vus-etsc.edu.vn', '$P$BYgKQiNGUJ6vZfmKTJstPIUnR1PgFN1', 'hien-ltvvus-etsc-edu-vn', 'hien.ltv@vus-etsc.edu.vn', '', '2022-07-28 07:42:04', '', 0, 'Hien LE'),
(6, 'quocle@vus-etsc.edu.vn', '$P$BGC2/G0RFCCKKSgnyxGjMEzUNUXdWN0', 'quoclevus-etsc-edu-vn', 'quocle@vus-etsc.edu.vn', '', '2022-07-28 07:42:42', '', 0, 'Quoc LE');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_download_log`
--

DROP TABLE IF EXISTS `wp_wc_download_log`;
CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `user_ip_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_product_meta_lookup`
--

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;
CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint NOT NULL,
  `sku` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(10,2) DEFAULT NULL,
  `max_price` decimal(10,2) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'instock',
  `rating_count` bigint DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_product_meta_lookup`
--

INSERT INTO `wp_wc_product_meta_lookup` (`product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`) VALUES
(103, '', 0, 0, '2.10', '2.10', 1, NULL, 'instock', 0, '0.00', 0),
(104, '', 0, 0, '2800000.00', '2800000.00', 1, NULL, 'instock', 0, '0.00', 0),
(105, '', 0, 0, '3400000.00', '3400000.00', 1, NULL, 'instock', 0, '0.00', 0),
(107, '', 0, 0, '3600000.00', '3600000.00', 0, NULL, 'instock', 0, '0.00', 0),
(123, '', 0, 0, '1200000.00', '1200000.00', 0, NULL, 'instock', 0, '0.00', 0),
(142, '', 0, 0, '2300000.00', '2300000.00', 0, NULL, 'instock', 0, '0.00', 0),
(147, '', 0, 0, '3600000.00', '3600000.00', 0, NULL, 'instock', 0, '0.00', 0),
(169, '', 0, 0, '5000000.00', '5000000.00', 0, NULL, 'instock', 0, '0.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_tax_rate_classes`
--

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;
CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint UNSIGNED NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_tax_rate_classes`
--

INSERT INTO `wp_wc_tax_rate_classes` (`tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_webhooks`
--

DROP TABLE IF EXISTS `wp_wc_webhooks`;
CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint UNSIGNED NOT NULL,
  `status` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `delivery_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint NOT NULL,
  `failure_count` smallint NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_api_keys`
--

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;
CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `truncated_key` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_attribute_taxonomies`
--

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;
CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint UNSIGNED NOT NULL,
  `attribute_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_downloadable_product_permissions`
--

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;
CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `download_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `order_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `order_key` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_log`
--

DROP TABLE IF EXISTS `wp_woocommerce_log`;
CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint NOT NULL,
  `source` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;
CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `order_item_id` bigint UNSIGNED NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_items`
--

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;
CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint UNSIGNED NOT NULL,
  `order_item_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokenmeta`
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;
CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `payment_token_id` bigint UNSIGNED NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokens`
--

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;
CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint UNSIGNED NOT NULL,
  `gateway_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_sessions`
--

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;
CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint UNSIGNED NOT NULL,
  `session_key` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zones`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;
CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint UNSIGNED NOT NULL,
  `zone_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_locations`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;
CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint UNSIGNED NOT NULL,
  `zone_id` bigint UNSIGNED NOT NULL,
  `location_code` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_methods`
--

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;
CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint UNSIGNED NOT NULL,
  `instance_id` bigint UNSIGNED NOT NULL,
  `method_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rates`
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;
CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint UNSIGNED NOT NULL,
  `tax_rate_compound` int NOT NULL DEFAULT '0',
  `tax_rate_shipping` int NOT NULL DEFAULT '1',
  `tax_rate_order` bigint UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rate_locations`
--

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;
CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint UNSIGNED NOT NULL,
  `location_code` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint UNSIGNED NOT NULL,
  `location_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpmailsmtp_debug_events`
--

DROP TABLE IF EXISTS `wp_wpmailsmtp_debug_events`;
CREATE TABLE `wp_wpmailsmtp_debug_events` (
  `id` int UNSIGNED NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `initiator` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `event_type` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wpmailsmtp_debug_events`
--

INSERT INTO `wp_wpmailsmtp_debug_events` (`id`, `content`, `initiator`, `event_type`, `created_at`) VALUES
(1, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"D:\\\\SRC\\\\traininghub_frontend_uat\\\\wp-content\\\\plugins\\\\wp-mail-smtp\\\\src\\\\Reports\\\\Emails\\\\Summary.php\",\"line\":112}', 0, '2022-07-11 19:01:06'),
(2, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"D:\\\\SRC\\\\traininghub_frontend_uat\\\\wp-includes\\\\class-wp-recovery-mode-email-service.php\",\"line\":217}', 0, '2022-07-13 00:38:28'),
(3, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"D:\\\\SRC\\\\traininghub_frontend_uat\\\\wp-includes\\\\user.php\",\"line\":2050}', 0, '2022-07-13 08:29:58'),
(4, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"D:\\\\SRC\\\\traininghub_frontend_uat\\\\wp-includes\\\\pluggable.php\",\"line\":1980}', 0, '2022-07-13 08:31:11'),
(5, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"D:\\\\SRC\\\\traininghub_frontend_uat\\\\wp-content\\\\plugins\\\\wp-mail-smtp\\\\src\\\\Reports\\\\Emails\\\\Summary.php\",\"line\":112}', 0, '2022-07-18 19:02:01'),
(6, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"D:\\\\SRC\\\\traininghub_frontend_uat\\\\wp-content\\\\plugins\\\\wp-mail-smtp\\\\src\\\\Reports\\\\Emails\\\\Summary.php\",\"line\":112}', 0, '2022-07-26 00:44:58'),
(7, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"\\/home\\/www\\/vu_traininghub_frontend\\/wp-includes\\/pluggable.php\",\"line\":1980}', 0, '2022-07-28 07:42:04'),
(8, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"\\/home\\/www\\/vu_traininghub_frontend\\/wp-includes\\/pluggable.php\",\"line\":1980}', 0, '2022-07-28 07:42:43'),
(9, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"\\/home\\/www\\/vu_traininghub_frontend\\/wp-includes\\/user.php\",\"line\":2050}', 0, '2022-08-01 08:00:09'),
(10, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"\\/home\\/www\\/vu_traininghub_frontend\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}', 0, '2022-08-02 08:39:09'),
(11, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"\\/home\\/www\\/vu_traininghub_frontend\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}', 0, '2022-08-09 08:53:33'),
(12, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"\\/home\\/www\\/vu_traininghub_frontend\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}', 0, '2022-08-16 10:30:12'),
(13, 'Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.', '{\"file\":\"\\/home\\/www\\/vu_traininghub_frontend\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}', 0, '2022-08-23 13:25:35');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpmailsmtp_tasks_meta`
--

DROP TABLE IF EXISTS `wp_wpmailsmtp_tasks_meta`;
CREATE TABLE `wp_wpmailsmtp_tasks_meta` (
  `id` bigint NOT NULL,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wpmailsmtp_tasks_meta`
--

INSERT INTO `wp_wpmailsmtp_tasks_meta` (`id`, `action`, `data`, `date`) VALUES
(1, 'wp_mail_smtp_summary_report_email', 'W10=', '2022-07-05 09:49:47'),
(2, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2022-07-05 09:49:55'),
(3, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2022-07-06 14:39:09'),
(4, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2022-07-11 08:28:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `hook` (`hook`),
  ADD KEY `status` (`status`),
  ADD KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  ADD KEY `args` (`args`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `last_attempt_gmt` (`last_attempt_gmt`),
  ADD KEY `claim_id` (`claim_id`),
  ADD KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`);

--
-- Indexes for table `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  ADD PRIMARY KEY (`claim_id`),
  ADD KEY `date_created_gmt` (`date_created_gmt`);

--
-- Indexes for table `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `slug` (`slug`(191));

--
-- Indexes for table `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `log_date_gmt` (`log_date_gmt`);

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_tutor_earnings`
--
ALTER TABLE `wp_tutor_earnings`
  ADD PRIMARY KEY (`earning_id`);

--
-- Indexes for table `wp_tutor_notifications`
--
ALTER TABLE `wp_tutor_notifications`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wp_tutor_quiz_attempts`
--
ALTER TABLE `wp_tutor_quiz_attempts`
  ADD PRIMARY KEY (`attempt_id`);

--
-- Indexes for table `wp_tutor_quiz_attempt_answers`
--
ALTER TABLE `wp_tutor_quiz_attempt_answers`
  ADD PRIMARY KEY (`attempt_answer_id`);

--
-- Indexes for table `wp_tutor_quiz_questions`
--
ALTER TABLE `wp_tutor_quiz_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `wp_tutor_quiz_question_answers`
--
ALTER TABLE `wp_tutor_quiz_question_answers`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `wp_tutor_withdraws`
--
ALTER TABLE `wp_tutor_withdraws`
  ADD PRIMARY KEY (`withdraw_id`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indexes for table `wp_wc_product_meta_lookup`
--
ALTER TABLE `wp_wc_product_meta_lookup`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `virtual` (`virtual`),
  ADD KEY `downloadable` (`downloadable`),
  ADD KEY `stock_status` (`stock_status`),
  ADD KEY `stock_quantity` (`stock_quantity`),
  ADD KEY `onsale` (`onsale`),
  ADD KEY `min_max_price` (`min_price`,`max_price`);

--
-- Indexes for table `wp_wc_tax_rate_classes`
--
ALTER TABLE `wp_wc_tax_rate_classes`
  ADD PRIMARY KEY (`tax_rate_class_id`),
  ADD UNIQUE KEY `slug` (`slug`(191));

--
-- Indexes for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Indexes for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Indexes for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`);

--
-- Indexes for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD UNIQUE KEY `session_key` (`session_key`);

--
-- Indexes for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Indexes for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_wpmailsmtp_debug_events`
--
ALTER TABLE `wp_wpmailsmtp_debug_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpmailsmtp_tasks_meta`
--
ALTER TABLE `wp_wpmailsmtp_tasks_meta`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  MODIFY `action_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=680;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  MODIFY `claim_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4060;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  MODIFY `group_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  MODIFY `log_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1826;

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6212;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=584;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `wp_tutor_earnings`
--
ALTER TABLE `wp_tutor_earnings`
  MODIFY `earning_id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_tutor_notifications`
--
ALTER TABLE `wp_tutor_notifications`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_tutor_quiz_attempts`
--
ALTER TABLE `wp_tutor_quiz_attempts`
  MODIFY `attempt_id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_tutor_quiz_attempt_answers`
--
ALTER TABLE `wp_tutor_quiz_attempt_answers`
  MODIFY `attempt_answer_id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_tutor_quiz_questions`
--
ALTER TABLE `wp_tutor_quiz_questions`
  MODIFY `question_id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_tutor_quiz_question_answers`
--
ALTER TABLE `wp_tutor_quiz_question_answers`
  MODIFY `answer_id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `wp_tutor_withdraws`
--
ALTER TABLE `wp_tutor_withdraws`
  MODIFY `withdraw_id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=411;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  MODIFY `download_log_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wc_tax_rate_classes`
--
ALTER TABLE `wp_wc_tax_rate_classes`
  MODIFY `tax_rate_class_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  MODIFY `webhook_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  MODIFY `key_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  MODIFY `log_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  MODIFY `order_item_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  MODIFY `token_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  MODIFY `session_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3009;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpmailsmtp_debug_events`
--
ALTER TABLE `wp_wpmailsmtp_debug_events`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `wp_wpmailsmtp_tasks_meta`
--
ALTER TABLE `wp_wpmailsmtp_tasks_meta`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
